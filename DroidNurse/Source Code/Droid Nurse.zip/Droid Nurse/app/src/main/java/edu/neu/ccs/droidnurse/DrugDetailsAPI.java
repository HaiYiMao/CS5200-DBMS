package edu.neu.ccs.droidnurse;

import android.app.Fragment;
import android.app.FragmentManager;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.ImageView;
import android.util.Log;
import android.widget.Toast;
import android.widget.Button;
import java.io.BufferedReader;
import java.io.InputStream;
import org.apache.http.HttpResponse;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.DefaultHttpClient;
import java.io.InputStreamReader;
import org.json.JSONObject;
import org.json.XML;
import android.graphics.Bitmap;
import java.net.URL;
import java.net.HttpURLConnection;
import android.graphics.BitmapFactory;
import java.net.URLConnection;

/**
 * Created by Venkatesh on 30/07/14.
 */

public class DrugDetailsAPI extends Fragment {

    private static final String TAG = "DrugDetailsAPI";
    private final String SCREENCODE = "D2";
    // http://pillbox.nlm.nih.gov/PHP/pillboxAPIService.php?prodcode=0591-5714&key=2A6FLIVYWI
    private final String baseAPIURL = "http://pillbox.nlm.nih.gov/PHP/pillboxAPIService.php?prodcode=";
    private final String smallImageURL = "http://pillbox.nlm.nih.gov/assets/small/";
    private final String largeImageURL = "http://pillbox.nlm.nih.gov/assets/large/";
    private final String imageType = ".jpg";
    private final String apiKey = "2A6FLIVYWI";
    private final String baseAPIKeyPartURL = "&key=" + apiKey;
    View rootView;

    // Bundle Arguments
    public String ARG_USER_ID;
    public String NPINUMBER;
    public String PRESCRIBERLNAME;
    public String PRESCRIBERFNAME;
    public String RXNUMBER;
    public String NDCNUMBER;
    public String NDCNAME;
    public String NO_OF_REFILLS;
    public String WRITTENDATE;
    public String EXPIRYDATE;
    public String DRUGCOUNT;
    public String DRUGDOSAGE;
    public String DOSAGECOUNT;
    public String DOSAGEINTERVAL;
    public String DRUGTEMPNAME;
    public String NDCNUMBERTEMP;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        try {
            GetBundleArguments();
            rootView = inflater.inflate(R.layout.fragment_drug_details_api, container, false);

            String xmlData = GetXMLDrugDetailsFromAPI(NDCNUMBERTEMP);
            String jsonData = ConvertXMLToJSON(xmlData);
            DisplayJSONData(jsonData);

            Button btnBackToSearchResults = (Button) rootView.findViewById(R.id.btnDDBackToResults);
            btnBackToSearchResults.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {

                    Fragment searchDrugFragment = new SearchDrugFragment();
                    Bundle args = new Bundle();
                    args.putString("USER_ID", ARG_USER_ID);
                    args.putString("SCREEN_CODE", SCREENCODE);
                    args.putString("RXNUMBER", RXNUMBER);
                    args.putString("NPINUMBER", NPINUMBER);
                    args.putString("PRESCRIBERLNAME", PRESCRIBERLNAME);
                    args.putString("PRESCRIBERFNAME", PRESCRIBERFNAME);
                    args.putString("NDCNUMBER", NDCNUMBER);
                    args.putString("NDCNAME", NDCNAME);
                    args.putString("NO_OF_REFILLS", NO_OF_REFILLS);
                    args.putString("WRITTENDATE", WRITTENDATE);
                    args.putString("EXPIRYDATE", EXPIRYDATE);
                    args.putString("DRUGCOUNT", DRUGCOUNT);
                    args.putString("DRUGDOSAGE", DRUGDOSAGE);
                    args.putString("DOSAGECOUNT", DOSAGECOUNT);
                    args.putString("DOSAGEINTERVAL", DOSAGEINTERVAL);
                    args.putString("DRUGTEMPNAME", DRUGTEMPNAME);
                    searchDrugFragment.setArguments(args);
                    FragmentManager fragmentManager = getFragmentManager();
                    fragmentManager.beginTransaction().replace(R.id.content_frame, searchDrugFragment).commit();

                }
            });

            Button btnSelectDrug = (Button) rootView.findViewById(R.id.btnDDSelectDrug);
            btnSelectDrug.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {

                    Fragment addRXFragment = new RxFragmentAddRx();
                    Bundle args = new Bundle();
                    args.putString("USER_ID", ARG_USER_ID);
                    args.putString("SCREEN_CODE", SCREENCODE);
                    args.putString("RXNUMBER", RXNUMBER);
                    args.putString("NPINUMBER", NPINUMBER);
                    args.putString("PRESCRIBERLNAME", PRESCRIBERLNAME);
                    args.putString("PRESCRIBERFNAME", PRESCRIBERFNAME);
                    EditText txtDrugName = (EditText) rootView.findViewById(R.id.txtDDDrugName);
                    args.putString("NDCNUMBER", NDCNUMBERTEMP);
                    args.putString("NDCNAME", txtDrugName.getText().toString().trim());
                    args.putString("NO_OF_REFILLS", NO_OF_REFILLS);
                    args.putString("WRITTENDATE", WRITTENDATE);
                    args.putString("EXPIRYDATE", EXPIRYDATE);
                    args.putString("DRUGCOUNT", DRUGCOUNT);
                    args.putString("DRUGDOSAGE", DRUGDOSAGE);
                    args.putString("DOSAGECOUNT", DOSAGECOUNT);
                    args.putString("DOSAGEINTERVAL", DOSAGEINTERVAL);
                    addRXFragment.setArguments(args);
                    FragmentManager fragmentManager = getFragmentManager();
                    fragmentManager.beginTransaction().replace(R.id.content_frame, addRXFragment).commit();

                }
            });

        } catch (Exception ex) {
            Log.e(TAG, "Exception - " + ex.getMessage());
        } finally {
            return rootView;
        }
    }


    // Retrieves the bundle arguments which holds data from the previous screens
    private void GetBundleArguments() {
        try {
            ARG_USER_ID = getArguments().getString("USER_ID");
            RXNUMBER = getArguments().getString("RXNUMBER");
            NPINUMBER = getArguments().getString("NPINUMBER");
            PRESCRIBERLNAME = getArguments().getString("PRESCRIBERLNAME");
            PRESCRIBERFNAME = getArguments().getString("PRESCRIBERFNAME");
            NDCNUMBER = getArguments().getString("NDCNUMBER");
            NDCNAME = getArguments().getString("NDCNAME");
            NO_OF_REFILLS = getArguments().getString("NO_OF_REFILLS");
            WRITTENDATE = getArguments().getString("WRITTENDATE");
            EXPIRYDATE = getArguments().getString("EXPIRYDATE");
            DRUGCOUNT = getArguments().getString("DRUGCOUNT");
            DRUGDOSAGE = getArguments().getString("DRUGDOSAGE");
            DOSAGECOUNT = getArguments().getString("DOSAGECOUNT");
            DOSAGEINTERVAL = getArguments().getString("DOSAGEINTERVAL");
            DRUGTEMPNAME = getArguments().getString("DRUGTEMPNAME");
            NDCNUMBERTEMP = getArguments().getString("NDCNUMBERTEMP");
        } catch (Exception ex) {
            Log.e(TAG, "Exception - " + ex.getMessage());
        }
    }

    // Below method uses HttpGet to receive json data from REST API (PILLBOX API)
    private String GetXMLDrugDetailsFromAPI(String ndcNumber) {
        String result = "";
        try {

            String framedAPIURL = baseAPIURL + ndcNumber.trim() + baseAPIKeyPartURL;
            //String framedAPIURL = baseAPIURL + "0591-5714" + baseAPIKeyPartURL;
            // create HttpClient
            HttpClient httpclient = new DefaultHttpClient();

            // make GET request to the given URL
            HttpResponse httpResponse = httpclient.execute(new HttpGet(framedAPIURL));

            // receive response as inputStream
            InputStream inputStream = httpResponse.getEntity().getContent();

            // convert inputstream to string
            if (inputStream != null) {
                result = convertInputStreamToString(inputStream);
            } else {
                Toast.makeText(getActivity(),
                        "Oops, unable to fetch data from PillBox REST API.", Toast.LENGTH_SHORT)
                        .show();
            }

        } catch (Exception ex) {
            Log.e(TAG, "Exception - " + ex.getMessage());
        } finally {
            return result;
        }
    }

    // Below method converts the input stream of data retrieved from the rest api and then converts to String format.
    private String convertInputStreamToString(InputStream inputStream) {
        String result = "";
        try {
            BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(inputStream));
            String line = "";
            while ((line = bufferedReader.readLine()) != null)
                result += line;

            inputStream.close();
        } catch (Exception ex) {
            Log.e(TAG, "Exception - " + ex.getMessage());
        } finally {
            return result;
        }
    }

    // Below methods converts the xml contents to equivalent json
    private String ConvertXMLToJSON(String xmlData) {
        String jsonData = "";
        try {
            final int PRETTY_PRINT_INDENT_FACTOR = 4;
            JSONObject xmlJSONObj = XML.toJSONObject(xmlData);
            jsonData = xmlJSONObj.toString(PRETTY_PRINT_INDENT_FACTOR);
        } catch (Exception ex) {
            Log.e(TAG, "Exception - " + ex.getMessage());
            Toast.makeText(getActivity(),
                    "Exception - " + ex.getMessage(), Toast.LENGTH_SHORT)
                    .show();
        } finally {
            return jsonData;
        }
    }

    // Below method parses the json data which was retrieved from rest api and then displays the appropriate value in the front end
    private void DisplayJSONData(String jsonData) {
        try {
            Boolean isImageAvailable = false;
            EditText txtNDCNumber = (EditText) rootView.findViewById(R.id.txtDDNDCNumber);
            EditText txtDrugName = (EditText) rootView.findViewById(R.id.txtDDDrugName);
            EditText txtManufacturerName = (EditText) rootView.findViewById(R.id.txtDDManufacturerName);
            EditText txtColor = (EditText) rootView.findViewById(R.id.txtDDColor);
            EditText txtImprint = (EditText) rootView.findViewById(R.id.txtDDImprint);
            EditText txtIngredients = (EditText) rootView.findViewById(R.id.txtDDIngredients);
            EditText txtHasImage = (EditText) rootView.findViewById(R.id.txtDDHasImage);
            ImageView imgViewDrug = (ImageView) rootView.findViewById(R.id.imgViewDrug);

            // Parsing the JSON Data to retrieve the appropriate values
            JSONObject jsonObject = new JSONObject(jsonData);
            JSONObject topLevelJSONObject = jsonObject.getJSONObject("Pills");
            JSONObject secondLevelJSONObject = topLevelJSONObject.getJSONObject("pill");

            txtNDCNumber.setText(NDCNUMBERTEMP);
            txtDrugName.setText(secondLevelJSONObject.getString("RXSTRING"));
            txtManufacturerName.setText(secondLevelJSONObject.getString("AUTHOR"));
            String jsonDataColor = secondLevelJSONObject.getString("SPLCOLOR");
            txtColor.setText(GetPillColor(jsonDataColor));
            txtImprint.setText(secondLevelJSONObject.getString("SPLIMPRINT"));
            txtIngredients.setText(secondLevelJSONObject.getString("SPL_INACTIVE_ING"));

            String jsonDataHasImage = secondLevelJSONObject.getString("HAS_IMAGE");
            if (jsonDataHasImage.equals("1")) {
                isImageAvailable = true;
                txtHasImage.setText("Image Preview Available For This Drug !!");
            }

            if (isImageAvailable) {
                String imageID = secondLevelJSONObject.getString("image_id");
                String finalImageURL = largeImageURL + imageID + imageType;

                Bitmap myBitmap = DownloadImageFromHTTPURL(finalImageURL);
                imgViewDrug.setImageBitmap(myBitmap);

            } else {
                txtHasImage.setText("Sorry, No Image Preview Available For This Drug.");
            }

            // Setting the control enabled property to false to make it read only.
            txtNDCNumber.setEnabled(false);
            txtDrugName.setEnabled(false);
            txtManufacturerName.setEnabled(false);
            txtColor.setEnabled(false);
            txtImprint.setEnabled(false);
            txtHasImage.setEnabled(false);
            txtIngredients.setEnabled(false);

        } catch (Exception ex) {
            Log.e(TAG, "Exception - " + ex.getMessage());
            Toast.makeText(getActivity(),
                    "Exception - " + ex.getMessage(), Toast.LENGTH_SHORT)
                    .show();
        }
    }


    // Below method assists in identifying the pill color
    private String GetPillColor(String colorCode) {
        String pillColor = "WHITE";
        try {
            String upperCasedColorCode = colorCode.toUpperCase().trim();
            if (upperCasedColorCode.equals("C48323")) {
                pillColor = "BLACK";
            } else if (upperCasedColorCode.equals("C48333")) {
                pillColor = "BLUE";
            } else if (upperCasedColorCode.equals("C48332")) {
                pillColor = "BROWN";
            } else if (upperCasedColorCode.equals("C48324")) {
                pillColor = "GRAY";
            } else if (upperCasedColorCode.equals("C48329")) {
                pillColor = "GREEN";
            } else if (upperCasedColorCode.equals("C48331")) {
                pillColor = "ORANGE";
            } else if (upperCasedColorCode.equals("C48328")) {
                pillColor = "PINK";
            } else if (upperCasedColorCode.equals("C48327")) {
                pillColor = "PURPLE";
            } else if (upperCasedColorCode.equals("C48326")) {
                pillColor = "RED";
            } else if (upperCasedColorCode.equals("C48334")) {
                pillColor = "TURQUOISE";
            } else if (upperCasedColorCode.equals("C48325")) {
                pillColor = "WHITE";
            } else if (upperCasedColorCode.equals("C48330")) {
                pillColor = "YELLOW";
            }

        } catch (Exception ex) {
            Log.e(TAG, "Exception - " + ex.getMessage());
        } finally {
            return pillColor;
        }

    }

    // Creates Bitmap from InputStream and returns it
    private Bitmap DownloadImageFromHTTPURL(String url) {
        Bitmap bitmap = null;
        InputStream stream = null;
        BitmapFactory.Options bmOptions = new BitmapFactory.Options();
        bmOptions.inSampleSize = 1;

        try {
            stream = GetHttpConnection(url);
            bitmap = BitmapFactory.
                    decodeStream(stream, null, bmOptions);
            stream.close();
        } catch (Exception ex) {
            Log.e(TAG, "Exception - " + ex.getMessage());
            Toast.makeText(getActivity(),
                    "Exception - " + ex.getMessage(), Toast.LENGTH_SHORT)
                    .show();
        }
        return bitmap;
    }

    // Makes HttpURLConnection and returns InputStream
    private InputStream GetHttpConnection(String urlString) {

        InputStream stream = null;

        try {
            URL url = new URL(urlString);
            URLConnection connection = url.openConnection();
            HttpURLConnection httpConnection = (HttpURLConnection) connection;
            httpConnection.setRequestMethod("GET");
            httpConnection.connect();

            if (httpConnection.getResponseCode() == HttpURLConnection.HTTP_OK) {
                stream = httpConnection.getInputStream();
            }
        } catch (Exception ex) {
            Log.e(TAG, "Exception - " + ex.getMessage());
            Toast.makeText(getActivity(),
                    "Exception - " + ex.getMessage(), Toast.LENGTH_SHORT)
                    .show();
        }
        return stream;
    }

}
