package edu.neu.ccs.droidnurse;


import android.graphics.Color;
import android.os.Bundle;
import android.app.Fragment;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TableLayout;
import android.widget.TableRow;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.view.ViewGroup.LayoutParams;
import android.content.Intent;

import com.mongodb.BasicDBList;
import com.mongodb.BasicDBObject;
import com.mongodb.DBCollection;
import com.mongodb.DBCursor;
import com.mongodb.DBObject;

import org.bson.types.ObjectId;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Enumeration;

import org.achartengine.ChartFactory;
import org.achartengine.model.CategorySeries;
import org.achartengine.renderer.DefaultRenderer;
import org.achartengine.renderer.SimpleSeriesRenderer;


/**
 * A simple {@link Fragment} subclass.
 */
public class ExpenseReportFragment extends Fragment {

    private static final String TAG = "ExpenseReportFragment";
    public String ARG_USER_ID = "";
    View rootView;

    // Below variables hold the from and to date for which the expense report needs to be generated
    private String fromDate = "";
    private String toDate = "";

    // Below variables hold the pie chart values
    private List<String> rxNumbersList = new ArrayList<String>();

    // Below dictionary holds the rxNumber and its PlanCoPay value which was retrieved from MongoDB
    Map<String, Double> rxExpenditureMap = new HashMap<String, Double>();


    public ExpenseReportFragment() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        try {
            GetBundleArguments();
            // Inflate the layout for this fragment
            rootView = inflater.inflate(R.layout.fragment_expense_report, container, false);

            Button btnGetExpenseReports = (Button) rootView.findViewById(R.id.btnGetExpenseReports);
            btnGetExpenseReports.setOnClickListener(new View.OnClickListener() {

                @Override
                public void onClick(View v) {
                    EditText txtFromDate = (EditText) rootView.findViewById(R.id.txtERFromDate);
                    EditText txtToDate = (EditText) rootView.findViewById(R.id.txtERToDate);

                    fromDate = txtFromDate.getText().toString().trim();
                    toDate = txtToDate.getText().toString().trim();

                    /*
                    fromDate = "08-01-2014";
                    toDate = "08-19-2014";
                    */

                    if ((fromDate.length() < 10) || (toDate.length() < 10)) {
                        Toast.makeText(getActivity(),
                                "Enter Valid Refill From/To Date", Toast.LENGTH_SHORT)
                                .show();
                    } else {
                        DisplayExpenseReport();
                    }
                }
            });
        } catch (Exception ex) {
            Log.e(TAG, "Exception - " + ex.getMessage());
            Toast.makeText(getActivity(),
                    "Exception - " + ex.getMessage(), Toast.LENGTH_SHORT)
                    .show();
        } finally {
            return rootView;
        }
    }


    // Retrieves the bundle arguments which holds data from the previous screens
    private void GetBundleArguments() {
        try {
            ARG_USER_ID = getArguments().getString("USER_ID");
        } catch (Exception ex) {
            Log.e(TAG, "Exception At GetBundleArguments() - " + ex.getMessage());
            Toast.makeText(getActivity(),
                    "Exception - " + ex.getMessage(), Toast.LENGTH_SHORT)
                    .show();
        }
    }

    // Below method is responsible for displaying the expenses incurred for RX in a tabular view
    private void DisplayExpenseReport() {
        try {
            // Once when this boolean value is set to true, the "Display Pie Chart" button would be displayed
            Boolean isRXExpenditureExists = false;
            TableRow tr_head = new TableRow(getActivity());
            TableLayout tblExpenseReportResults = (TableLayout) rootView.findViewById(R.id.tblExpenseReportResults);
            LinearLayout linerLayout = (LinearLayout) rootView.findViewById(R.id.linearLayoutForChartButton);
            linerLayout.removeAllViewsInLayout();
            tblExpenseReportResults.removeAllViewsInLayout();
            tr_head.setBackgroundColor(Color.BLUE);
            tr_head.setLayoutParams(new TableLayout.LayoutParams(
                    TableRow.LayoutParams.MATCH_PARENT,
                    TableRow.LayoutParams.WRAP_CONTENT));


            TextView label_RXNOs = new TextView(getActivity());
            label_RXNOs.setText("RX NO's");
            label_RXNOs.setTextColor(Color.WHITE);
            tr_head.addView(label_RXNOs);

            TextView label_RefillDate = new TextView(getActivity());
            label_RefillDate.setText("RefillDate");
            label_RefillDate.setTextColor(Color.WHITE);
            tr_head.addView(label_RefillDate);

            TextView label_RefillExpenses = new TextView(getActivity());
            label_RefillExpenses.setText("RefillCost");
            label_RefillExpenses.setTextColor(Color.WHITE);
            tr_head.addView(label_RefillExpenses);

            TextView label_PlanName = new TextView(getActivity());
            label_PlanName.setText("PlanName");
            label_PlanName.setTextColor(Color.WHITE);
            tr_head.addView(label_PlanName);

            TextView label_PlanCover = new TextView(getActivity());
            label_PlanCover.setText("PlanCover");
            label_PlanCover.setTextColor(Color.WHITE);
            tr_head.addView(label_PlanCover);

            TextView label_PlanCoPay = new TextView(getActivity());
            label_PlanCoPay.setText("PlanCoPay");
            label_PlanCoPay.setTextColor(Color.WHITE);
            tr_head.addView(label_PlanCoPay);

            tblExpenseReportResults.addView(tr_head, new TableLayout.LayoutParams(
                    TableLayout.LayoutParams.MATCH_PARENT,
                    TableLayout.LayoutParams.WRAP_CONTENT));


            DateFormat formatter = new SimpleDateFormat("MM-dd-yyyy");
            Date parsedFromDOB = formatter.parse(fromDate);
            Date parsedToDOB = formatter.parse(toDate);

            /*

            DateFormat formatter = new SimpleDateFormat("MM-dd-yyyy");
            Date parsedFromDOB = formatter.parse("08-01-2014");
            Date parsedToDOB = formatter.parse("08-09-2014");

            */

            // First step is to retrieve the RX NO's from User_Profile collection
            DBCollection userProfile = MongoConnect.getCollection(MongoConnect.dbCollections.user_profile);
            BasicDBObject whereQuery = new BasicDBObject();
            whereQuery.put("_id", new ObjectId(ARG_USER_ID));
            DBCursor userProfileCursor = userProfile.find(whereQuery);
            // We shall advance the cursor to next position as only the logged in user can access these screen hence there would be a document for every user in the collection
            DBObject dbObject = userProfileCursor.next();
            BasicDBList rxList = (BasicDBList) dbObject.get("Rx");
            for (int i = 0; i < rxList.size(); i++) {
                String rxNumber = rxList.get(i).toString();
                // Second step is to retrieve the refills from Prescription collection
                DBCollection prescription = MongoConnect.getCollection(MongoConnect.dbCollections.prescription);
                BasicDBObject rxQuery = new BasicDBObject();
                rxQuery.put("_id", rxNumber);
                DBCursor rxCursor = prescription.find(rxQuery);

                while (rxCursor.hasNext()) {
                    DBObject rxDBObject = rxCursor.next();
                    BasicDBList refillList = (BasicDBList) rxDBObject.get("refills");

                    // There might be few RX's for which no prescription refill would have happened. So adding try catch block to handle it.
                    try {
                        for (int j = 0; j < refillList.size(); j++) {
                            String refillID = refillList.get(j).toString();

                            // Third step is to retrieve all the refill expenses from Refill collection
                            DBCollection refillCollection = MongoConnect.getCollection(MongoConnect.dbCollections.refill);
                            BasicDBObject refillExpensesQuery = new BasicDBObject();
                            List<BasicDBObject> refillExpensesQueryListDBObject = new ArrayList<BasicDBObject>();
                            refillExpensesQueryListDBObject.add(new BasicDBObject("_id", new ObjectId(refillID)));
                            refillExpensesQueryListDBObject.add(new BasicDBObject("refill_date", new BasicDBObject("$gte", parsedFromDOB).append("$lte", parsedToDOB)));
                            refillExpensesQuery.put("$and", refillExpensesQueryListDBObject);
                            DBCursor refillExpensesCursor = refillCollection.find(refillExpensesQuery);

                            while (refillExpensesCursor.hasNext()) {
                                DBObject refillExpensesDBObject = refillExpensesCursor.next();

                                String rawRefillDate = refillExpensesDBObject.get("refill_date").toString();
                                String refillDate = rawRefillDate.substring(0, 10);

                                String refillTotalCost = refillExpensesDBObject.get("total_cost").toString();

                                DBObject insuranceDBObject = (DBObject) refillExpensesDBObject.get("insurance_details");
                                String planID = insuranceDBObject.get("plan_object_id").toString();
                                String planCover = insuranceDBObject.get("plan_cover").toString();
                                String planCoPay = insuranceDBObject.get("plan_copay").toString();

                                DBCollection healthPlanCollection = MongoConnect.getCollection(MongoConnect.dbCollections.health_plan);
                                BasicDBObject healthPlanQuery = new BasicDBObject("_id", new ObjectId(planID));
                                DBCursor healthPlanCursor = healthPlanCollection.find(healthPlanQuery);
                                if (healthPlanCursor.hasNext()) {
                                    DBObject healthPlanDBObject = healthPlanCursor.next();
                                    String planName = healthPlanDBObject.get("issuer_name").toString();

                                    // Create the table row
                                    TableRow tr = new TableRow(getActivity());
                                    tr.setLayoutParams(new TableRow.LayoutParams(
                                            TableRow.LayoutParams.WRAP_CONTENT,
                                            TableRow.LayoutParams.WRAP_CONTENT));

                                    // Create a TextView to add RX Numbers
                                    TextView txtViewRXNOsTableResults = new TextView(getActivity());
                                    txtViewRXNOsTableResults.setText(rxNumber);
                                    txtViewRXNOsTableResults.setPadding(2, 0, 5, 0);
                                    txtViewRXNOsTableResults.setTextColor(Color.BLACK);
                                    tr.addView(txtViewRXNOsTableResults);

                                    // Create a TextView to add RefillDate
                                    TextView txtViewRefillDateTableResults = new TextView(getActivity());
                                    txtViewRefillDateTableResults.setText(refillDate);
                                    txtViewRefillDateTableResults.setPadding(2, 0, 5, 0);
                                    txtViewRefillDateTableResults.setTextColor(Color.BLACK);
                                    tr.addView(txtViewRefillDateTableResults);

                                    // Create a TextView to add RefillTotalCosts
                                    TextView txtViewRefillExpensesTableResults = new TextView(getActivity());
                                    txtViewRefillExpensesTableResults.setText(refillTotalCost);
                                    txtViewRefillExpensesTableResults.setPadding(2, 0, 5, 0);
                                    txtViewRefillExpensesTableResults.setTextColor(Color.BLACK);
                                    tr.addView(txtViewRefillExpensesTableResults);

                                    // Create a TextView to add PlanName
                                    TextView txtViewRefillPlanNameTableResults = new TextView(getActivity());
                                    txtViewRefillPlanNameTableResults.setText(planName);
                                    txtViewRefillPlanNameTableResults.setPadding(2, 0, 5, 0);
                                    txtViewRefillPlanNameTableResults.setTextColor(Color.BLACK);
                                    tr.addView(txtViewRefillPlanNameTableResults);

                                    // Create a TextView to add PlanCoverageAmount
                                    TextView txtViewRefillPlanCoverTableResults = new TextView(getActivity());
                                    txtViewRefillPlanCoverTableResults.setText(planCover);
                                    txtViewRefillPlanCoverTableResults.setPadding(2, 0, 5, 0);
                                    txtViewRefillPlanCoverTableResults.setTextColor(Color.BLACK);
                                    tr.addView(txtViewRefillPlanCoverTableResults);

                                    // Create a TextView to add PlanCoPay
                                    TextView txtViewRefillPlanCoPayTableResults = new TextView(getActivity());
                                    txtViewRefillPlanCoPayTableResults.setText(planCoPay);
                                    txtViewRefillPlanCoPayTableResults.setPadding(2, 0, 5, 0);
                                    txtViewRefillPlanCoPayTableResults.setTextColor(Color.BLACK);
                                    tr.addView(txtViewRefillPlanCoPayTableResults);

                                    // finally add the table row to the table row
                                    tblExpenseReportResults.addView(tr, new TableLayout.LayoutParams(
                                            TableLayout.LayoutParams.WRAP_CONTENT,
                                            TableLayout.LayoutParams.WRAP_CONTENT));

                                    // Below logic add the rxDetails into Dictionary which is later consumed to draw maps
                                    // If the RX Number has already been encountered then sum up the expenditure values
                                    if (rxNumbersList.contains(rxNumber)) {
                                        double expenseIncurred = Double.parseDouble(refillTotalCost) - Double.parseDouble(planCover);
                                        double expenseIncurredTillNow = rxExpenditureMap.get(rxNumber);
                                        rxExpenditureMap.put(rxNumber, (expenseIncurredTillNow + (double) expenseIncurred));
                                    }
                                    // First time when RX Number is encountered add it to the list with respective values
                                    else {
                                        rxNumbersList.add(rxNumber);
                                        double expenseIncurred = Double.parseDouble(refillTotalCost) - Double.parseDouble(planCover);
                                        rxExpenditureMap.put(rxNumber, (double) expenseIncurred);
                                    }

                                    // Once when this boolean value is set to true, the "Display Pie Chart" button would be displayed
                                    isRXExpenditureExists = true;
                                }
                            }
                        }
                    } catch (Exception ex) {
                    }

                }
            }
            // Once when this boolean value is set to true, the "Display Pie Chart" button would be displayed
            if (isRXExpenditureExists) {
                // Dynamically generate the button and add it to the linear layout.
                // OnClick() would create a pie chart
                Button btnGetChart = new Button(getActivity());
                btnGetChart.setText("Display Pie Chart");
                LayoutParams layoutParams = new LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.WRAP_CONTENT);
                linerLayout.addView(btnGetChart, layoutParams);

                btnGetChart.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        DisplayExpenseReportCharts();
                    }
                });
            }
        } catch (Exception ex) {
            Log.e(TAG, "Exception - " + ex.getMessage());
            Toast.makeText(getActivity(),
                    "Exception - " + ex.getMessage(), Toast.LENGTH_SHORT)
                    .show();
        }
    }

    // Below method is responsible for displaying the expenses incurred for RX in the pie chart
    private void DisplayExpenseReportCharts() {
        try {

            // Pie Chart Section Names
            String[] code = rxNumbersList.toArray(new String[rxNumbersList.size()]);
            // Pie Chart Section Value
            double[] distribution = GetRXExpenditureDataFromMap();
            // Color of each Pie Chart Sections
            int[] colors = {Color.GREEN, Color.YELLOW, Color.MAGENTA, Color.CYAN, Color.RED, Color.BLUE, Color.GRAY, Color.BLACK, Color.DKGRAY};
            // Instantiating CategorySeries to plot Pie Chart
            CategorySeries distributionSeries = new CategorySeries("Rx Expenditure");
            for (int i = 0; i < distribution.length; i++) {
                // Adding a slice with its values and name to the Pie Chart
                distributionSeries.add(code[i], distribution[i]);
            }
            // Instantiating a renderer for the Pie Chart
            DefaultRenderer defaultRenderer = new DefaultRenderer();
            for (int i = 0; i < distribution.length; i++) {
                SimpleSeriesRenderer seriesRenderer = new SimpleSeriesRenderer();
                seriesRenderer.setColor(colors[i % 10]);
                seriesRenderer.setDisplayChartValues(true);
                // Adding a renderer for a slice
                defaultRenderer.addSeriesRenderer(seriesRenderer);
            }
            defaultRenderer.setChartTitle("Rx Expenditure Distribution");
            defaultRenderer.setChartTitleTextSize(50);
            defaultRenderer.setZoomButtonsVisible(true);

            // Creating an intent to plot bar chart
            Intent intent = ChartFactory.getPieChartIntent(getActivity(), distributionSeries, defaultRenderer, "Rx Expenditure");
            // Start PieChart Activity
            startActivity(intent);

        } catch (Exception ex) {
            Log.e(TAG, "Exception - " + ex.getMessage());
            Toast.makeText(getActivity(),
                    "Exception - " + ex.getMessage(), Toast.LENGTH_SHORT)
                    .show();
        }
    }

    // Below method scans the value from Map and returns the expenditure incurred
    private double[] GetRXExpenditureDataFromMap() {
        double[] rxExpenditureArray = new double[rxNumbersList.size()];
        try {
            int i = 0;
            for (Map.Entry<String, Double> rxDetails : rxExpenditureMap.entrySet()) {
                rxExpenditureArray[i] = rxDetails.getValue();
                i++;
            }
        } catch (Exception ex) {
            Log.e(TAG, "Exception - " + ex.getMessage());
            Toast.makeText(getActivity(),
                    "Exception - " + ex.getMessage(), Toast.LENGTH_SHORT)
                    .show();
        } finally {
            return rxExpenditureArray;
        }
    }

}