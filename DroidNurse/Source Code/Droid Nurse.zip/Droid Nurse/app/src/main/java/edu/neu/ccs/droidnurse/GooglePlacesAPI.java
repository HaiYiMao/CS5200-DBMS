package edu.neu.ccs.droidnurse;

import android.util.Log;
import org.apache.http.HttpResponse;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.DefaultHttpClient;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;

/**
 * Created by Venkatesh on 03/08/14.
 */

public class GooglePlacesAPI {

    //https://maps.googleapis.com/maps/api/place/nearbysearch/json?location=42.339243,-71.090078&radius=2500&types=hospital&key=AIzaSyBTaZZ1XoMpHl3DY3uY34_s8idVfucDgtM
    private final String baseAPIURL = "https://maps.googleapis.com/maps/api/place/nearbysearch/json?location=";
    // Radius distance is mentioned in meters
    private final String radiusDistance = "&radius=3219";
    private final String hospitalType = "&types=hospital";
    private final String pharmacyType = "&types=pharmacy";
    private static final String GooglePlacesAPIKey = "&key=AIzaSyBTaZZ1XoMpHl3DY3uY34_s8idVfucDgtM";
    private static final String TAG = "GooglePlacesAPI";


    // Below method is responsible retrieving the Hospital details from GooglePlaces API
    public String GetHospitalDetailsFromGooglePlacesAPI(double latitude, double longitude) {
        String jsonHospitalData = "";
        try {
            String baseURL = baseAPIURL+ String.valueOf(latitude).trim() +","+String.valueOf(longitude).trim()+ radiusDistance + hospitalType + GooglePlacesAPIKey;

            // create HttpClient
            HttpClient httpclient = new DefaultHttpClient();

            // make GET request to the given URL
            HttpResponse httpResponse = httpclient.execute(new HttpGet(baseURL));

            // receive response as inputStream
            InputStream inputStream = httpResponse.getEntity().getContent();

            // convert inputstream to string
            if (inputStream != null) {
                jsonHospitalData = ConvertInputStreamToString(inputStream);
            }

        } catch (Exception ex) {
            Log.e(TAG, "Exception - " + ex.getMessage());
        } finally {
            return jsonHospitalData;
        }
    }


    // Below method is responsible retrieving the Pharmacy details from GooglePlaces API
    public String GetPharmacyDetailsFromGooglePlacesAPI(double latitude, double longitude) {
        String jsonPharmacyData = "";
        try {
            String baseURL = baseAPIURL+ String.valueOf(latitude).trim() +","+String.valueOf(longitude).trim()+ radiusDistance + pharmacyType + GooglePlacesAPIKey;

            // create HttpClient
            HttpClient httpclient = new DefaultHttpClient();

            // make GET request to the given URL
            HttpResponse httpResponse = httpclient.execute(new HttpGet(baseURL));

            // receive response as inputStream
            InputStream inputStream = httpResponse.getEntity().getContent();

            // convert inputstream to string
            if (inputStream != null) {
                jsonPharmacyData = ConvertInputStreamToString(inputStream);
            }

        } catch (Exception ex) {
            Log.e(TAG, "Exception - " + ex.getMessage());
        } finally {
            return jsonPharmacyData;
        }
    }


    // Below method converts the input stream of data retrieved from the rest api and then converts to String format.
    private String ConvertInputStreamToString(InputStream inputStream) {
        String result = "";
        try {
            BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(inputStream));
            String line = "";
            while ((line = bufferedReader.readLine()) != null)
                result += line;

            inputStream.close();
        } catch (Exception ex) {
            Log.e(TAG, "Exception - " + ex.getMessage());
        } finally {
            return result;
        }
    }



}