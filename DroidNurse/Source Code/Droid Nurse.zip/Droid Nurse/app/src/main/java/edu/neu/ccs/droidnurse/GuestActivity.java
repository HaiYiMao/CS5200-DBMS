package edu.neu.ccs.droidnurse;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.Fragment;
import android.app.FragmentTransaction;
import android.content.Intent;
import android.os.Bundle;
import android.os.StrictMode;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;

import com.mongodb.BasicDBObject;
import com.mongodb.DBCollection;
import com.mongodb.DBCursor;
import com.mongodb.DBObject;

import org.joda.time.DateTime;
import org.joda.time.DateTimeZone;

import java.util.ArrayList;
import java.util.List;



public class GuestActivity extends Activity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        if (android.os.Build.VERSION.SDK_INT > 9) {
            StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy
                    .Builder().permitAll().build();
            StrictMode.setThreadPolicy(policy);
        }

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_guest);
        if (savedInstanceState == null) {
            getFragmentManager().beginTransaction()
                    .add(R.id.container, new PlaceholderFragment())
                    .commit();
        }
    }

    /**
     * A placeholder fragment containing a simple view.
     */
    public static class PlaceholderFragment extends Fragment {

        public PlaceholderFragment() {
        }

        @Override
        public View onCreateView(LayoutInflater inflater, ViewGroup container,
                                 Bundle savedInstanceState) {
            View rootView = inflater.inflate(R.layout.fragment_guest_login, container, false);
            return rootView;
        }
    }

    public void navigateToRegister(View v) {
        Fragment frag = new GuestRegisterFragment();
        FragmentTransaction ft = getFragmentManager().beginTransaction();
        ft.replace(R.id.container, frag);
        ft.setTransition(FragmentTransaction.TRANSIT_FRAGMENT_FADE);
        ft.addToBackStack(null);
        ft.commit();
    }


    public void validateLogin(View view) {
        EditText username, password;
        String input_user = "", input_pass = "";

        // Get the controls from the screen
        username = (EditText) findViewById(R.id.username);
        password = (EditText) findViewById(R.id.password);

        // Get the values from the controls
        input_user = username.getText().toString();
        input_pass = password.getText().toString();

        try {

            DBCollection user_profile = MongoConnect.getCollection(MongoConnect.dbCollections.user_profile);
            BasicDBObject andQuery = new BasicDBObject();
            List<BasicDBObject> obj = new ArrayList<BasicDBObject>();
            obj.add(new BasicDBObject("username", input_user));
            obj.add(new BasicDBObject("password", input_pass));
            obj.add(new BasicDBObject("isActive", true));
            andQuery.put("$and", obj);


            DBCursor cursor = user_profile.find(andQuery);

            // If the result contains a valid user_id, assume login is successful
            if (cursor.hasNext()) {
                DBObject DBO = cursor.next();
                Intent intent = new Intent(this, MainActivity.class);

                intent.putExtra("USER_ID", DBO.get("_id").toString());

                intent.putExtra("FIRST_NAME", DBO.get("first_name").toString());

                DateTime createDateTime = new DateTime(DBO.get("DOB"), DateTimeZone.forID("EST"));
                intent.putExtra("DOB", createDateTime.toString());

                startActivity(intent);
                finish();
            } else {
                // Display that the login is invalid
                AlertDialog.Builder dlgAlert = new AlertDialog.Builder(this);
                dlgAlert.setMessage("Wrong username/password!\nPlease try again");
                dlgAlert.setTitle("Invalid Credentials");
                dlgAlert.setPositiveButton("OK", null);
                dlgAlert.setCancelable(true);
                dlgAlert.create().show();
            }


        } catch (Exception e) {
            e.printStackTrace();
        }


    }


}
