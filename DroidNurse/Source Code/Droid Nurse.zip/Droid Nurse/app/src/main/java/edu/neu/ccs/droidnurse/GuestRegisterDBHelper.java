package edu.neu.ccs.droidnurse;

import android.util.Log;

import com.mongodb.BasicDBObject;
import com.mongodb.DB;
import com.mongodb.DBCollection;
import com.mongodb.DBCursor;
import com.mongodb.Mongo;
import com.mongodb.MongoURI;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by Venkatesh on 24/07/14.
 */
public class GuestRegisterDBHelper {

    private static final String TAG = "GuestRegisterDBHelper";

    //
    public boolean IsUserIDAvailable(String userName) {
        boolean isIDAvailable = true;
        try {
            DBCollection user_profile = MongoConnect.getCollection(MongoConnect.dbCollections.user_profile);
            BasicDBObject whereQuery = new BasicDBObject();
            whereQuery.put("username", userName);
            DBCursor cursor = user_profile.find(whereQuery);

            // If there exists a results then it indicates that the username / email has already been taken by another user.
            if (cursor.hasNext()) {
                isIDAvailable = false;
            } else {
                isIDAvailable = true;
            }
        } catch (Exception ex) {
            Log.e(TAG, "Exception - " + ex.getMessage());
        } finally {
            return isIDAvailable;
        }
    }

    public void RegisterNewUser(BasicDBObject jsonData) {
        try {
            DBCollection user_profile = MongoConnect.getCollection(MongoConnect.dbCollections.user_profile);
            user_profile.insert(jsonData);
        } catch (Exception ex) {
            Log.e(TAG, "Exception - " + ex.getMessage());
        }

    }
}
