package edu.neu.ccs.droidnurse;

import android.os.Bundle;
import android.app.Fragment;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.Button;
import android.widget.RadioButton;
import android.view.View.OnClickListener;
import com.mongodb.BasicDBObject;
import com.mongodb.DBCollection;
import com.mongodb.DBCursor;
import com.mongodb.DBObject;

import android.widget.Spinner;
import android.widget.ArrayAdapter;
import android.content.Intent;
import android.widget.Toast;

import org.bson.types.ObjectId;
import org.joda.time.DateTime;
import org.joda.time.DateTimeZone;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;


/**
 * A simple {@link Fragment} subclass.
 */
public class GuestRegisterFragment extends Fragment {

    private static final String TAG = "GuestRegisterFragment";

    public GuestRegisterFragment() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {

        View view = inflater.inflate(R.layout.fragment_guest_register, container, false);

        LoadStateSpinnerValues(view);

        Button btnGoBack = (Button) view.findViewById(R.id.back_to_login);
        btnGoBack.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getActivity().getApplication(), GuestActivity.class);
                getActivity().finish();
                startActivity(intent);
            }
        });


        Button btnSignUp = (Button) view.findViewById(R.id.signup);
        btnSignUp.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                EditText txtFirstName, txtMiddleName, txtLastName, txtDOB, txtEmail, txtPhone, txtAddress, txtCity, txtZipCode, txtUserName, txtPassword, txtConfirmPassword;
                RadioButton rbMale;
                Spinner spinnerState;
                String firstName, middleName, lastName, gender, dob, email, phone, address, state, city, zipCode, userName, password, confirmPassword = "";

                // Get the controls from the screen
                txtFirstName = (EditText) getView().findViewById(R.id.fname);
                txtMiddleName = (EditText) getView().findViewById(R.id.mname);
                txtLastName = (EditText) getView().findViewById(R.id.lname);
                rbMale = (RadioButton) getView().findViewById(R.id.genderMale);
                txtDOB = (EditText) getView().findViewById(R.id.dob);
                txtEmail = (EditText) getView().findViewById(R.id.email);
                txtPhone = (EditText) getView().findViewById(R.id.phone);
                txtAddress = (EditText) getView().findViewById(R.id.addr_line);
                spinnerState = (Spinner) getView().findViewById(R.id.spinnerState);
                txtCity = (EditText) getView().findViewById(R.id.city);
                txtZipCode = (EditText) getView().findViewById(R.id.zip);
                txtUserName = (EditText) getView().findViewById(R.id.choose_username);
                txtPassword = (EditText) getView().findViewById(R.id.choose_pass);
                txtConfirmPassword = (EditText) getView().findViewById(R.id.confirm_pass);

                // Get the values from those controls
                firstName = txtFirstName.getText().toString();
                middleName = txtMiddleName.getText().toString();
                lastName = txtLastName.getText().toString();
                if (rbMale.isChecked()) {
                    gender = "male";
                } else {
                    gender = "female";
                }
                dob = txtDOB.getText().toString();
                email = txtEmail.getText().toString();
                phone = txtPhone.getText().toString();
                address = txtAddress.getText().toString();
                state = spinnerState.getSelectedItem().toString();
                city = txtCity.getText().toString();
                zipCode = txtZipCode.getText().toString();
                userName = txtUserName.getText().toString();
                password = txtPassword.getText().toString();
                confirmPassword = txtConfirmPassword.getText().toString();

                // Verify that the fields are not empty
                if ((firstName.length() > 0) && (lastName.length() > 0) && (dob.length() > 0) &&
                        (email.length() > 0) && (phone.length() == 10) && (address.length() > 0) &&
                        (city.length() > 0) && (zipCode.length() >= 5) && (userName.length() > 0) &&
                        (password.length() > 7) && (confirmPassword.length() > 7)) {

                    if (password.equals(confirmPassword)) {
                        GuestRegisterDBHelper grDBHelper = new GuestRegisterDBHelper();
                        boolean isUserIDAvailable = grDBHelper.IsUserIDAvailable(userName);
                        if (isUserIDAvailable) {
                            BasicDBObject document = new BasicDBObject();
                            document.put("first_name", firstName);
                            document.put("middle_name", middleName);
                            document.put("last_name", lastName);
                            document.put("gender", gender);
                            document.put("city", city);
                            document.put("state", state);
                            document.put("zip", zipCode);
                            document.put("email", email);
                            document.put("username", userName);
                            document.put("password", password);
                            document.put("phone", phone);
                            DateFormat formatter = new SimpleDateFormat("MM-dd-yyyy");
                            Date parsedDOB = null;
                            try {
                                parsedDOB = formatter.parse(dob);
                            } catch (ParseException e) {
                                Log.e(TAG, "Exception - " + e.getMessage());
                            }
                            document.put("DOB", parsedDOB);
                            document.put("isActive", true);

                            grDBHelper.RegisterNewUser(document);

                            Toast.makeText(getActivity(),
                                    "Successfully registered !!", Toast.LENGTH_SHORT)
                                    .show();

                            RedirectToHomeScreen(userName, password);

                        } else {
                            //User ID Already Exists
                            Toast.makeText(getActivity(),
                                    "UserName already exists, please try with alternate user names.", Toast.LENGTH_SHORT)
                                    .show();

                        }
                    } else {
                        // Password and ReType password arent matching
                        Toast.makeText(getActivity(),
                                "Passwords do not match.", Toast.LENGTH_SHORT)
                                .show();

                    }
                } else {
                    //  Validation error message (Field Length Empty) has to be displayed to the end user
                    Toast.makeText(getActivity(),
                            "Please do not leave any fields empty.", Toast.LENGTH_SHORT)
                            .show();
                }
            }
        });

        // Inflate the layout for this fragment
        return view;

    }

    // This method is responsible for loading the spinner 'State' with values from the string.xml
    private void LoadStateSpinnerValues(View view) {

        // Populating the State values
        Spinner spinnerState = (Spinner) view.findViewById(R.id.spinnerState);
        ArrayAdapter<CharSequence> stateAdapter = ArrayAdapter.createFromResource(getActivity(),
                R.array.state_array, android.R.layout.simple_spinner_item);
        stateAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinnerState.setAdapter(stateAdapter);

    }

    // This methods is responsible for redirecting the user to home screen after successful registration
    private void RedirectToHomeScreen(String userName, String password) {
        try {
            DBCollection user_profile = MongoConnect.getCollection(MongoConnect.dbCollections.user_profile);
            BasicDBObject andQuery = new BasicDBObject();
            List<BasicDBObject> obj = new ArrayList<BasicDBObject>();
            obj.add(new BasicDBObject("username", userName));
            obj.add(new BasicDBObject("password", password));
            obj.add(new BasicDBObject("isActive", true));
            andQuery.put("$and", obj);
            DBCursor cursor = user_profile.find(andQuery);

            // If the result contains a valid user_id, assume login is successful
            if (cursor.hasNext()) {
                DBObject DBO = cursor.next();
                Intent intent = new Intent(getActivity().getApplication(), MainActivity.class);
                intent.putExtra("USER_ID", DBO.get("_id").toString());
                intent.putExtra("FIRST_NAME", DBO.get("first_name").toString());
                DateTime createDateTime = new DateTime(DBO.get("DOB"), DateTimeZone.forID("EST"));
                intent.putExtra("DOB", createDateTime.toString());
                getActivity().finish();
                startActivity(intent);
            } else {
                Toast.makeText(getActivity(),
                        "Oops, our system encountered some error while logging in. Please try again.", Toast.LENGTH_SHORT)
                        .show();
            }
        } catch (Exception ex) {
            Log.e(TAG, "Exception - " + ex.getMessage());
        }

    }
}