package edu.neu.ccs.droidnurse;

import android.app.Fragment;
import android.app.FragmentManager;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import android.text.Html;
import android.text.method.LinkMovementMethod;

import com.mongodb.BasicDBObject;
import com.mongodb.DBCollection;
import com.mongodb.DBCursor;
import com.mongodb.DBObject;

import org.apache.http.HttpResponse;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.DefaultHttpClient;
import org.bson.types.ObjectId;
import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;

/**
 * Created by Venkatesh on 07/08/14.
 */

public class HealthPlanDetailsAPI extends Fragment {

    private static final String TAG = "HealthPlanDetailsAPI";
        /* Sample URL's

            https://data.healthcare.gov/dataset/QHP-Landscape-Individual-Market-Medical/b8in-sz6k

            http://data.healthcare.gov/resource/b8in-sz6k.json?$select=state,county,issuer_name,plan_id_standard_component,plan_marketing_name,plan_type,metal_level,customer_service_phone_number_toll_free,network_url,plan_brochure_url,summary_of_benefits_url,medical_deductible_individual_standard,drug_deductible_individual_standard,medical_deductible_family_standard,drug_deductible_family_standard,medical_maximum_out_of_pocket_individual_standard,drug_maximum_out_of_pocket_individual_standard,medical_maximum_out_of_pocket_family_standard,drug_maximum_out_of_pocket_family_standard,primary_care_physician_standard,specialist_standard,emergency_room_standard,inpatient_facility_standard,inpatient_physician_standard&$where=plan_id_standard_component='16842FL0120044' AND state='FL' AND county='BAY'
        */

    private final String baseAPIURL = "http://data.healthcare.gov/resource/b8in-sz6k.json?$select=state,county,issuer_name,plan_id_standard_component,plan_marketing_name,plan_type,metal_level,customer_service_phone_number_toll_free,network_url,plan_brochure_url,summary_of_benefits_url,medical_deductible_individual_standard,drug_deductible_individual_standard,medical_deductible_family_standard,drug_deductible_family_standard,medical_maximum_out_of_pocket_individual_standard,drug_maximum_out_of_pocket_individual_standard,medical_maximum_out_of_pocket_family_standard,drug_maximum_out_of_pocket_family_standard,primary_care_physician_standard,specialist_standard,emergency_room_standard,inpatient_facility_standard,inpatient_physician_standard&$where=plan_id_standard_component=";
    private final String baseAPIState = "%20AND%20state=";
    private final String baseAPICounty = "%20AND%20county=";
    private String healthPlanID = "";
    private String state = "";
    private String county = "";
    View rootView;

    // Bundle Arguments
    public String ARG_USER_ID;
    public String HEALTHPLANOBJECTID;


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        try {

            GetBundleArguments();
            rootView = inflater.inflate(R.layout.fragment_health_plan_details_api, container, false);

            GetStateAndCountyDetailsFromDB(HEALTHPLANOBJECTID);
            String jsonData = GetJSONHealthPlanDetailsFromAPI(healthPlanID, state, county);

            DisplayJSONData(jsonData);

            Button btnBackToMyHealthPlans = (Button) rootView.findViewById(R.id.btnHPDBackToResults);
            btnBackToMyHealthPlans.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {

                    Fragment planFragment = new PlanFragment();
                    Bundle args = new Bundle();
                    args.putString("USER_ID", ARG_USER_ID);
                    planFragment.setArguments(args);
                    FragmentManager fragmentManager = getFragmentManager();
                    fragmentManager.beginTransaction().replace(R.id.content_frame, planFragment).commit();

                }
            });

        } catch (Exception ex) {
            Log.e(TAG, "Exception - " + ex.getMessage());
        } finally {
            return rootView;
        }
    }


    // Retrieves the bundle arguments which holds data from the previous screens
    private void GetBundleArguments() {
        try {
            ARG_USER_ID = getArguments().getString("USER_ID");
            HEALTHPLANOBJECTID = getArguments().getString("HEALTHPLANOBJECTID");
        } catch (Exception ex) {
            Log.e(TAG, "Exception - " + ex.getMessage());
        }
    }


    // Below method pulls the HealthPlanID, State and County from MongoDB based on the ObjectID obtained from the previous screen MyHealthPlan (PlanFragment)
    private void GetStateAndCountyDetailsFromDB(String healthplanobjectid) {
        try {
            DBCollection user_profile = MongoConnect.getCollection(MongoConnect.dbCollections.health_plan);
            BasicDBObject whereQuery = new BasicDBObject("_id", new ObjectId(healthplanobjectid));
            DBCursor cursor = user_profile.find(whereQuery);
            if (cursor.hasNext()) {
                DBObject dbObject = cursor.next();
                healthPlanID = dbObject.get("Plan_id").toString().trim();
                state = dbObject.get("state").toString().trim();
                county = dbObject.get("city").toString().trim();

                // Removing the blank spaces with %20. If not done then exception occurs while requesting HTTPGet request from the REST API
                healthPlanID = healthPlanID.replace(" ","%20");
                state = state.replace(" ","%20");
                county = county.replace(" ","%20");

            }
        } catch (Exception ex) {
            Log.e(TAG, "Exception - " + ex.getMessage());
            Toast.makeText(getActivity(),
                    "Exception - " + ex.getMessage(), Toast.LENGTH_SHORT)
                    .show();
        }
    }

    // Below method uses HttpGet to receive json data from REST API (Socrata)
    private String GetJSONHealthPlanDetailsFromAPI(String planID, String state, String county) {
        String result = "";
        try {

            String framedAPIURL = baseAPIURL + "'" + planID + "'" + baseAPIState + "'" + state + "'" + baseAPICounty + "'" + county + "'";
            //String framedAPIURL = "http://data.healthcare.gov/resource/b8in-sz6k.json?$select=state,county,issuer_name,plan_id_standard_component,plan_marketing_name,plan_type,metal_level,customer_service_phone_number_toll_free,network_url,plan_brochure_url,summary_of_benefits_url,medical_deductible_individual_standard,drug_deductible_individual_standard,medical_deductible_family_standard,drug_deductible_family_standard,medical_maximum_out_of_pocket_individual_standard,drug_maximum_out_of_pocket_individual_standard,medical_maximum_out_of_pocket_family_standard,drug_maximum_out_of_pocket_family_standard,primary_care_physician_standard,specialist_standard,emergency_room_standard,inpatient_facility_standard,inpatient_physician_standard&$where=plan_id_standard_component='16842FL0120044'%20AND%20state='FL'%20AND%20county='BAY'";

            // create HttpClient
            HttpClient httpclient = new DefaultHttpClient();

            // make GET request to the given URL
            HttpResponse httpResponse = httpclient.execute(new HttpGet(framedAPIURL));

            // receive response as inputStream
            InputStream inputStream = httpResponse.getEntity().getContent();

            // convert input stream to string
            if (inputStream != null) {
                result = convertInputStreamToString(inputStream);
            } else {
                Toast.makeText(getActivity(),
                        "Oops, unable to fetch data from data.healthcare.gov Socrata API.", Toast.LENGTH_SHORT)
                        .show();
            }

        } catch (Exception ex) {
            Log.e(TAG, "Exception - " + ex.getMessage());
            Toast.makeText(getActivity(),
                    "Exception - " + ex.getMessage(), Toast.LENGTH_LONG)
                    .show();
        } finally {
            return result;
        }
    }

    // Below method converts the input stream of data retrieved from the rest api and then converts to String format.
    private String convertInputStreamToString(InputStream inputStream) {
        String result = "";
        try {
            BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(inputStream));
            String line = "";
            while ((line = bufferedReader.readLine()) != null)
                result += line;

            inputStream.close();
        } catch (Exception ex) {
            Log.e(TAG, "Exception - " + ex.getMessage());
            Toast.makeText(getActivity(),
                    "Exception - " + ex.getMessage(), Toast.LENGTH_LONG)
                    .show();
        } finally {
            return result;
        }
    }

    // Below method parses the json data which was retrieved from rest api and then displays the appropriate value in the front end
    private void DisplayJSONData(String jsonData) {
        try {
            EditText txtHPDPlanType = (EditText) rootView.findViewById(R.id.txtHPDPlanType);
            EditText txtHPDPlanID = (EditText) rootView.findViewById(R.id.txtHPDPlanID);
            EditText txtHPDPlanName = (EditText) rootView.findViewById(R.id.txtHPDPlanName);
            EditText txtHPDIssuerName = (EditText) rootView.findViewById(R.id.txtHPDIssuerName);
            EditText txtHPDCustomerCarePhone = (EditText) rootView.findViewById(R.id.txtHPDCustomerCarePhone);
            TextView txtViewHPDNetworkURL = (TextView) rootView.findViewById(R.id.txtHPDNetworkURL);
            TextView txtViewHPDPlanBrochureURL = (TextView) rootView.findViewById(R.id.txtHPDPlanBrochureURL);
            TextView txtViewHPDSummaryBenefitsURL = (TextView) rootView.findViewById(R.id.txtHPDSummaryBenefitsURL);
            TextView txtViewHPDPrimaryCarePhysician = (TextView) rootView.findViewById(R.id.txtHPDPrimaryCarePhysician);

            // Individuals
            EditText txtHPDMedicalDeductibleIndividual = (EditText) rootView.findViewById(R.id.txtHPDMedicalDeductibleIndividual);
            EditText txtHPDDrugDeductibleIndividual = (EditText) rootView.findViewById(R.id.txtHPDDrugDeductibleIndividual);
            EditText txtHPDMedicalMaxOOPIndividual = (EditText) rootView.findViewById(R.id.txtHPDMedicalMaxOOPIndividual);
            EditText txtHPDDrugMaxOOPIndividual = (EditText) rootView.findViewById(R.id.txtHPDDrugMaxOOPIndividual);

            // Family
            EditText txtHPDMedicalDeductibleFamily = (EditText) rootView.findViewById(R.id.txtHPDMedicalDeductibleFamily);
            EditText txtHPDDrugDeductibleFamily = (EditText) rootView.findViewById(R.id.txtHPDDrugDeductibleFamily);
            EditText txtHPDMedicalMaxOOPFamily = (EditText) rootView.findViewById(R.id.txtHPDMedicalMaxOOPFamily);
            EditText txtHPDDrugMaxOOPFamily = (EditText) rootView.findViewById(R.id.txtHPDDrugMaxOOPFamily);

            EditText txtHPDSpecialist = (EditText) rootView.findViewById(R.id.txtHPDSpecialist);
            EditText txtHPDEmergencyRoom = (EditText) rootView.findViewById(R.id.txtHPDEmergencyRoom);
            EditText txtHPDInpatientFacility = (EditText) rootView.findViewById(R.id.txtHPDInpatientFacility);
            EditText txtHPDInpatientPhysician = (EditText) rootView.findViewById(R.id.txtHPDInpatientPhysician);

            // Parsing the JSON Data to retrieve the appropriate values
            JSONArray jsonArray = new JSONArray(jsonData);
            JSONObject jsonObject = jsonArray.getJSONObject(0);
            txtHPDPlanType.setText(jsonObject.getString("plan_type"));
            txtHPDPlanID.setText(jsonObject.getString("plan_id_standard_component"));
            txtHPDPlanName.setText(jsonObject.getString("plan_marketing_name"));

            txtHPDIssuerName.setText(jsonObject.getString("issuer_name"));
            txtHPDCustomerCarePhone.setText(jsonObject.getString("customer_service_phone_number_toll_free"));

            JSONObject jsonObjNetworkURL = jsonObject.getJSONObject("network_url");
            String urlFramer = "<a href='"+ jsonObjNetworkURL.getString("url") +"'> Click Me </a>";
            txtViewHPDNetworkURL.setText(Html.fromHtml(urlFramer));
            txtViewHPDNetworkURL.setMovementMethod(LinkMovementMethod.getInstance());

            JSONObject jsonObjPlanBrochureURL = jsonObject.getJSONObject("plan_brochure_url");
            urlFramer = "<a href='"+ jsonObjPlanBrochureURL.getString("url") +"'> Click Me </a>";
            txtViewHPDPlanBrochureURL.setText(Html.fromHtml(urlFramer));
            txtViewHPDPlanBrochureURL.setMovementMethod(LinkMovementMethod.getInstance());

            JSONObject jsonObjSummaryBenefitsURL = jsonObject.getJSONObject("summary_of_benefits_url");
            urlFramer = "<a href='"+ jsonObjSummaryBenefitsURL.getString("url") +"'> Click Me </a>";
            txtViewHPDSummaryBenefitsURL.setText(Html.fromHtml(urlFramer));
            txtViewHPDSummaryBenefitsURL.setMovementMethod(LinkMovementMethod.getInstance());

            txtViewHPDPrimaryCarePhysician.setText(jsonObject.getString("primary_care_physician_standard"));

            // Individuals
            txtHPDMedicalDeductibleIndividual.setText(jsonObject.getString("medical_deductible_individual_standard"));
            txtHPDDrugDeductibleIndividual.setText(jsonObject.getString("drug_deductible_individual_standard"));
            txtHPDMedicalMaxOOPIndividual.setText(jsonObject.getString("medical_maximum_out_of_pocket_individual_standard"));
            txtHPDDrugMaxOOPIndividual.setText(jsonObject.getString("drug_maximum_out_of_pocket_individual_standard"));

            // Family
            txtHPDMedicalDeductibleFamily.setText(jsonObject.getString("medical_deductible_family_standard"));
            txtHPDDrugDeductibleFamily.setText(jsonObject.getString("drug_deductible_family_standard"));
            txtHPDMedicalMaxOOPFamily.setText(jsonObject.getString("medical_maximum_out_of_pocket_family_standard"));
            txtHPDDrugMaxOOPFamily.setText(jsonObject.getString("drug_maximum_out_of_pocket_family_standard"));

            txtHPDSpecialist.setText(jsonObject.getString("specialist_standard"));
            txtHPDEmergencyRoom.setText(jsonObject.getString("emergency_room_standard"));
            txtHPDInpatientFacility.setText(jsonObject.getString("inpatient_facility_standard"));
            txtHPDInpatientPhysician.setText(jsonObject.getString("inpatient_physician_standard"));


            // Making the fields as read only
            txtHPDPlanType.setEnabled(false);
            txtHPDPlanID.setEnabled(false);
            txtHPDPlanName.setEnabled(false);
            txtHPDIssuerName.setEnabled(false);
            txtHPDCustomerCarePhone.setEnabled(false);

            /*
                We are not disabling the control as URL needs to be clicked for further details
            txtViewHPDNetworkURL.setEnabled(false);
            txtViewHPDPlanBrochureURL.setEnabled(false);
            txtViewHPDSummaryBenefitsURL.setEnabled(false);
            */

            txtViewHPDPrimaryCarePhysician.setEnabled(false);

            // Individuals
            txtHPDMedicalDeductibleIndividual.setEnabled(false);
            txtHPDDrugDeductibleIndividual.setEnabled(false);
            txtHPDMedicalMaxOOPIndividual.setEnabled(false);
            txtHPDDrugMaxOOPIndividual.setEnabled(false);

            // Family
            txtHPDMedicalDeductibleFamily.setEnabled(false);
            txtHPDDrugDeductibleFamily.setEnabled(false);
            txtHPDMedicalMaxOOPFamily.setEnabled(false);
            txtHPDDrugMaxOOPFamily.setEnabled(false);

            txtHPDSpecialist.setEnabled(false);
            txtHPDEmergencyRoom.setEnabled(false);
            txtHPDInpatientFacility.setEnabled(false);
            txtHPDInpatientPhysician.setEnabled(false);

        } catch (Exception ex) {
            Log.e(TAG, "Exception - " + ex.getMessage());
            Toast.makeText(getActivity(),
                    "Exception - " + ex.getMessage(), Toast.LENGTH_SHORT)
                    .show();
        }
    }

}