package edu.neu.ccs.droidnurse;


import android.app.AlertDialog;
import android.app.DatePickerDialog;
import android.app.FragmentManager;
import android.os.Bundle;
import android.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;

import com.mongodb.BasicDBObject;
import com.mongodb.DBCollection;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;



/**
 * A simple {@link Fragment} subclass.
 */
public class HealthReportFragment extends Fragment {

    public String ARG_USER_ID = "";
    public int spinner_pos = 0;

    public int reportCode = 20;
    public int UOMCode = 30;

    public HealthReportFragment() {
        // Required empty public constructor
    }


    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {

        ARG_USER_ID = getArguments().getString("USER_ID");

        View v = inflater.inflate(R.layout.fragment_health_report, container, false);

        Button setDateBtn = (Button) v.findViewById(R.id.set_date_btn);
        setDateBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                int mYear, mMonth, mDay;
                // Process to get Current Date
                final Calendar c = Calendar.getInstance();
                //final TextView txtDate = (TextView)v.findViewById(R.id.date_lbl);

                mYear = c.get(Calendar.YEAR);
                mMonth = c.get(Calendar.MONTH);
                mDay = c.get(Calendar.DAY_OF_MONTH);

                // Launch Date Picker Dialog
                DatePickerDialog dpd = new DatePickerDialog(getActivity(),
                        new DatePickerDialog.OnDateSetListener() {

                            @Override
                            public void onDateSet(DatePicker view, int year,
                                                  int monthOfYear, int dayOfMonth) {

                                TextView txtDate = (TextView) getActivity().findViewById(R.id.date_lbl);
                                // Display Selected date
                                txtDate.setText(dayOfMonth + "-"
                                        + (monthOfYear + 1) + "-" + year);

                            }

                        }, mYear, mMonth, mDay
                );
                dpd.getDatePicker().setMaxDate(new Date().getTime());
                dpd.show();
            }
        });


        Spinner spinner = (Spinner) v.findViewById(R.id.health_report_spinner);
// Create an ArrayAdapter using the string array and a default spinner layout
        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(this.getActivity(),
                R.array.report_array, android.R.layout.simple_spinner_item);
// Specify the layout to use when the list of choices appears
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
// Apply the adapter to the spinner
        spinner.setAdapter(adapter);

        spinner.setOnItemSelectedListener(
                new AdapterView.OnItemSelectedListener()

                {
                    @Override
                    public void onItemSelected(AdapterView<?> parent, View view,
                                               int pos, long id) {
                        // An item was selected. You can retrieve the selected item using
                        TextView UOM = (TextView) getActivity().findViewById(R.id.UOM);

                        switch (pos) {
                            case 0:
                                UOM.setText("mg/dL");
                                reportCode = 20;
                                UOMCode = 30;
                                break;
                            case 1:
                                UOM.setText("cms");
                                reportCode = 21;
                                UOMCode = 31;
                                break;
                            case 2:
                                UOM.setText("lbs");
                                reportCode = 22;
                                UOMCode = 32;
                                break;
                        }

                        // Update Spinner_pos for use when history button is clicked
                        spinner_pos = pos;
                    }

                    @Override
                    public void onNothingSelected(AdapterView<?> parent) {
                        // Another interface callback
                    }
                }
        );


        // Listener for record_reading_btn
        Button button = (Button) v.findViewById(R.id.record_reading_btn);
        button.setOnClickListener(new View.OnClickListener() {

            public void saveReading() {

                boolean result;

                EditText reading = (EditText) getActivity().findViewById(R.id.report_reading);
                TextView readingDate = (TextView) getActivity().findViewById(R.id.date_lbl);

                String selectedDateString = readingDate.getText().toString();

                if (reading.getText().length() >= 1 || readingDate.getText().length() >= 1) {

                    double readingValue = Double.parseDouble(reading.getText().toString());

                    result = saveReportToDB(readingValue, reportCode, UOMCode, selectedDateString);

                    if (result) {
                        //
                        AlertDialog.Builder dlgAlert = new AlertDialog.Builder(getActivity());
                        dlgAlert.setMessage("Report saved Successfully");
                        dlgAlert.setTitle("Success!");
                        dlgAlert.setPositiveButton("OK", null);
                        dlgAlert.setCancelable(true);
                        dlgAlert.create().show();

                    } else {
                        AlertDialog.Builder dlgAlert = new AlertDialog.Builder(getActivity());
                        dlgAlert.setMessage("An error occurred while saving! Please try again.");
                        dlgAlert.setTitle("Error");
                        dlgAlert.setPositiveButton("OK", null);
                        dlgAlert.setCancelable(true);
                        dlgAlert.create().show();
                    }

                } else {

                    AlertDialog.Builder dlgAlert = new AlertDialog.Builder(getActivity());
                    dlgAlert.setMessage("Date & Reading fields cannot be empty!");
                    dlgAlert.setTitle("Error");
                    dlgAlert.setPositiveButton("OK", null);
                    dlgAlert.setCancelable(true);
                    dlgAlert.create().show();
                }

            }

            @Override
            public void onClick(View v) {
                saveReading();
            }

        });


        // Listener for view_report_history_btn

        Button viewHistoryBtn = (Button) v.findViewById(R.id.show_report_history_btn);
        viewHistoryBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Fragment hrHistory = new HealthReportHistoryFragment();
                Bundle args = new Bundle();
                args.putString("USER_ID", ARG_USER_ID);
                args.putInt("REPORT_CODE", reportCode);
                args.putInt("REPORT_UOM_CODE", UOMCode);
                hrHistory.setArguments(args);
                FragmentManager fragmentManager = getFragmentManager();
                fragmentManager.beginTransaction().replace(R.id.content_frame, hrHistory).commit();
            }
        });


        return v;
    }


    public boolean saveReportToDB(double reportValue, int reportCode, int reportUOMCode, String reportDate) {

        try {

            DateFormat formatter = new SimpleDateFormat("dd-MM-yyyy");
            Date selectedDate = formatter.parse(reportDate);

            DBCollection user_report = MongoConnect.getCollection(MongoConnect.dbCollections.user_report);

            BasicDBObject doc = new BasicDBObject("user_id", ARG_USER_ID)
                    .append("report_code", reportCode)
                    .append("report_UOM", reportUOMCode)
                    .append("report_value", reportValue)
                    .append("report_time", selectedDate);
            user_report.insert(doc);

            return true;
        } catch (Exception e) {
            return false;
        }
    }

}