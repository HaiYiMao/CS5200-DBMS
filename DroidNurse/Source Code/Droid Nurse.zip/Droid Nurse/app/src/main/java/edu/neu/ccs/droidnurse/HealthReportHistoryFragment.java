package edu.neu.ccs.droidnurse;

import android.app.FragmentManager;
import android.graphics.Color;
import android.os.Bundle;
import android.app.Fragment;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TableLayout;
import android.widget.TableRow;
import android.widget.TextView;
import android.widget.Toast;

import org.bson.types.ObjectId;
import com.mongodb.BasicDBObject;
import com.mongodb.DBCollection;
import com.mongodb.DBCursor;
import com.mongodb.DBObject;

import org.joda.time.DateTime;
import org.joda.time.DateTimeZone;

import java.util.ArrayList;
import java.util.List;

import com.jjoe64.graphview.GraphView;
import com.jjoe64.graphview.LineGraphView;
import com.jjoe64.graphview.GraphViewSeries;
import com.jjoe64.graphview.GraphView.GraphViewData;


/**
 * Created by Venkatesh on 31/07/14.
 */

public class HealthReportHistoryFragment extends Fragment {

    private static final String TAG = "HealthReportHistoryFragment";
    public String USER_ID;
    public int reportCode;
    public int UOMCode;
    public ArrayList<String> _idList = new ArrayList<String>();
    View v;

    // Below variables hold the values of x and y axis in the graph
    public String reportTitle = "Health Reports : ";
    public String report_type = "";
    public List<String> graphXAxis = new ArrayList<String>();
    public List<String> graphYAxis = new ArrayList<String>();

    public HealthReportHistoryFragment() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        String UOM = "";
        v = inflater.inflate(R.layout.fragment_health_report_history, container, false);

        USER_ID = getArguments().getString("USER_ID");
        reportCode = getArguments().getInt("REPORT_CODE");
        UOMCode = getArguments().getInt("REPORT_UOM_CODE");

        DBCollection code = MongoConnect.getCollection(MongoConnect.dbCollections.code);

        // Below logic is to fetch report type from code collection based on the report id
        BasicDBObject reportMeaningTextQuery = new BasicDBObject();
        reportMeaningTextQuery.put("_id", reportCode);
        DBCursor reportMeaningTextCursor = code.find(reportMeaningTextQuery);
        if (reportMeaningTextCursor.hasNext()) {
            DBObject dbObject = reportMeaningTextCursor.next();
            report_type = dbObject.get("meaning_text").toString().trim();
            TextView txtViewHealthReportsTitle = (TextView) v.findViewById(R.id.txtViewHealthReportsTitle);
            txtViewHealthReportsTitle.setText(reportTitle + report_type);
        }

        BasicDBObject codeQuery = new BasicDBObject();
        List<BasicDBObject> obj2 = new ArrayList<BasicDBObject>();
        obj2.add(new BasicDBObject("_id", UOMCode));
        obj2.add(new BasicDBObject("isActive", true));
        codeQuery.put("$and", obj2);
        DBCursor codeCursor = code.find(codeQuery);

        if (codeCursor.hasNext()) {
            UOM = codeCursor.next().get("meaning_text").toString();
        }
/////////////////////////////////////////////////////////////////

        DBCollection user_report = MongoConnect.getCollection(MongoConnect.dbCollections.user_report);
        BasicDBObject andQuery = new BasicDBObject();
        List<BasicDBObject> obj = new ArrayList<BasicDBObject>();
        obj.add(new BasicDBObject("user_id", USER_ID));
        obj.add(new BasicDBObject("report_code", reportCode));
        andQuery.put("$and", obj);
        DBCursor cursor = user_report.find(andQuery).sort(new BasicDBObject("report_time", -1));


        // Render the data in the table layout
        int i = 1;
        TableLayout tableLayout = (TableLayout) v.findViewById(R.id.main_table);
        TableRow tr_head = new TableRow(getActivity());
        tr_head.setId(100000 + i);
        tr_head.setBackgroundColor(Color.GRAY);
        tr_head.setPadding(5, 10, 5, 10);
        tr_head.setLayoutParams(new TableLayout.LayoutParams(
                TableRow.LayoutParams.MATCH_PARENT,
                TableRow.LayoutParams.WRAP_CONTENT));


        TextView label_date = new TextView(getActivity());
        label_date.setId(20000000 + i);
        label_date.setText("Date");
        label_date.setTextColor(Color.WHITE);
        label_date.setPadding(5, 5, 5, 5);
        tr_head.addView(label_date);// add the column to the table row here

        TextView label_value = new TextView(getActivity());
        label_value.setId(20000001 + i);// define id that must be unique
        label_value.setText("Value"); // set the text for the header
        label_value.setTextColor(Color.WHITE); // set the color
        label_value.setPadding(5, 5, 5, 5); // set the padding (if required)
        tr_head.addView(label_value); // add the column to the table row here

        TextView label_Delete = new TextView(getActivity());
        label_Delete.setText("Delete");
        label_Delete.setTextColor(Color.WHITE);
        label_Delete.setPadding(5, 5, 5, 5);
        tr_head.addView(label_Delete);

        tableLayout.addView(tr_head, new TableLayout.LayoutParams(
                TableLayout.LayoutParams.MATCH_PARENT,
                TableLayout.LayoutParams.WRAP_CONTENT));

        Integer count = 0;
        while (cursor.hasNext()) {

            DBObject DBO = cursor.next();
            DateTime date = new DateTime(DBO.get("report_time"), DateTimeZone.forID("EST"));
            String value = DBO.get("report_value").toString();
            _idList.add(count, DBO.get("_id").toString());

            // Below variables hold the values of x and y axis in the graph
            graphXAxis.add(date.toString().substring(0, 10));
            graphYAxis.add(value);

            // Create the table row
            TableRow tr = new TableRow(getActivity());
            if (count % 2 != 0) tr.setBackgroundColor(Color.GRAY);
            tr.setId(count);
            tr.setLayoutParams(new TableRow.LayoutParams(
                    TableRow.LayoutParams.MATCH_PARENT,
                    TableRow.LayoutParams.WRAP_CONTENT));

            //Create two columns to add as table data
            // Create a TextView to add date
            TextView labelDATE = new TextView(getActivity());
            labelDATE.setId(count);
            labelDATE.setText(date.toString().substring(0, 10));
            labelDATE.setPadding(2, 0, 5, 0);
            labelDATE.setTextColor(Color.BLACK);
            tr.addView(labelDATE);

            TextView labelValue = new TextView(getActivity());
            labelValue.setId(count);
            labelValue.setText(value.toString() + " " + UOM);
            labelValue.setTextColor(Color.BLACK);
            tr.addView(labelValue);

            final Button deleteButton = new Button(getActivity());
            deleteButton.setId(count);
            deleteButton.setHint(count.toString());
            deleteButton.setText("X");
            deleteButton.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    String buttonID = (deleteButton.getHint().toString());

                    deleteReadingFromDB(buttonID);
                }
            });
            tr.addView(deleteButton);

            // finally add this to the table row
            tableLayout.addView(tr, new TableLayout.LayoutParams(
                    TableLayout.LayoutParams.MATCH_PARENT,
                    TableLayout.LayoutParams.WRAP_CONTENT));

            count++;
        }


        // Listener for Go Back button
        Button goBackBtn = (Button) v.findViewById(R.id.close_button);
        goBackBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Fragment hr = new HealthReportFragment();
                Bundle args = new Bundle();
                args.putString("USER_ID", USER_ID);
                hr.setArguments(args);
                FragmentManager fragmentManager = getFragmentManager();
                fragmentManager.beginTransaction().replace(R.id.content_frame, hr).commit();
            }
        });


        // Draw the Graph
        DrawGraph();

        // Inflate the layout for this fragment
        return v;
    }


    public void deleteReadingFromDB(String id) {
        String _id = "";
        int indexPos = Integer.parseInt(id);
        DBCollection user_report = MongoConnect.getCollection(MongoConnect.dbCollections.user_report);
        BasicDBObject deleteQuery = new BasicDBObject();
        _id = _idList.get(indexPos).toString();
        deleteQuery.put("_id", new ObjectId(_id));
        user_report.remove(deleteQuery);

        Fragment hrHistory = new HealthReportHistoryFragment();
        Bundle args = new Bundle();
        args.putString("USER_ID", USER_ID);
        args.putInt("REPORT_CODE", reportCode);
        args.putInt("REPORT_UOM_CODE", UOMCode);
        hrHistory.setArguments(args);
        FragmentManager fragmentManager = getFragmentManager();
        fragmentManager.beginTransaction().replace(R.id.content_frame, hrHistory).commit();
    }

    // Below method is responsible for drawing graphs for the respective report
    public void DrawGraph() {
        try {
            // X-Axis contents holds the date
            // Y-Axis contents holds the values of the report
            int noOfElementsInGraphs = graphYAxis.size();

            // Graph would be drawn only when there are at least 2 elements
            if (noOfElementsInGraphs > 1) {

                String[] yAxisContents = graphYAxis.toArray(new String[graphXAxis.size()]);

                LinearLayout layoutReportGraph = (LinearLayout) v.findViewById(R.id.layoutReportGraph);
                GraphViewData[] graphViewDatas = new GraphViewData[noOfElementsInGraphs];
                // Below loop is responsible for drawing lines in the graph. Connects the different values.
                for (int i = 0; i < noOfElementsInGraphs; i++) {
                    GraphViewData tempData = new GraphViewData((i + 1), Double.parseDouble(yAxisContents[i]));
                    graphViewDatas[i] = tempData;
                }
                GraphViewSeries graphViewSeries = new GraphViewSeries(graphViewDatas);

                GraphView graphView = new LineGraphView(getActivity(), reportTitle + report_type);
                // Set Horizontal X-Axis with Date Labels
                graphView.setHorizontalLabels(graphXAxis.toArray(new String[graphXAxis.size()]));
                graphView.addSeries(graphViewSeries);
                layoutReportGraph.addView(graphView);
            }

        } catch (Exception ex) {
            Log.e(TAG, "Exception - " + ex.getMessage());
            Toast.makeText(getActivity(),
                    "Exception - " + ex.getMessage(), Toast.LENGTH_SHORT)
                    .show();
        }

    }

}