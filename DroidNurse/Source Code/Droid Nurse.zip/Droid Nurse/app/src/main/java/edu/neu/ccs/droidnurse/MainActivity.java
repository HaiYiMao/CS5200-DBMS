package edu.neu.ccs.droidnurse;
/*
 * Copyright 2013 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

import android.app.Activity;
import android.app.AlarmManager;
import android.app.Fragment;
import android.app.FragmentManager;
import android.app.Notification;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Intent;
import android.content.res.Configuration;
import android.os.Bundle;
import android.support.v4.app.ActionBarDrawerToggle;
import android.support.v4.view.GravityCompat;
import android.support.v4.widget.DrawerLayout;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import org.joda.time.Days;
import org.joda.time.LocalDate;

import java.util.Calendar;


/**
 * This example illustrates a common usage of the DrawerLayout widget
 * in the Android support library.
 * <p/>
 * <p>When a navigation (left) drawer is present, the host activity should detect presses of
 * the action bar's Up affordance as a signal to open and close the navigation drawer. The
 * ActionBarDrawerToggle facilitates this behavior.
 * Items within the drawer should fall into one of two categories:</p>
 * <p/>
 * <ul>
 * <li><strong>View switches</strong>. A view switch follows the same basic policies as
 * list or tab navigation in that a view switch does not create navigation history.
 * This pattern should only be used at the root activity of a task, leaving some form
 * of Up navigation active for activities further down the navigation hierarchy.</li>
 * <li><strong>Selective Up</strong>. The drawer allows the user to choose an alternate
 * parent for Up navigation. This allows a user to jump across an app's navigation
 * hierarchy at will. The application should treat this as it treats Up navigation from
 * a different task, replacing the current task stack using TaskStackBuilder or similar.
 * This is the only form of navigation drawer that should be used outside of the root
 * activity of a task.</li>
 * </ul>
 * <p/>
 * <p>Right side drawers should be used for actions, not navigation. This follows the pattern
 * established by the Action Bar that navigation should be to the left and actions to the right.
 * An action should be an operation performed on the current contents of the window,
 * for example enabling or disabling a data overlay on top of the current content.</p>
 */
public class MainActivity extends Activity {

    private static final String TAG = "MainActivity";
    private PendingIntent pendingIntent;

    private DrawerLayout mDrawerLayout;
    private ListView mDrawerList;
    private ActionBarDrawerToggle mDrawerToggle;
    private CharSequence mDrawerTitle;
    private CharSequence mTitle;
    private String[] mOptions;
    public static String USER_ID = "";
    public static String FIRST_NAME = "";
    public static String DOB = "";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        USER_ID = getIntent().getStringExtra("USER_ID");
        FIRST_NAME = getIntent().getStringExtra("FIRST_NAME");
        DOB = getIntent().getStringExtra("DOB");

        mTitle = mDrawerTitle = getTitle();
        mOptions = getResources().getStringArray(R.array.options);
        mDrawerLayout = (DrawerLayout) findViewById(R.id.drawer_layout);
        mDrawerList = (ListView) findViewById(R.id.left_drawer);

        // set a custom shadow that overlays the main content when the drawer opens
        mDrawerLayout.setDrawerShadow(R.drawable.drawer_shadow, GravityCompat.START);
        // set up the drawer's list view with items and click listener
        mDrawerList.setAdapter(new ArrayAdapter<String>(this,
                R.layout.drawer_list_item, mOptions));
        mDrawerList.setOnItemClickListener(new DrawerItemClickListener());

        // enable ActionBar app icon to behave as action to toggle nav drawer
        try {
            getActionBar().setDisplayHomeAsUpEnabled(true);
            getActionBar().setHomeButtonEnabled(true);
        } catch (Exception e) {
            e.printStackTrace();
        }

        // ActionBarDrawerToggle ties together the the proper interactions
        // between the sliding drawer and the action bar app icon
        mDrawerToggle = new ActionBarDrawerToggle(
                this,                  /* host Activity */
                mDrawerLayout,         /* DrawerLayout object */
                R.drawable.ic_drawer,  /* nav drawer image to replace 'Up' caret */
                R.string.drawer_open,  /* "open drawer" description for accessibility */
                R.string.drawer_close  /* "close drawer" description for accessibility */
        ) {
            public void onDrawerClosed(View view) {
                getActionBar().setTitle(mTitle);
                invalidateOptionsMenu(); // creates call to onPrepareOptionsMenu()
            }

            public void onDrawerOpened(View drawerView) {
                getActionBar().setTitle(mDrawerTitle);
                invalidateOptionsMenu(); // creates call to onPrepareOptionsMenu()
            }
        };
        mDrawerLayout.setDrawerListener(mDrawerToggle);

        if (savedInstanceState == null) {
            selectItem(0);
            getActionBar().setTitle("Home");
        }

        handleNotification();
    }

    private void handleNotification() {
        Intent alarmIntent = new Intent(this, MyReceiver.class);
        alarmIntent.putExtra("USER_ID", USER_ID);
        PendingIntent pendingIntent = PendingIntent.getBroadcast(this, 0, alarmIntent, PendingIntent.FLAG_UPDATE_CURRENT);
        AlarmManager alarmManager = (AlarmManager)getSystemService(ALARM_SERVICE);
        alarmManager.setRepeating(AlarmManager.RTC_WAKEUP, System.currentTimeMillis(), 1000*60*60, pendingIntent);
    }

    /* The click listener for ListView in the navigation drawer */
    private class DrawerItemClickListener implements ListView.OnItemClickListener {
        @Override
        public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
            selectItem(position);
        }
    }

    private void selectItem(int position) {
        try {
            // update the main content by replacing fragments
            Fragment fragment = null;
            Bundle args = new Bundle();

            switch (position) {
                case 0:
                    fragment = new HomeFragment();
                    break;
                case 1:
                    fragment = new RxFragment();
                    args.putString("USER_ID", USER_ID);
                    args.putBoolean("SHOW_ACTIVE_RX", true);
                    break;
                /*
                case 2:
                    fragment = new PhysicianFragment();
                    args.putString(PhysicianFragment.ARG_USER_ID, USER_ID);
                    break;
                    */
                case 2:
                    fragment = new PlanFragment();
                    args.putString("USER_ID", USER_ID);
                    break;
                /*
                case 4:
                    fragment = new FamilyFragment();
                    args.putString(FamilyFragment.ARG_USER_ID, USER_ID);
                    break;
                    */
                case 3:
                    fragment = new HealthReportFragment();
                    args.putString("USER_ID", USER_ID);
                    break;
                case 4:
                    fragment = new ExpenseReportFragment();
                    args.putString("USER_ID", USER_ID);
                    break;
                case 5:
                    Intent mapsActivityIntent = new Intent(this, MapsActivity.class);
                    startActivity(mapsActivityIntent);
                    fragment = new HomeFragment();
                    break;
                /*
                case 8:
                    fragment = new ProfileSettingsFragment();
                    args.putString(ProfileSettingsFragment.ARG_USER_ID, USER_ID);
                    break;
                    */
                case 6:
                    Intent guestActivityIntent = new Intent(this, GuestActivity.class);
                    startActivity(guestActivityIntent);
                    finish();
                default:
                    fragment = new HomeFragment();
                    break;
            }


            fragment.setArguments(args);
            FragmentManager fragmentManager = getFragmentManager();
            fragmentManager.beginTransaction().replace(R.id.content_frame, fragment).commit();

            // update selected item and title, then close the drawer
            mDrawerList.setItemChecked(position, true);
            setTitle(mOptions[position]);
            mDrawerLayout.closeDrawer(mDrawerList);
        } catch (Exception ex) {
            Log.e(TAG, "Exception - " + ex.getMessage());
            Toast.makeText(this,
                    "Exception - " + ex.getMessage(), Toast.LENGTH_SHORT)
                    .show();
        }
    }

    @Override
    public void setTitle(CharSequence title) {
        mTitle = title;
        getActionBar().setTitle(mTitle);
    }

    /**
     * When using the ActionBarDrawerToggle, you must call it during
     * onPostCreate() and onConfigurationChanged()...
     */

    @Override
    protected void onPostCreate(Bundle savedInstanceState) {
        super.onPostCreate(savedInstanceState);
        // Sync the toggle state after onRestoreInstanceState has occurred.
        mDrawerToggle.syncState();
    }

    /**
     * Handling the touch event of app icon
     */
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (mDrawerToggle.onOptionsItemSelected(item)) {
            return true;
        }
        return super.onOptionsItemSelected(item);
    }

    @Override
    public void onConfigurationChanged(Configuration newConfig) {
        super.onConfigurationChanged(newConfig);
        // Pass any configuration change to the drawer toggls
        mDrawerToggle.onConfigurationChanged(newConfig);
    }

    /**
     * Fragment that appears in the "content_frame", shows a planet
     */
    public static class HomeFragment extends Fragment {


        public HomeFragment() {
            // Empty constructor required for fragment subclasses
        }

        @Override
        public View onCreateView(LayoutInflater inflater, ViewGroup container,
                                 Bundle savedInstanceState) {
            View rootView = null;
            try {
                rootView = inflater.inflate(R.layout.fragment_home, container, false);

                TextView home_screen_welcome_msg_tv = (TextView) rootView.findViewById(R.id.home_screen_welcome_msg);
                home_screen_welcome_msg_tv.setText("Good day " + FIRST_NAME + "!");


                // Calculate the number of days left for the user's birthday

                LocalDate birthday = new LocalDate(DOB.substring(0, 10));
                LocalDate today = LocalDate.now();
                LocalDate nextBDay = birthday.withYear(today.getYear());

                //If your birthday has occurred this year already, add 1 to the year.
                if (nextBDay.isBefore(today) || nextBDay.isEqual(today)) {
                    nextBDay = nextBDay.plusYears(1);
                }
                TextView today_age_msg_tv = (TextView) rootView.findViewById(R.id.today_age_msg);
                today_age_msg_tv.setText("You have " + Days.daysBetween(today, nextBDay).getDays()
                        + " more days until your next birthday!");


            } catch (Exception ex) {
                Log.e(TAG, "Exception - " + ex.getMessage());

            } finally {
                return rootView;
            }
        }
    }
}