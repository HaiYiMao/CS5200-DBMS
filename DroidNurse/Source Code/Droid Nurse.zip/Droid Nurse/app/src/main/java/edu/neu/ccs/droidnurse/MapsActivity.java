package edu.neu.ccs.droidnurse;

import android.support.v4.app.FragmentActivity;
import android.os.Bundle;
import android.util.Log;
import android.widget.Toast;

import com.google.android.gms.maps.GoogleMap;
import android.location.Location;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.MarkerOptions;
import com.google.android.gms.maps.model.Marker;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.model.BitmapDescriptorFactory;

import org.apache.http.HttpResponse;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.DefaultHttpClient;
import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;

public class MapsActivity extends FragmentActivity {

    private static final String TAG = "MapsActivity";
    private GoogleMap mMap; // Might be null if Google Play services APK is not available.

    // Below variable holds the latitude and longitude position of the user
    public double currentLatitudePosition = 0.d;
    public double currentLongitudePosition = 0.d;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_maps);
        SetUpGoogleMaps();
    }

    @Override
    protected void onResume() {
        super.onResume();
        SetUpGoogleMaps();
    }

    /**
     * Sets up the map if it is possible to do so (i.e., the Google Play services APK is correctly
     * installed) and the map has not already been instantiated.. This will ensure that we only ever
     * call {@link #PlotCurrentUserLocationMarker()} once when {@link #mMap} is not null.
     * <p>
     * If it isn't installed {@link SupportMapFragment} (and
     * {@link com.google.android.gms.maps.MapView MapView}) will show a prompt for the user to
     * install/update the Google Play services APK on their device.
     * <p>
     * A user can return to this FragmentActivity after following the prompt and correctly
     * installing/updating/enabling the Google Play services. Since the FragmentActivity may not
     * have been completely destroyed during this process (it is likely that it would only be
     * stopped or paused), {@link #onCreate(Bundle)} may not be called again so we should call this
     * method in {@link #onResume()} to guarantee that it will be called.
     */
    private void SetUpGoogleMaps() {
        // Do a null check to confirm that we have not already instantiated the map.
        if (mMap == null) {
            // Try to obtain the map from the SupportMapFragment.
            mMap = ((SupportMapFragment) getSupportFragmentManager().findFragmentById(R.id.map))
                    .getMap();
            // Check if we were successful in obtaining the map.
            if (mMap != null) {
                PlotCurrentUserLocationMarker();
                PlotHospitalMarkers();
                PlotPharmacyMarkers();
            }
        }
    }

    // Below method is responsible for plotting the current user location markers in the google maps
    private void PlotCurrentUserLocationMarker() {

        LatLng myLocation = GetCurrentLocation();
        Marker myLocationMarker = mMap.addMarker(new MarkerOptions().position(myLocation)
                .title("Your Location")
                .snippet("You are Currently Here !!")
                .icon(BitmapDescriptorFactory.fromResource(R.drawable.current_position_marker)));

        // Below line of code would make the map to focus on the user's current location
        mMap.moveCamera(CameraUpdateFactory.newLatLngZoom(myLocation, 13.0f));
    }


    // Below method is responsible for plotting Hospital markers of respective location in the google maps
    private void PlotHospitalMarkers() {
        try {
            String jsonHospitalData = "";
            GooglePlacesAPI googlePlacesAPI = new GooglePlacesAPI();
            jsonHospitalData = googlePlacesAPI.GetHospitalDetailsFromGooglePlacesAPI(currentLatitudePosition, currentLongitudePosition);

            JSONObject jsonObject = new JSONObject(jsonHospitalData);
            JSONArray jsonResultsArray = jsonObject.getJSONArray("results");

            for (int i = 0; i < jsonResultsArray.length(); i++) {
                JSONObject jsonResultsObj = (JSONObject) jsonResultsArray.getJSONObject(i);
                String hospitalName = jsonResultsObj.getString("name");
                String hospitalAddress = jsonResultsObj.getString("vicinity");
                JSONObject geometryJSONObject = jsonResultsObj.getJSONObject("geometry");
                JSONObject locationJSONObject = geometryJSONObject.getJSONObject("location");
                String hospitalLatitude = locationJSONObject.getString("lat");
                String hospitalLongitude = locationJSONObject.getString("lng");
                LatLng hospitalLatLng = new LatLng(Double.parseDouble(hospitalLatitude), Double.parseDouble(hospitalLongitude));
                Marker hospitalLocationMarker = mMap.addMarker(new MarkerOptions().position(hospitalLatLng)
                        .title(hospitalName)
                        .snippet(hospitalAddress)
                        .icon(BitmapDescriptorFactory.fromResource(R.drawable.hospital_building)));

            }

        } catch (Exception ex) {
            Log.e(TAG, "Exception - " + ex.getMessage());
            Toast.makeText(this,
                    "Exception - " + ex.getMessage(), Toast.LENGTH_SHORT)
                    .show();
        }
    }

    // Below method is responsible for plotting Pharmacy markers of respective location in the google maps
    private void PlotPharmacyMarkers() {
        try{
            String jsonPharmacyData = "";
            GooglePlacesAPI googlePlacesAPI = new GooglePlacesAPI();
            jsonPharmacyData = googlePlacesAPI.GetPharmacyDetailsFromGooglePlacesAPI(currentLatitudePosition, currentLongitudePosition);

            JSONObject jsonObject = new JSONObject(jsonPharmacyData);
            JSONArray jsonResultsArray = jsonObject.getJSONArray("results");

            for (int i = 0; i < jsonResultsArray.length(); i++) {
                JSONObject jsonResultsObj = (JSONObject) jsonResultsArray.getJSONObject(i);
                String pharmacyName = jsonResultsObj.getString("name");
                String pharmacyAddress = jsonResultsObj.getString("vicinity");
                JSONObject geometryJSONObject = jsonResultsObj.getJSONObject("geometry");
                JSONObject locationJSONObject = geometryJSONObject.getJSONObject("location");
                String pharmacyLatitude = locationJSONObject.getString("lat");
                String pharmacyLongitude = locationJSONObject.getString("lng");
                LatLng pharmacyLatLng = new LatLng(Double.parseDouble(pharmacyLatitude), Double.parseDouble(pharmacyLongitude));
                Marker pharmacyLocationMarker = mMap.addMarker(new MarkerOptions().position(pharmacyLatLng)
                        .title(pharmacyName)
                        .snippet(pharmacyAddress)
                        .icon(BitmapDescriptorFactory.fromResource(R.drawable.pharmacy_building)));

            }
        } catch (Exception ex) {
            Log.e(TAG, "Exception - " + ex.getMessage());
            Toast.makeText(this,
                    "Exception - " + ex.getMessage(), Toast.LENGTH_SHORT)
                    .show();
        }
    }

    // Below method is responsible for retrieving the user's latitude and longitude coordinates using GPS
    private LatLng GetCurrentLocation()
    {
        LatLng myLocation=null;
        try
        {
            GPSTracker gps = new GPSTracker(this);
            if(gps.canGetLocation()) {
                currentLatitudePosition = gps.getLatitude();
                currentLongitudePosition = gps.getLongitude();
                myLocation = new LatLng(currentLatitudePosition, currentLongitudePosition);
            }

        } catch (Exception ex) {
            Log.e(TAG, "Exception - " + ex.getMessage());
            Toast.makeText(this,
                    "Exception - " + ex.getMessage(), Toast.LENGTH_SHORT)
                    .show();
        }
        finally
        {
            return myLocation;
        }

    }


}