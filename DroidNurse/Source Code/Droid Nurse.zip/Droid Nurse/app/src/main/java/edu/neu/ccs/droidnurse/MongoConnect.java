package edu.neu.ccs.droidnurse;

import com.mongodb.DB;
import com.mongodb.DBCollection;
import com.mongodb.MongoClient;
import com.mongodb.MongoCredential;
import com.mongodb.ServerAddress;
import java.net.UnknownHostException;
import java.util.Arrays;

public class MongoConnect {

    public enum dbCollections {code, drug_details, health_plan, physician, prescription, refill, user_profile, user_report}

    ;

    // Below credentials is for venkatesh891 account
    private final static String dbUser = "droidnurse";
    private final static String dbPassword = "password";
    private final static String dbName = "droidnurse";
    private final static String dbServerAddress = "ds055699.mongolab.com:55699";

    /*
    // Below credentials is for sandeep account
    private final static String dbUser = "droidnurse";
    private final static String dbPassword = "password";
    private final static String dbName = "droidnurse";
    private final static String dbServerAddress = "ds033429.mongolab.com:33429";
    */

    public static DBCollection getCollection(dbCollections collection) {
        DBCollection connectCollection = null;
        try {
            MongoCredential credential = MongoCredential.createMongoCRCredential(dbUser, dbName, dbPassword.toCharArray());
            MongoClient mongo = new MongoClient(new ServerAddress(dbServerAddress), Arrays.asList(credential));
            DB db = mongo.getDB(dbName);
            String collectionName = "";
            switch (collection) {
                case code:
                    collectionName = "code";
                    break;

                case drug_details:
                    collectionName = "drug_details";
                    break;

                case health_plan:
                    collectionName = "health_plan";
                    break;

                case physician:
                    collectionName = "physician";
                    break;

                case prescription:
                    collectionName = "prescription";
                    break;

                case refill:
                    collectionName = "refill";
                    break;

                case user_profile:
                    collectionName = "user_profile";
                    break;

                case user_report:
                    collectionName = "user_report";
                    break;

            }

            connectCollection = db.getCollection(collectionName);

        } catch (UnknownHostException e) {
            e.printStackTrace();
        } finally {
            return connectCollection;
        }
    }
}
