package edu.neu.ccs.droidnurse;

import android.app.Notification;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.os.Parcelable;
import android.support.v4.app.NotificationCompat;
import android.support.v4.app.TaskStackBuilder;

import com.mongodb.BasicDBList;
import com.mongodb.BasicDBObject;
import com.mongodb.DBCollection;
import com.mongodb.DBCursor;
import com.mongodb.DBObject;

import org.bson.types.ObjectId;
import org.joda.time.DateTime;
import org.joda.time.Days;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.List;

/**
 * Created by Sandeep on 8/6/2014.
 */
public class MyReceiver extends BroadcastReceiver {

    ArrayList<String> rxList = new ArrayList<String>();
    ArrayList<String> refillList = new ArrayList<String>();
    String USER_ID;

    @Override
    public void onReceive(Context context, Intent intent) {

        USER_ID = intent.getStringExtra("USER_ID");


        if (notificationExists()) {
            NotificationCompat.Builder mBuilder =
                    new NotificationCompat.Builder(context)
                            .setSmallIcon(R.drawable.ic_launcher)
                            .setContentTitle("DroidNurse : Remainder")
                            .setContentText("Tap to see pending Notifications ")
                            .setDefaults(Notification.DEFAULT_ALL)
                            .setAutoCancel(true);

            Intent resultIntent = new Intent(context, NotificationActivity.class);
            resultIntent.putStringArrayListExtra("rxList", rxList);
            resultIntent.putStringArrayListExtra("refillList", refillList);

            TaskStackBuilder stackBuilder = TaskStackBuilder.create(context);
            stackBuilder.addParentStack(MainActivity.class);
            stackBuilder.addNextIntent(resultIntent);
            PendingIntent resultPendingIntent = stackBuilder.getPendingIntent(0, PendingIntent.FLAG_UPDATE_CURRENT);
            //PendingIntent.getActivity(context, 0, new Intent(), 0);
            //builder.setContentIntent(notifyPendingIntent);

            mBuilder.setContentIntent(resultPendingIntent);
            NotificationManager mNotificationManager = (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);
            mNotificationManager.notify(1, mBuilder.build());
        }

    }

    public boolean notificationExists() {

        boolean result = false;

        try {
            DBCollection prescription = MongoConnect.getCollection(MongoConnect.dbCollections.prescription);
            DBCollection user_profile = MongoConnect.getCollection(MongoConnect.dbCollections.user_profile);
            DBCollection refill = MongoConnect.getCollection(MongoConnect.dbCollections.refill);

            BasicDBObject whereQuery = new BasicDBObject();
            whereQuery.put("_id", new ObjectId(USER_ID));
            DBCursor cursor = user_profile.find(whereQuery);
            DBObject DBO = cursor.next();
            BasicDBList rxDBList = (BasicDBList) DBO.get("Rx");

            BasicDBObject rxQuery = new BasicDBObject();
            List<BasicDBObject> obj = new ArrayList<BasicDBObject>();
            obj.add(new BasicDBObject("_id", new BasicDBObject("$in", rxDBList)));
            obj.add(new BasicDBObject("isActive", true));
            rxQuery.put("$and", obj);
            DBCursor rxCursor = prescription.find(rxQuery);


            while (rxCursor.hasNext()) {
                ArrayList<ObjectId> refillObjIdList = new ArrayList<ObjectId>();


                DBObject rxDBO = rxCursor.next();

                BasicDBObject sig = (BasicDBObject) rxDBO.get("sig");
                int sigDosageCounts = Integer.parseInt(sig.get("sig_times").toString());
                int sigMinDosageQty = Integer.parseInt(sig.get("single_dose_qty").toString());


                ArrayList<String> refillObj;
                refillObj = (ArrayList<String>)rxDBO.get("refills");


                if (refillObj != null) {

                    for (String sObj : refillObj)
                        refillObjIdList.add(new ObjectId(sObj));

                    BasicDBObject refillQuery = new BasicDBObject();
                    List<BasicDBObject> obj2 = new ArrayList<BasicDBObject>();
                    obj2.add(new BasicDBObject("_id", new BasicDBObject("$in", refillObjIdList)));
                    obj2.add(new BasicDBObject("isActive", true));
                    refillQuery.put("$and", obj2);
                    DBCursor refillCursor = refill.find(refillQuery);

                    while (refillCursor.hasNext()) {

                        DBObject refillDBO = refillCursor.next();

                        String currentRefillId = refillDBO.get("_id").toString();
                        BasicDBObject notifications = (BasicDBObject) refillDBO.get("notification");
                        int note_counter = Integer.parseInt(notifications.get("note_counter").toString());
                        int qty_remaining = Integer.parseInt(refillDBO.get("qty_remaining").toString());
                        DateTime last_update = new DateTime(notifications.get("last_update_time"));

                        int daysBetween = Days.daysBetween(last_update, DateTime.now()).getDays();
                        if( daysBetween >= 1)
                        {
                            resetNotification(currentRefillId);
                        }


                        if (qty_remaining < sigMinDosageQty) {

                            // Deactivate the refill
                            BasicDBObject refillSearchQuery = new BasicDBObject();
                            refillSearchQuery.put("_id", new ObjectId(refillCursor.next().get("_id").toString()));

                            refill.update(refillSearchQuery, new BasicDBObject("$set",
                                    new BasicDBObject("isActive", false)));

                        } else if (note_counter < sigDosageCounts) {
                            rxList.add(rxDBO.get("_id").toString());
                            refillList.add(currentRefillId);
                            result = true;
                        }

                    }
                }

            }
        } catch (Exception e) {
            e.printStackTrace();


       }

        return result;

    }

    public void resetNotification(String RefillId)
    {
        DBCollection refill = MongoConnect.getCollection(MongoConnect.dbCollections.refill);
        BasicDBObject refillQuery = new BasicDBObject();
        refillQuery.put("_id", new ObjectId(RefillId));

        refill.update(refillQuery,new BasicDBObject("$set",
                new BasicDBObject("notification.last_update_time", new Date())));

        refill.update(refillQuery,new BasicDBObject("$set",
                new BasicDBObject("notification.note_counter", 0)));
    }

}

