package edu.neu.ccs.droidnurse;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.TableLayout;
import android.widget.TableRow;
import android.widget.TextView;
import android.widget.Toast;

import com.mongodb.BasicDBObject;
import com.mongodb.DBCollection;
import com.mongodb.DBCursor;
import com.mongodb.DBObject;

import org.bson.types.ObjectId;

import java.util.ArrayList;
import java.util.Date;

import edu.neu.ccs.droidnurse.R;

public class NotificationActivity extends Activity {

    ArrayList<String> rxList = new ArrayList<String>();
    ArrayList<String> refillList = new ArrayList<String>();
    ArrayList<String> selectedRxList = new ArrayList<String>();
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_notification);
        rxList = getIntent().getStringArrayListExtra("rxList");
        refillList = getIntent().getStringArrayListExtra("refillList");

        populateScreen();

        Button saveBtn = (Button)this.findViewById(R.id.notification_save_button);
        saveBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if (selectedRxList.isEmpty()) {
                    Toast.makeText(getApplicationContext(), "Please select at least one notification", Toast.LENGTH_SHORT)
                            .show();
                }
                else {

                   if(saveSelectedNotifications())
                   {
                       Toast.makeText(getApplicationContext(), "Save Successful", Toast.LENGTH_SHORT)
                               .show();

                       // Minimise the screen and send the user back home
                       Intent startMain = new Intent(Intent.ACTION_MAIN);
                       startMain.addCategory(Intent.CATEGORY_HOME);
                       startMain.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                       startActivity(startMain);
                   }
                    else {
                       Toast.makeText(getApplicationContext(), "An error occurred while saving. Please try again! ", Toast.LENGTH_SHORT)
                               .show();
                   }

                }
            }
        });


    }



    public void populateScreen()
    {
        int i = 1;
        TableLayout tableLayout = (TableLayout)this.findViewById(R.id.main_table);
        TableRow tr_head = new TableRow(this);
        tr_head.setId(100000 + i);
        tr_head.setBackgroundColor(Color.GRAY);
        tr_head.setPadding(5, 10, 5, 10);
        tr_head.setLayoutParams(new TableLayout.LayoutParams(
                TableRow.LayoutParams.FILL_PARENT,
                TableRow.LayoutParams.WRAP_CONTENT));

        TextView label_rx = new TextView(this);
        label_rx.setId(20000000 + i);
        label_rx.setText("Rx No");
        label_rx.setTextColor(Color.WHITE);
        label_rx.setPadding(5, 5, 5, 5);
        TableRow.LayoutParams params1 = new TableRow.LayoutParams(0, TableRow.LayoutParams.WRAP_CONTENT, .3f);
        label_rx.setLayoutParams(params1);
        tr_head.addView(label_rx);// add the column to the table row here

        TextView label_drug = new TextView(this);
        label_drug.setId(20000001 + i);// define id that must be unique
        label_drug.setText("Drug Name"); // set the text for the header
        label_drug.setTextColor(Color.WHITE); // set the color
        label_drug.setPadding(5, 5, 5, 5); // set the padding (if required)
        TableRow.LayoutParams params2 = new TableRow.LayoutParams(0, TableRow.LayoutParams.WRAP_CONTENT, .3f);
        label_drug.setLayoutParams(params2);
        tr_head.addView(label_drug); // add the column to the table row here

        TextView label_dosage = new TextView(this);
        label_dosage.setId(20000001 + i);// define id that must be unique
        label_dosage.setText("Dosage"); // set the text for the header
        label_dosage.setTextColor(Color.WHITE); // set the color
        label_dosage.setPadding(5, 5, 5, 5); // set the padding (if required)
        TableRow.LayoutParams params3 = new TableRow.LayoutParams(0, TableRow.LayoutParams.WRAP_CONTENT, .2f);
        label_dosage.setLayoutParams(params3);
        tr_head.addView(label_dosage); // add the column to the table row here

        TextView label_view_rx = new TextView(this);
        label_view_rx.setId(20000001 + i);// define id that must be unique
        label_view_rx.setText("Mark Intake"); // set the text for the header
        label_view_rx.setTextColor(Color.WHITE); // set the color
        label_view_rx.setPadding(5, 5, 5, 5); // set the padding (if required)
        TableRow.LayoutParams params4 = new TableRow.LayoutParams(0, TableRow.LayoutParams.WRAP_CONTENT, .2f);
        label_view_rx.setLayoutParams(params4);
        tr_head.addView(label_view_rx);


        tableLayout.addView(tr_head, new TableLayout.LayoutParams(
                TableLayout.LayoutParams.FILL_PARENT,
                TableLayout.LayoutParams.WRAP_CONTENT));

       int count =0;

       DBCollection prescription = MongoConnect.getCollection(MongoConnect.dbCollections.prescription);
       BasicDBObject rxQuery = new BasicDBObject();

       DBCollection drug_details = MongoConnect.getCollection(MongoConnect.dbCollections.drug_details);
       BasicDBObject drugQuery = new BasicDBObject();

         DBCollection refill = MongoConnect.getCollection(MongoConnect.dbCollections.refill);
         BasicDBObject refillQuery = new BasicDBObject();

         DBCollection code = MongoConnect.getCollection(MongoConnect.dbCollections.code);
         BasicDBObject codeQuery = new BasicDBObject();




        for(String rx : rxList)
        {

            rxQuery.put("_id", rx);
            DBCursor rxCursor = prescription.find(rxQuery);
            DBObject rxDBO = rxCursor.next();
            BasicDBObject sig = (BasicDBObject)rxDBO.get("sig");

            int dosage_qty = Integer.parseInt(sig.get("single_dose_qty").toString());
            int sig_times =  Integer.parseInt(sig.get("sig_times").toString());
            int UOM_code =   Integer.parseInt(sig.get("UOM_code").toString());

            codeQuery.put("_id", UOM_code);
            DBCursor codeCursor = code.find(codeQuery);

            String UOM = codeCursor.next().get("meaning_text").toString();


            drugQuery.put("NDC", rxDBO.get("drug_NDC").toString());
            DBCursor drugCursor = drug_details.find(drugQuery);

            String refillString =refillList.get(rxList.indexOf(rx));
            refillQuery.put("_id", new ObjectId(refillString));
            DBCursor refillCursor = refill.find(refillQuery);

            DBObject refillDBO = refillCursor.next();
            BasicDBObject notification = (BasicDBObject)refillDBO.get("notification");


            // Create the table row
            TableRow tr = new TableRow(this);
            if (count % 2 != 0) tr.setBackgroundColor(Color.GRAY);
            tr.setId(count);
            tr.setLayoutParams(new TableRow.LayoutParams(
                    TableRow.LayoutParams.FILL_PARENT,
                    TableRow.LayoutParams.WRAP_CONTENT));

            //Create two columns to add as table data
            // Create a TextView to add date
            TextView labelRx = new TextView(this);
            labelRx.setId(count+ 100);
            labelRx.setText(rx);
            labelRx.setPadding(2, 0, 5, 0);
            labelRx.setTextColor(Color.BLACK);
            labelRx.setLayoutParams(params1);
            tr.addView(labelRx);

            TextView labelDrug = new TextView(this);
            labelDrug.setId(count+200);
            labelDrug.setText(drugCursor.next().get("drug_name").toString());
            labelDrug.setTextColor(Color.BLACK);
            labelDrug.setLayoutParams(params2);
            tr.addView(labelDrug);


            TextView labelDosage = new TextView(this);
            labelDosage.setId(count + 300);
            labelDosage.setText(dosage_qty + " " + UOM);
            labelDosage.setTextColor(Color.BLACK);
            labelDosage.setLayoutParams(params3);
            tr.addView(labelDosage);

            final CheckBox checkBox = new CheckBox(this);
            checkBox.setId(count);
            checkBox.setLayoutParams(params4);
            tr.addView(checkBox);
            checkBox.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
                @Override
                public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {

                    if(isChecked)
                        selectedRxList.add(rxList.get(checkBox.getId()));
                    else
                        selectedRxList.remove(rxList.get(checkBox.getId()));



                }
            });

            // finally add this to the table row
            tableLayout.addView(tr, new TableLayout.LayoutParams(
                    TableLayout.LayoutParams.FILL_PARENT,
                    TableLayout.LayoutParams.WRAP_CONTENT));


            count++;



        }
    }


    public boolean saveSelectedNotifications() {

        boolean result = true;

        try {


            DBCollection prescription = MongoConnect.getCollection(MongoConnect.dbCollections.prescription);
            DBCollection refill = MongoConnect.getCollection(MongoConnect.dbCollections.refill);



            for (String rx : selectedRxList) {

                BasicDBObject rxQuery = new BasicDBObject();
                BasicDBObject refillQuery = new BasicDBObject();

                rxQuery.put("_id", rx);
                DBCursor rxCursor = prescription.find(rxQuery);
                DBObject rxDBO = rxCursor.next();
                BasicDBObject sig = (BasicDBObject)rxDBO.get("sig");

                int dosage_qty = Integer.parseInt(sig.get("single_dose_qty").toString());
                int sig_times =  Integer.parseInt(sig.get("sig_times").toString());
                int UOM_code =   Integer.parseInt(sig.get("UOM_code").toString());

                // Find the refill to update
                String refillString = refillList.get(rxList.indexOf(rx));
                refillQuery.put("_id", new ObjectId(refillString));


                // Decrease the qty_remaining field
                DBObject modifiedRefillQuantityObject = new BasicDBObject();
                modifiedRefillQuantityObject.put("$inc", new BasicDBObject().append("qty_remaining", (-1* dosage_qty)));
                refill.update(refillQuery, modifiedRefillQuantityObject);

                refill.update(refillQuery,new BasicDBObject("$set",
                        new BasicDBObject("notification.last_update_time", new Date())));

                // increase the note_counter field
                DBObject modifiedNoteCounterObject = new BasicDBObject();
                modifiedNoteCounterObject.put("$inc", new BasicDBObject().append("notification.note_counter", 1));
                refill.update(refillQuery, modifiedNoteCounterObject);

            }

        }
        catch (Exception e)
        {
            result = false;
        }


        return result;
    }
 }
