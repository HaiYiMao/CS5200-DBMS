package edu.neu.ccs.droidnurse;

import android.app.Fragment;
import android.app.FragmentManager;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.util.Log;
import android.widget.Toast;
import android.widget.Button;
import java.io.BufferedReader;
import java.io.InputStream;
import org.apache.http.HttpResponse;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.DefaultHttpClient;
import java.io.InputStreamReader;
import org.json.JSONObject;
import org.json.JSONArray;

/**
 * Created by Venkatesh on 26/07/14.
 */

public class PhysicianDetailsAPI extends Fragment {

    private static final String TAG = "PhysicianDetailsAPI";
    private final String baseAPIURL = "http://data.medicare.gov/resource/s63f-csi6.json?$where=npi=";
    private final String SCREENCODE = "C";
    View rootView;

    // Bundle Arguments
    public String ARG_USER_ID;
    public String NPINUMBER;
    public String NPINUMBERTEMP;
    public String PRESCRIBERLNAME;
    public String PRESCRIBERFNAME;
    public String RXNUMBER;
    public String NDCNUMBER;
    public String NDCNAME;
    public String NO_OF_REFILLS;
    public String WRITTENDATE;
    public String EXPIRYDATE;
    public String DRUGCOUNT;
    public String DRUGDOSAGE;
    public String DOSAGECOUNT;
    public String DOSAGEINTERVAL;
    public String PRESCRIBERTEMPLNAME;
    public String PRESCRIBERTEMPFNAME;

    public PhysicianDetailsAPI() {
        // Required empty public constructor
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        try {

            GetBundleArguments();

            rootView = inflater.inflate(R.layout.fragment_physician_details_api, container, false);

            String jsonData = GetJSONPhysicianDetailsFromAPI(NPINUMBERTEMP);
            DisplayJSONData(jsonData);

            Button btnBackToSearchResults = (Button) rootView.findViewById(R.id.btnPDBackToResults);
            btnBackToSearchResults.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {

                    Fragment searchPrescriberFragment = new SearchPrescriberFragment();
                    Bundle args = new Bundle();
                    args.putString("USER_ID", ARG_USER_ID);
                    args.putString("SCREEN_CODE", SCREENCODE);
                    args.putString("RXNUMBER", RXNUMBER);
                    args.putString("NPINUMBER", NPINUMBER);
                    args.putString("NDCNUMBER", NDCNUMBER);
                    args.putString("NDCNAME", NDCNAME);
                    args.putString("NO_OF_REFILLS", NO_OF_REFILLS);
                    args.putString("WRITTENDATE", WRITTENDATE);
                    args.putString("EXPIRYDATE", EXPIRYDATE);
                    args.putString("DRUGCOUNT", DRUGCOUNT);
                    args.putString("DRUGDOSAGE", DRUGDOSAGE);
                    args.putString("DOSAGECOUNT", DOSAGECOUNT);
                    args.putString("DOSAGEINTERVAL", DOSAGEINTERVAL);
                    args.putString("PRESCRIBERLNAME", PRESCRIBERLNAME);
                    args.putString("PRESCRIBERFNAME", PRESCRIBERFNAME);
                    args.putString("PRESCRIBERTEMPLNAME", PRESCRIBERTEMPLNAME);
                    args.putString("PRESCRIBERTEMPFNAME", PRESCRIBERTEMPFNAME);
                    searchPrescriberFragment.setArguments(args);
                    FragmentManager fragmentManager = getFragmentManager();
                    fragmentManager.beginTransaction().replace(R.id.content_frame, searchPrescriberFragment).commit();

                }
            });

            Button btnSelectPrescriber = (Button) rootView.findViewById(R.id.btnPDSelectPrescriber);
            btnSelectPrescriber.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {

                    Fragment addRXFragment = new RxFragmentAddRx();
                    Bundle args = new Bundle();
                    args.putString("USER_ID", ARG_USER_ID);
                    args.putString("SCREEN_CODE", SCREENCODE);
                    args.putString("RXNUMBER", RXNUMBER);
                    args.putString("NPINUMBER", NPINUMBERTEMP);
                    EditText txtPhysicianFirstName = (EditText) rootView.findViewById(R.id.txtPDFirstName);
                    EditText txtPhysicianLastName = (EditText) rootView.findViewById(R.id.txtPDLastName);
                    args.putString("PRESCRIBERLNAME", txtPhysicianFirstName.getText().toString());
                    args.putString("PRESCRIBERFNAME", txtPhysicianLastName.getText().toString());
                    args.putString("NDCNUMBER", NDCNUMBER);
                    args.putString("NDCNAME", NDCNAME);
                    args.putString("NO_OF_REFILLS", NO_OF_REFILLS);
                    args.putString("WRITTENDATE", WRITTENDATE);
                    args.putString("EXPIRYDATE", EXPIRYDATE);
                    args.putString("DRUGCOUNT", DRUGCOUNT);
                    args.putString("DRUGDOSAGE", DRUGDOSAGE);
                    args.putString("DOSAGECOUNT", DOSAGECOUNT);
                    args.putString("DOSAGEINTERVAL", DOSAGEINTERVAL);
                    addRXFragment.setArguments(args);
                    FragmentManager fragmentManager = getFragmentManager();
                    fragmentManager.beginTransaction().replace(R.id.content_frame, addRXFragment).commit();

                }
            });


        } catch (Exception ex) {
            Log.e(TAG, "Exception - " + ex.getMessage());
        } finally {
            return rootView;
        }
    }

    // Retrieves the bundle arguments which holds data from the previous screens
    private void GetBundleArguments() {
        try {
            ARG_USER_ID = getArguments().getString("USER_ID");
            RXNUMBER = getArguments().getString("RXNUMBER");
            NPINUMBER = getArguments().getString("NPINUMBER");
            NPINUMBERTEMP =  getArguments().getString("NPINUMBERTEMP");
            PRESCRIBERFNAME = getArguments().getString("PRESCRIBERFNAME");
            PRESCRIBERLNAME = getArguments().getString("PRESCRIBERLNAME");
            NDCNUMBER = getArguments().getString("NDCNUMBER");
            NDCNAME = getArguments().getString("NDCNAME");
            NO_OF_REFILLS = getArguments().getString("NO_OF_REFILLS");
            WRITTENDATE = getArguments().getString("WRITTENDATE");
            EXPIRYDATE = getArguments().getString("EXPIRYDATE");
            DRUGCOUNT = getArguments().getString("DRUGCOUNT");
            DRUGDOSAGE = getArguments().getString("DRUGDOSAGE");
            DOSAGECOUNT = getArguments().getString("DOSAGECOUNT");
            DOSAGEINTERVAL = getArguments().getString("DOSAGEINTERVAL");
            PRESCRIBERTEMPLNAME = getArguments().getString("PRESCRIBERTEMPLNAME");
            PRESCRIBERTEMPFNAME = getArguments().getString("PRESCRIBERTEMPFNAME");
        } catch (Exception ex) {
            Log.e(TAG, "Exception - " + ex.getMessage());
        }
    }

    // Below method uses HttpGet to receive json data from REST API (Socrata)
    private String GetJSONPhysicianDetailsFromAPI(String npi) {
        String result = "";
        try {
            String baseURL = baseAPIURL + "'" + npi.trim() + "'";
            // create HttpClient
            HttpClient httpclient = new DefaultHttpClient();

            // make GET request to the given URL
            HttpResponse httpResponse = httpclient.execute(new HttpGet(baseURL));

            // receive response as inputStream
            InputStream inputStream = httpResponse.getEntity().getContent();

            // convert inputstream to string
            if (inputStream != null) {
                result = convertInputStreamToString(inputStream);
            } else {
                Toast.makeText(getActivity(),
                        "Oops, unable to fetch data from Socrata REST API.", Toast.LENGTH_SHORT)
                        .show();
            }

        } catch (Exception ex) {
            Log.e(TAG, "Exception - " + ex.getMessage());
        } finally {
            return result;
        }
    }

    // Below method converts the input stream of data retrieved from the rest api and then converts to String format.
    private String convertInputStreamToString(InputStream inputStream) {
        String result = "";
        try {
            BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(inputStream));
            String line = "";
            while ((line = bufferedReader.readLine()) != null)
                result += line;

            inputStream.close();
        } catch (Exception ex) {
            Log.e(TAG, "Exception - " + ex.getMessage());
        } finally {
            return result;
        }
    }

    // Below method parses the json data which was retrieved from rest api and then displays the appropriate value in the front end
    private void DisplayJSONData(String jsonData) {
        try {
            EditText txtPhysicianFirstName = (EditText) rootView.findViewById(R.id.txtPDFirstName);
            EditText txtPhysicianLastName = (EditText) rootView.findViewById(R.id.txtPDLastName);
            EditText txtPhysicianNPI = (EditText) rootView.findViewById(R.id.txtPDNPI);
            EditText txtPhysicianPacID = (EditText) rootView.findViewById(R.id.txtPDPacID);
            EditText txtPhysicianEnrollmentID = (EditText) rootView.findViewById(R.id.txtPDEnrollmentID);
            EditText txtPhysicianMedSchool = (EditText) rootView.findViewById(R.id.txtPDMedSchool);
            EditText txtPhysicianGradYear = (EditText) rootView.findViewById(R.id.txtPDGradYear);
            EditText txtPhysicianPrimarySpeciality = (EditText) rootView.findViewById(R.id.txtPDPriSpec);
            EditText txtPhysicianAddress = (EditText) rootView.findViewById(R.id.txtPDAddress);
            EditText txtPhysicianCity = (EditText) rootView.findViewById(R.id.txtPDCity);
            EditText txtPhysicianState = (EditText) rootView.findViewById(R.id.txtPDState);
            EditText txtPhysicianZip = (EditText) rootView.findViewById(R.id.txtPDZipCode);

            JSONArray jsonArry = new JSONArray(jsonData);
            // Physicians work at multiple cities, but here we are displaying the first set of data which has been retrieved from the API
            JSONObject jsonObj = (JSONObject) jsonArry.getJSONObject(0);
            txtPhysicianNPI.setText(jsonObj.getString("npi"));
            txtPhysicianFirstName.setText(jsonObj.getString("frst_nm"));
            txtPhysicianLastName.setText(jsonObj.getString("lst_nm"));
            txtPhysicianPacID.setText(jsonObj.getString("ind_pac_id"));
            txtPhysicianEnrollmentID.setText(jsonObj.getString("ind_enrl_id"));
            txtPhysicianMedSchool.setText(jsonObj.getString("med_sch"));
            txtPhysicianGradYear.setText(jsonObj.getString("grd_yr"));
            txtPhysicianPrimarySpeciality.setText(jsonObj.getString("pri_spec"));
            txtPhysicianAddress.setText(jsonObj.getString("adr_ln_1"));
            txtPhysicianCity.setText(jsonObj.getString("cty"));
            txtPhysicianState.setText(jsonObj.getString("st"));
            txtPhysicianZip.setText(jsonObj.getString("zip"));

            // Setting the control enabled property to false to make it read only.
            txtPhysicianNPI.setEnabled(false);
            txtPhysicianFirstName.setEnabled(false);
            txtPhysicianLastName.setEnabled(false);
            txtPhysicianPacID.setEnabled(false);
            txtPhysicianEnrollmentID.setEnabled(false);
            txtPhysicianMedSchool.setEnabled(false);
            txtPhysicianGradYear.setEnabled(false);
            txtPhysicianPrimarySpeciality.setEnabled(false);
            txtPhysicianAddress.setEnabled(false);
            txtPhysicianCity.setEnabled(false);
            txtPhysicianState.setEnabled(false);
            txtPhysicianZip.setEnabled(false);


        } catch (Exception ex) {
            Log.e(TAG, "Exception - " + ex.getMessage());
        }
    }

}