package edu.neu.ccs.droidnurse;


import android.app.FragmentManager;
import android.graphics.Color;
import android.os.Bundle;
import android.app.Fragment;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.Spinner;
import android.widget.TableLayout;
import android.widget.TableRow;
import android.widget.TextView;
import android.widget.Toast;

import com.mongodb.BasicDBList;
import com.mongodb.BasicDBObject;
import com.mongodb.DBCollection;
import com.mongodb.DBCursor;
import com.mongodb.DBObject;

import org.bson.types.ObjectId;

import java.util.ArrayList;
import java.util.Map;
import java.util.HashMap;
import java.util.List;


/**
 * A simple {@link Fragment} subclass.
 */
public class PlanFragment extends Fragment {

    private static final String TAG = "PlanFragment";

    String ARG_USER_ID;
    final DBCollection health_plan = MongoConnect.getCollection(MongoConnect.dbCollections.health_plan);
    DBCollection user_profile = MongoConnect.getCollection(MongoConnect.dbCollections.user_profile);
    ArrayList<String> plan_IdArrayList = new ArrayList<String>();

    // Below dictionary holds the object id of all the health plan retrieved from Mongo DB
    Map<Integer, String> objectIDMap = new HashMap<Integer, String>();

    public PlanFragment() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {

        ARG_USER_ID = getArguments().getString("USER_ID");
        // Inflate the layout for this fragment
        View v = inflater.inflate(R.layout.fragment_plan, container, false);


        final Spinner stateSpinner = (Spinner) v.findViewById(R.id.state_spinner);
        final Spinner citySpinner = (Spinner) v.findViewById(R.id.city_spinner);
        Button saveBtn = (Button) v.findViewById(R.id.save_plan);

        saveBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                boolean result = savePlan();

                if (result) {
                    Toast toast = Toast.makeText(getActivity(), "Plan saved Successfully", Toast.LENGTH_LONG);
                    toast.show();
                }
            }
        });

        // Populate state spinner from DB

        List stateList = health_plan.distinct("state");

        ArrayAdapter<String> stateSpinnerArrayAdapter = new ArrayAdapter<String>(getActivity(), android.R.layout.simple_spinner_item, stateList); //selected item will look like a spinner set from XML
        stateSpinnerArrayAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        stateSpinner.setAdapter(stateSpinnerArrayAdapter);


        // Populate city spinner based om sate spinner's value
        stateSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {

            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {

                BasicDBObject cityQuery = new BasicDBObject("state", stateSpinner.getSelectedItem().toString());
                List cityList = health_plan.distinct("city", cityQuery);

                ArrayAdapter<String> citySpinnerArrayAdapter = new ArrayAdapter<String>(getActivity(), android.R.layout.simple_spinner_item, cityList); //selected item will look like a spinner set from XML
                citySpinnerArrayAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                citySpinner.setAdapter(citySpinnerArrayAdapter);
                populatePlanList();

            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });

        populateSavedPlans(v);

        return v;
    }


    public void populatePlanList() {
        ArrayList<String> planList = new ArrayList<String>();

        Spinner planSpinner = (Spinner) getActivity().findViewById(R.id.plan_spinner);
        final Spinner stateSpinner = (Spinner) getActivity().findViewById(R.id.state_spinner);
        final Spinner citySpinner = (Spinner) getActivity().findViewById(R.id.city_spinner);

        BasicDBObject planQuery = new BasicDBObject();
        List<BasicDBObject> obj = new ArrayList<BasicDBObject>();

        obj.add(new BasicDBObject("state", stateSpinner.getSelectedItem().toString()));
        obj.add(new BasicDBObject("city", citySpinner.getSelectedItem().toString()));
        //obj.add(new BasicDBObject("isActive", true));
        planQuery.put("$and", obj);

        DBCursor planCursor = health_plan.find(planQuery);

        while (planCursor.hasNext()) {

            DBObject planObject = planCursor.next();
            planList.add(planObject.get("plan_name").toString());
            plan_IdArrayList.add(planObject.get("_id").toString());

        }

        if (!(planList.isEmpty())) {
            ArrayAdapter<String> planSpinnerArrayAdapter = new ArrayAdapter<String>(getActivity(), android.R.layout.simple_spinner_item, planList); //selected item will look like a spinner set from XML
            planSpinnerArrayAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
            planSpinner.setAdapter(planSpinnerArrayAdapter);
        }


    }


    public boolean savePlan() {
        boolean res = true;
        String family, planName, plan_ObjectId;
        int familyCode;


        Spinner familyTypeSpinner = (Spinner) getActivity().findViewById(R.id.family_spinner);
        Spinner planSpinner = (Spinner) getActivity().findViewById(R.id.plan_spinner);
        Spinner citySpinner = (Spinner) getActivity().findViewById(R.id.city_spinner);

        planName = planSpinner.getSelectedItem().toString();
        family = familyTypeSpinner.getSelectedItem().toString();

        if (family.contains("Family"))
            familyCode = 81;
        else
            familyCode = 80;

        plan_ObjectId = plan_IdArrayList.get(planSpinner.getSelectedItemPosition());


        try {

            BasicDBObject plan_details = new BasicDBObject("plan_object_id", plan_ObjectId);
            plan_details.append("plan_type", familyCode);

            BasicDBObject planArray = new BasicDBObject();
            planArray.put("$addToSet", new BasicDBObject("health_plans", plan_details));

            BasicDBObject userMatch = new BasicDBObject();
            userMatch.put("_id", new ObjectId(ARG_USER_ID));
            user_profile.update(userMatch, planArray);
        } catch (Exception e) {
            res = false;
        }


        return res;
    }


    public void populateSavedPlans(View v) {
        BasicDBObject userProfileQuery = new BasicDBObject("_id", new ObjectId(ARG_USER_ID));
        DBCursor userCursor = user_profile.find(userProfileQuery);

        int i = 1;
        TableLayout tableLayout = (TableLayout) v.findViewById(R.id.main_table);
        TableRow tr_head = new TableRow(getActivity());
        tr_head.setId(100000 + i);
        tr_head.setBackgroundColor(Color.GRAY);
        tr_head.setPadding(5, 10, 5, 10);
        tr_head.setLayoutParams(new TableLayout.LayoutParams(
                TableRow.LayoutParams.FILL_PARENT,
                TableRow.LayoutParams.WRAP_CONTENT));

        TextView label_planName = new TextView(getActivity());
        label_planName.setId(20000000 + i);
        label_planName.setText("Plan Name");
        label_planName.setTextColor(Color.WHITE);
        label_planName.setPadding(5, 5, 5, 5);
        TableRow.LayoutParams params1 = new TableRow.LayoutParams(0, TableRow.LayoutParams.WRAP_CONTENT, .5f);
        label_planName.setLayoutParams(params1);
        tr_head.addView(label_planName);// add the column to the table row here

        TextView label_planType = new TextView(getActivity());
        label_planType.setId(20000001 + i);// define id that must be unique
        label_planType.setText("Type"); // set the text for the header
        label_planType.setTextColor(Color.WHITE); // set the color
        label_planType.setPadding(5, 5, 5, 5); // set the padding (if required)
        TableRow.LayoutParams params2 = new TableRow.LayoutParams(0, TableRow.LayoutParams.WRAP_CONTENT, .3f);
        label_planType.setLayoutParams(params2);
        tr_head.addView(label_planType); // add the column to the table row here


        TextView label_action = new TextView(getActivity());
        label_action.setId(20000001 + i);// define id that must be unique
        label_action.setText("Action"); // set the text for the header
        label_action.setTextColor(Color.WHITE); // set the color
        label_action.setPadding(5, 5, 5, 5); // set the padding (if required)
        TableRow.LayoutParams params3 = new TableRow.LayoutParams(0, TableRow.LayoutParams.WRAP_CONTENT, .2f);
        label_action.setLayoutParams(params3);
        tr_head.addView(label_action); // add the column to the table row here


        tableLayout.addView(tr_head, new TableLayout.LayoutParams(
                TableLayout.LayoutParams.FILL_PARENT,
                TableLayout.LayoutParams.WRAP_CONTENT));


        try {
            while (userCursor.hasNext()) {
                DBObject userDBO = userCursor.next();
                BasicDBList planDBO = (BasicDBList) userDBO.get("health_plans");

                Integer count = 0;

                while (count < planDBO.size()) {

                    DBObject planElement = (DBObject) planDBO.get(count);


                    BasicDBObject planNameQuery = new BasicDBObject("_id",
                            new ObjectId(planElement.get("plan_object_id").toString()));

                    objectIDMap.put(count, planElement.get("plan_object_id").toString());

                    DBCursor planCursor = health_plan.find(planNameQuery);

                    // Create the table row
                    TableRow tr = new TableRow(getActivity());
                    if (count % 2 != 0) tr.setBackgroundColor(Color.GRAY);
                    tr.setId(count);
                    tr.setLayoutParams(new TableRow.LayoutParams(
                            TableRow.LayoutParams.FILL_PARENT,
                            TableRow.LayoutParams.WRAP_CONTENT));

                    //Create two columns to add as table data
                    // Create a TextView to add date
                    TextView planLabel = new TextView(getActivity());
                    planLabel.setId(count);
                    planLabel.setText(planCursor.next().get("plan_name").toString());
                    planLabel.setPadding(2, 0, 5, 0);
                    planLabel.setTextColor(Color.BLACK);
                    planLabel.setLayoutParams(params1);
                    tr.addView(planLabel);


                    int familyCode = Integer.parseInt(planElement.get("plan_type").toString());

                    String planType;

                    if (familyCode == 80)
                        planType = "Individual";
                    else
                        planType = "Family";


                    TextView planTypeLBL = new TextView(getActivity());
                    planTypeLBL.setId(count);
                    planTypeLBL.setText(planType);
                    planTypeLBL.setPadding(2, 0, 5, 0);
                    planTypeLBL.setTextColor(Color.BLACK);
                    planTypeLBL.setLayoutParams(params2);
                    tr.addView(planTypeLBL);

                    final ImageButton btn_view_details = new ImageButton(getActivity());
                    btn_view_details.setId(count);// define id that must be unique
                    btn_view_details.setImageResource(R.drawable.view); // set the text for the header
                    btn_view_details.setMaxWidth(1);
                    btn_view_details.setMaxHeight(2);
                    //label_drug.setTextColor(Color.WHITE); // set the color
                    btn_view_details.setPadding(2, 2, 2, 2); // set the padding (if required)
                    btn_view_details.setLayoutParams(params3);

                    tr.addView(btn_view_details);


                    btn_view_details.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            int btnCount = btn_view_details.getId();
                            String btnObjectID = objectIDMap.get(btnCount);
                            Fragment healthPlanDetailsAPIFragment = new HealthPlanDetailsAPI();
                            Bundle args = new Bundle();
                            args.putString("USER_ID", ARG_USER_ID);
                            args.putString("HEALTHPLANOBJECTID", btnObjectID);
                            healthPlanDetailsAPIFragment.setArguments(args);
                            FragmentManager fragmentManager = getFragmentManager();
                            fragmentManager.beginTransaction().replace(R.id.content_frame, healthPlanDetailsAPIFragment).commit();

                        }
                    });


                    ImageButton btn_delete_plan = new ImageButton(getActivity());
                    btn_delete_plan.setId(count);// define id that must be unique
                    btn_delete_plan.setImageResource(R.drawable.delete); // set the text for the header
                    btn_delete_plan.setMaxWidth(1);
                    btn_delete_plan.setMaxHeight(2);
                    //label_drug.setTextColor(Color.WHITE); // set the color
                    btn_delete_plan.setPadding(2, 2, 2, 2); // set the padding (if required)
                    btn_delete_plan.setLayoutParams(params3);

                    tr.addView(btn_delete_plan);


                    // finally add this to the table row
                    tableLayout.addView(tr, new TableLayout.LayoutParams(
                            TableLayout.LayoutParams.FILL_PARENT,
                            TableLayout.LayoutParams.WRAP_CONTENT));

                    count++;
                }


            }
        } catch (Exception ex) {
            TextView savedPlansheader = (TextView) v.findViewById(R.id.savedPlansHeader);
            savedPlansheader.setText("Your Saved Plans : No Plans Saved!");
            Log.e(TAG, "Exception - " + ex.getMessage());
            Toast.makeText(getActivity(),
                    "Exception - " + ex.getMessage(), Toast.LENGTH_LONG)
                    .show();
        }


    }

}
