package edu.neu.ccs.droidnurse;

import android.app.AlertDialog;
import android.app.DatePickerDialog;
import android.app.Fragment;
import android.app.FragmentManager;
import android.content.DialogInterface;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.mongodb.BasicDBList;
import com.mongodb.BasicDBObject;
import com.mongodb.DBCollection;
import com.mongodb.DBCursor;
import com.mongodb.DBObject;

import org.bson.types.ObjectId;
import org.joda.time.DateTime;
import org.joda.time.LocalDateTime;
import org.joda.time.format.DateTimeFormatter;
import org.joda.time.format.ISODateTimeFormat;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.TimeZone;

/**
 * Created by Sandeep on 7/27/2014.
 */
public class RefillFragment extends Fragment {

    public String ARG_USER_ID;
    public ArrayList<String> rxEligibleForRefillList;
    ArrayList<String> planList = new ArrayList<String>();
    ArrayList<String> planIdList = new ArrayList<String>();

    public RefillFragment() {
        // Required empty public constructor
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {

        ARG_USER_ID = getArguments().getString("USER_ID");
        rxEligibleForRefillList = new ArrayList<String>(getArguments().getStringArrayList("RX_ARRAYLIST"));
        final View rootView = inflater.inflate(R.layout.fragment_rx_add_refill, container, false);
        final Spinner rxListSpinner = (Spinner)rootView.findViewById(R.id.refill_rx_spinner);

        if(rxEligibleForRefillList == null || rxEligibleForRefillList.isEmpty()) {
            noRxToRefillPormpt();
        }
        else
        {
            /*String[] refillRxArray =refillRxList();
            if(refillRxArray == null || refillRxArray.length==0)
                 noRxToRefillPormpt();

            else {*/
                ArrayAdapter<String> spinnerArrayAdapter = new ArrayAdapter<String>(getActivity(), android.R.layout.simple_spinner_item,rxEligibleForRefillList ); //selected item will look like a spinner set from XML
                spinnerArrayAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                rxListSpinner.setAdapter(spinnerArrayAdapter);
            //}
        }



        rxListSpinner.setOnItemSelectedListener(
                new AdapterView.OnItemSelectedListener()

                {
                    @Override
                    public void onItemSelected(AdapterView<?> parent, View view,
                                               int pos, long id) {


                        autoPopulateFields(rxListSpinner.getSelectedItem().toString());

                    }

                    @Override
                    public void onNothingSelected(AdapterView<?> parent) {

                    }
                });







        Button setDateBtn = (Button) rootView.findViewById(R.id.select_refill_date);
        setDateBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                int mYear, mMonth, mDay;
                // Process to get Current Date
                final Calendar c = Calendar.getInstance();
                //final TextView txtDate = (TextView)v.findViewById(R.id.date_lbl);

                mYear = c.get(Calendar.YEAR);
                mMonth = c.get(Calendar.MONTH);
                mDay = c.get(Calendar.DAY_OF_MONTH);

                // Launch Date Picker Dialog
                DatePickerDialog dpd = new DatePickerDialog(getActivity(),
                        new DatePickerDialog.OnDateSetListener() {

                            @Override
                            public void onDateSet(DatePicker view, int year,
                                                  int monthOfYear, int dayOfMonth) {

                                TextView txtDate = (TextView) rootView.findViewById(R.id.txtRefillDate);
                                // Display Selected

                                monthOfYear = monthOfYear +1;

                                String tempDayOfMonth, tempMonthOfYear;

                                if(dayOfMonth <=9)
                                    tempDayOfMonth = "0"+ dayOfMonth;
                                else
                                    tempDayOfMonth = String.valueOf(dayOfMonth);

                                if(monthOfYear <=9)
                                    tempMonthOfYear = "0"+monthOfYear;
                                else
                                tempMonthOfYear = String.valueOf(monthOfYear);



                                txtDate.setText("Refilled On : " + tempMonthOfYear + "-"
                                        + tempDayOfMonth + "-" + year);

                            }

                        }, mYear, mMonth, mDay
                );
                dpd.getDatePicker().setMaxDate(new Date().getTime());
                dpd.show();
            }
        });



        final Spinner planSpinner = (Spinner)rootView.findViewById(R.id.plan_spinner);
        planSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {

                EditText editTxtEstimatedCopay = (EditText)rootView.findViewById(R.id.editTxtEstimatedCopay);
                EditText editTxtEstimatedCoverage = (EditText)rootView.findViewById(R.id.editTxtEstimatedCoverage);

                if(planSpinner.getSelectedItem().toString().contentEquals("Cash"))
                {
                    editTxtEstimatedCopay.setText("0.00");
                    editTxtEstimatedCoverage.setText("0.00");

                    editTxtEstimatedCoverage.setEnabled(false);
                    editTxtEstimatedCopay.setEnabled(false);
                }
                else
                {
                    editTxtEstimatedCoverage.setEnabled(true);
                    editTxtEstimatedCopay.setEnabled(true);
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });



        Button recordRefillBTN = (Button)rootView.findViewById(R.id.record_refill_btn);
        recordRefillBTN.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                boolean res = true;
                double tally;


                EditText totalCost = (EditText)rootView.findViewById(R.id.totalCost);
                Spinner plan = (Spinner)rootView.findViewById(R.id.plan_spinner);
                EditText planCoverage = (EditText)rootView.findViewById(R.id.editTxtEstimatedCoverage);
                EditText planCopay = (EditText)rootView.findViewById(R.id.editTxtEstimatedCopay);

                if(plan.getSelectedItem().toString().contentEquals("Cash"))
                {
                    planCoverage.setText("0.00");
                    planCopay.setText("0.00");
                    res = saveRefillToDB();
                }
                else
                {
                    tally = Double.parseDouble(planCoverage.getText().toString()) + Double.parseDouble(planCopay.getText().toString());

                    if(tally == Double.parseDouble(totalCost.getText().toString()))
                    {
                        res = saveRefillToDB();
                    }
                    else
                    {
                        Toast.makeText(getActivity(), "Plan's Coverage and Copay does not match with the total cost",
                                Toast.LENGTH_LONG).show();
                    }

                }

                if(res == false)
                {
                    Toast.makeText(getActivity(), "Please check your inputs",
                            Toast.LENGTH_LONG).show();
                }
                else
                {
                    Toast.makeText(getActivity(), "Refill Recorded!! :)", Toast.LENGTH_LONG).show();
                    Fragment RXFragment = new RxFragment();
                    Bundle args = new Bundle();
                    args.putString("USER_ID", ARG_USER_ID);
                    RXFragment.setArguments(args);
                    FragmentManager fragmentManager = getFragmentManager();
                    fragmentManager.beginTransaction().replace(R.id.content_frame, RXFragment).commit();

                }



            }
        });

        return  rootView;

    }

    public void noRxToRefillPormpt()
    {
        AlertDialog.Builder dlgAlert = new AlertDialog.Builder(getActivity());
        dlgAlert.setMessage("No prescription eligible for refill found in your profile!");
        dlgAlert.setTitle("No Rx Available!");
        DialogInterface.OnClickListener dialogClickListener = new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {

                Fragment RXFragment = new RxFragment();
                Bundle args = new Bundle();
                args.putString("USER_ID", ARG_USER_ID);
                args.putBoolean("SHOW_ACTIVE_RX", true);
                RXFragment.setArguments(args);
                FragmentManager fragmentManager = getFragmentManager();
                fragmentManager.beginTransaction().replace(R.id.content_frame, RXFragment).commit();

            }
        };
        dlgAlert.setPositiveButton("OK", dialogClickListener);
        dlgAlert.create().show();
    }





    public void autoPopulateFields(String selectedRx)
    {
        int refillNumber = 1;
        String drugName="", UOM="";

        TextView txtPrescription = (TextView)getActivity().findViewById(R.id.txtPrescription);
        TextView txtRefillNumber = (TextView)getActivity().findViewById(R.id.txtRefillCount);
        TextView txtDrugName = (TextView)getActivity().findViewById(R.id.txtDrug);
        TextView txtUOM = (TextView)getActivity().findViewById(R.id.txtUOM);
        Spinner planSpinner = (Spinner)getActivity().findViewById(R.id.plan_spinner);



        DBCollection prescription =  MongoConnect.getCollection(MongoConnect.dbCollections.prescription);
        BasicDBObject rxQuery = new BasicDBObject();
        List<BasicDBObject> obj = new ArrayList<BasicDBObject>();
        obj.add(new BasicDBObject("_id", selectedRx));
        obj.add(new BasicDBObject("isActive", true));
        rxQuery.put("$and", obj);


        DBCollection drug_details = MongoConnect.getCollection(MongoConnect.dbCollections.drug_details);
        BasicDBObject drugQuery = new BasicDBObject();

        DBCollection code = MongoConnect.getCollection(MongoConnect.dbCollections.code);
        BasicDBObject codeQuery = new BasicDBObject();


        DBCursor rxCursor = prescription.find(rxQuery);
        DBCursor drugCursor;
        DBCursor codeCursor;


            while (rxCursor.hasNext()) {
                DBObject rxDBO = rxCursor.next();
                try {
                    BasicDBList refillList = (BasicDBList) rxDBO.get("refills");
                    refillNumber = refillNumber + refillList.size();
                }
                catch (Exception e)
                {

                }

                drugQuery.put("NDC", rxDBO.get("drug_NDC").toString());
                drugCursor = drug_details.find(drugQuery);
                drugName = drugCursor.next().get("drug_name").toString();


                DBObject sig = (DBObject)rxDBO.get("sig");

                codeQuery.put("_id", Integer.parseInt(sig.get("UOM_code").toString()));
                codeCursor =code.find(codeQuery);
                UOM = codeCursor.next().get("meaning_text").toString();

            }

        txtPrescription.setText("Rx : "+ selectedRx);
        txtRefillNumber.setText("Refill# : " + refillNumber);
        txtDrugName.setText("Drug Name : " + drugName);
        txtUOM.setText("UOM : " + UOM);


        DBCollection user_profile = MongoConnect.getCollection(MongoConnect.dbCollections.user_profile);
        DBCollection health_plan = MongoConnect.getCollection(MongoConnect.dbCollections.health_plan);

        BasicDBObject userProfileQuery = new BasicDBObject("_id", new ObjectId(ARG_USER_ID));
        DBCursor userCursor = user_profile.find(userProfileQuery);
        try {
            while (userCursor.hasNext()) {
                DBObject userDBO = userCursor.next();
                BasicDBList planDBO = (BasicDBList) userDBO.get("health_plans");

                Integer count = 0;

                planList.add("Cash");
                planIdList.add("53dc3ee1e4b086cdeda0ec39");

                while (count < planDBO.size()) {

                    DBObject planElement = (DBObject) planDBO.get(count);
                    BasicDBObject planNameQuery = new BasicDBObject("_id",
                            new ObjectId(planElement.get("plan_object_id").toString()));

                    DBCursor planCursor = health_plan.find(planNameQuery);

                    planList.add(planCursor.next().get("plan_name").toString());
                    planIdList.add(planElement.get("plan_object_id").toString());

                    count++;
                }
            }
        }
        catch (Exception e) {

        }

        ArrayAdapter<String> spinnerArrayAdapter = new ArrayAdapter<String>(getActivity(), android.R.layout.simple_spinner_item,planList ); //selected item will look like a spinner set from XML
        spinnerArrayAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        planSpinner.setAdapter(spinnerArrayAdapter);

    }





    public boolean saveRefillToDB()
    {
        boolean result = true;

        TextView prescription = (TextView) getActivity().findViewById(R.id.txtPrescription);
        TextView refilltxt = (TextView)getActivity().findViewById(R.id.txtRefillCount);
        TextView refillDate = (TextView)getActivity().findViewById(R.id.txtRefillDate);
        EditText refillQty = (EditText)getActivity().findViewById(R.id.refillQuantity);
        EditText totalCost = (EditText)getActivity().findViewById(R.id.totalCost);
        Spinner plan = (Spinner)getActivity().findViewById(R.id.plan_spinner);
        EditText planCoverage = (EditText)getActivity().findViewById(R.id.editTxtEstimatedCoverage);
        EditText planCopay = (EditText)getActivity().findViewById(R.id.editTxtEstimatedCopay);

        String prescriptionNumber, refillCount, refillQuantity, refillDateText, totalCostValue, planId, planCoverValue, planCopayValue;
        int intRefillCount, intRefillQuantity;
        double doubleTotalCostValue, doublePlanCoverValue, doublePlanCopayValue;


      try
        {
            prescriptionNumber = prescription.getText().toString().substring(5);
            refillCount = refilltxt.getText().toString().substring(10).trim();
            refillQuantity = refillQty.getText().toString();
            refillDateText = refillDate.getText().toString().substring(13).trim();
            totalCostValue = totalCost.getText().toString();
            planId = planIdList.get(planList.indexOf(plan.getSelectedItem().toString()));
            planCoverValue = planCoverage.getText().toString();
            planCopayValue = planCopay.getText().toString();

            if (planId.contentEquals("53dc3ee1e4b086cdeda0ec39")) {
                doublePlanCoverValue = 0;
                doublePlanCopayValue = 0;
            } else {
                doublePlanCoverValue = Double.parseDouble(planCoverValue);
                doublePlanCopayValue = Double.parseDouble(planCopayValue);
            }

            intRefillCount = Integer.parseInt(refillCount);
            intRefillQuantity = Integer.parseInt(refillQuantity);
            doubleTotalCostValue = Double.parseDouble(totalCostValue);

            DateFormat formatter = new SimpleDateFormat("MM-dd-yyyy");
            Date selectedDate = null;
            selectedDate = formatter.parse(refillDateText);
            DBCollection refill = MongoConnect.getCollection(MongoConnect.dbCollections.refill);

            BasicDBObject document = new BasicDBObject();
            document.put("refill_count", intRefillCount);
            document.put("refill_date", selectedDate);
           // document.put("refill_date", refillDateText);
            document.put("refill_quantity", intRefillQuantity);
            document.put("qty_remaining", intRefillQuantity);
            document.put("total_cost", doubleTotalCostValue);
            document.put("isActive", true);

            BasicDBObject planDetail = new BasicDBObject();
            planDetail.put("plan_object_id", planId);
            planDetail.put("plan_cover", doublePlanCoverValue);
            planDetail.put("plan_copay", doublePlanCopayValue);
            document.put("insurance_details", planDetail);


            DateTimeFormatter parser= ISODateTimeFormat.dateHourMinuteSecond();
            LocalDateTime dt=new LocalDateTime();
            LocalDateTime currentDateTime =parser.parseLocalDateTime(parser.print(dt));
            TimeZone.setDefault(TimeZone.getTimeZone("UTC"));

            BasicDBObject notificationDetail = new BasicDBObject();
            notificationDetail.put("last_update_time", currentDateTime.toDate());
            notificationDetail.put("note_counter", 0);
            document.append("notification", notificationDetail);

            refill.insert(document);
            ObjectId id = (ObjectId)document.get( "_id" );

            DBCollection prescriptionCollection = MongoConnect.getCollection(MongoConnect.dbCollections.prescription);
            BasicDBObject refillArrayElement = new BasicDBObject();
            refillArrayElement.put("$addToSet", new BasicDBObject("refills", id.toString()));
            BasicDBObject rxMatch = new BasicDBObject();
            rxMatch.put("_id", prescriptionNumber);
            prescriptionCollection.update(rxMatch, refillArrayElement);

            result =true;
        }
       catch (Exception e)
        {
            result = false;

        }

        return result;

    }
}
