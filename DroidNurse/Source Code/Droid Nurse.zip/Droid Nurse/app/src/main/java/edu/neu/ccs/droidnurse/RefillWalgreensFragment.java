package edu.neu.ccs.droidnurse;

import android.app.Fragment;
import android.app.FragmentManager;
import android.os.Bundle;
import android.os.StrictMode;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Spinner;
import com.google.gson.Gson;
import org.apache.http.HttpResponse;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.util.EncodingUtils;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.Map;

/**
 * Created by Sandeep on 7/28/2014.
 */
public class RefillWalgreensFragment extends Fragment {

    Gson gson = new Gson();
    String token;
    ArrayList<String> ARG_RX_LIST = new ArrayList<String>();
    ArrayList<String> ARG_RESULT_SINGLE_RX = new ArrayList<String>();
    String ARG_USER_ID;
    String RX = "";


    public RefillWalgreensFragment() {
        // Required empty public constructor
    }


    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {

        View v = inflater.inflate(R.layout.fragment_refill_walgreens, container, false);

        ARG_RX_LIST = getArguments().getStringArrayList("RX_ARRAYLIST");
        ARG_USER_ID = getArguments().getString("USER_ID");

        WebView webview = (WebView) v.findViewById(R.id.webView);
        webview.setEnabled(false);
        webview.setWebViewClient(new WebViewClient() {
            @Override
            public void onReceivedError(WebView view, int errorCode, String description, String failingUrl) {

                if(failingUrl.contains("=back")) {

                    Fragment addRefills = new RefillFragment();
                    Bundle args = new Bundle();
                    args.putString("USER_ID", ARG_USER_ID);
                    ARG_RESULT_SINGLE_RX.add(RX);
                    args.putStringArrayList("RX_ARRAYLIST", ARG_RESULT_SINGLE_RX);
                    addRefills.setArguments(args);
                    FragmentManager fragmentManager = getFragmentManager();
                    fragmentManager.beginTransaction().replace(R.id.content_frame, addRefills).commit();

                }
                else if (failingUrl.contains("cancel"))
                {
                    Fragment rxFragment = new RxFragment();
                    Bundle args = new Bundle();
                    args.putString("USER_ID", ARG_USER_ID);
                    args.putBoolean("SHOW_ACTIVE_RX", true);
                    rxFragment.setArguments(args);
                    FragmentManager fragmentManager = getFragmentManager();
                    fragmentManager.beginTransaction().replace(R.id.content_frame, rxFragment).commit();

                }


            }
        });



        final Spinner rxSpinner = (Spinner)v.findViewById(R.id.walgreens_rx_spinner);
        ArrayAdapter<String> spinnerArrayAdapter = new ArrayAdapter<String>(getActivity(), android.R.layout.simple_spinner_item, ARG_RX_LIST); //selected item will look like a spinner set from XML
        spinnerArrayAdapter.setDropDownViewResource(android.R.layout.simple_spinner_item);
        rxSpinner.setAdapter(spinnerArrayAdapter);
           rxSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                try {
                    RX = rxSpinner.getSelectedItem().toString();
                    postRequest();
                }
                catch (Exception e) {
               // Log.i("My Exception :", e.getMessage().toString());
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });



        return v;
    }

    public void postRequest() {

        WebView webview = (WebView) getActivity().findViewById(R.id.webView);

        String webRes = getWebserviceResponse();
        if (webRes != null) {
            Map<String, String> webResMap = gson.fromJson(webRes, Map.class);
            String strLandingUrl = webResMap.get("landingUrl");
            token = webResMap.get("token");

            try {

                RequestObject requestObj = new RequestObject(token);
                String gsonStr = gson.toJson(requestObj);
                byte[] postData = EncodingUtils.getBytes(gsonStr, "BASE64");
                WebSettings webSettings = webview.getSettings();
                webSettings.setJavaScriptEnabled(true);
                webview.setEnabled(true);
                webview.postUrl(strLandingUrl, postData);

            }
            catch (Exception e)
            {
                e.printStackTrace();
            }
        }
    }


    public String getWebserviceResponse()
    {
        InputStream inputStream = null;
        String response = "";
        String json = "";
        String walgreensAPIURL = "https://services-qa.walgreens.com/api/util/mweb5url";
        try {

            // 1. create HttpClient
            HttpClient httpclient = new DefaultHttpClient();

            // 2. make POST request to the given URL
            HttpPost httpPost = new HttpPost(walgreensAPIURL);

            // 3. build jsonObject
            JSONObject params = new JSONObject();
            params.put("transaction", "refillByScan");
            params.put("apiKey", "7515c74ed2dc3ca515d87e84493f6d14");
            params.put("devinf", "Android,2.3.3");
            params.put("act", "mweb5Url");
            params.put("view", "mweb5UrlJSON");
            params.put("affId", "extest1");
            params.put("appver", "3.3");

            json = params.toString();

            // 5. set json to StringEntity
            StringEntity se = new StringEntity(json);

            // 6. set httpPost Entity
            httpPost.setEntity(se);

            // 7. Set some headers to inform server about the type of the content
            httpPost.setHeader("Accept", "application/json");
            httpPost.setHeader("Content-type", "application/json");

            // 8. Execute POST request to the given URL
            HttpResponse httpResponse = httpclient.execute(httpPost);

            // 9. receive response as inputStream
            inputStream = httpResponse.getEntity().getContent();

            // 10. convert inputstream to string
            if(inputStream != null)
                response = convertInputStreamToString(inputStream);
            else
                response = "Error";

        } catch (Exception e) {
            Log.d("InputStream", e.getLocalizedMessage());
        }

        return response;
    }


    private static String convertInputStreamToString(InputStream inputStream) throws IOException {
        BufferedReader bufferedReader = new BufferedReader( new InputStreamReader(inputStream));
        String line = "";
        String result = "";
        while((line = bufferedReader.readLine()) != null)
            result += line;
        inputStream.close();
        return result;

    }



    class RequestObject {

        String appId= "refillByScan";
        String affId= "extest1";
        String token;
        String rxNo = RX;
        String appCallBackScheme = "refillByScan://handleControl";
        String appCallBackAction = "callBackAction";
        String act = "chkExpRx";
        String devinf = "Android,4.4.3";
        String appver = "3.3";

        RequestObject(String APItoken) {
            // no-args constructor
            token = APItoken;
        }
    }


}
