package edu.neu.ccs.droidnurse;


import android.app.FragmentManager;
import android.graphics.Color;
import android.os.Bundle;
import android.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.NumberPicker;
import android.widget.TableLayout;
import android.widget.TableRow;
import android.widget.TextView;
import android.widget.Toast;

import com.mongodb.BasicDBList;
import com.mongodb.BasicDBObject;
import com.mongodb.DBCollection;
import com.mongodb.DBCursor;
import com.mongodb.DBObject;
import com.mongodb.MongoException;

import org.bson.types.ObjectId;
import org.joda.time.DateTime;
import org.joda.time.DateTimeZone;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;



/**
 * A simple {@link Fragment} subclass.
 */
public class RxFragment extends Fragment {

        public String ARG_USER_ID;
        public boolean showActiveRx;
        public ArrayList<String> rxIdList = new ArrayList<String>();
        public ArrayList<String> rxEligibleForRefillList = new ArrayList<String>();

    public RxFragment() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {

        ARG_USER_ID = getArguments().getString("USER_ID");
        showActiveRx = getArguments().getBoolean("SHOW_ACTIVE_RX");
        final View rootView = inflater.inflate(R.layout.fragment_rx, container, false);

        populateActiveRx(rootView);


        Button addRxBtn = (Button) rootView.findViewById(R.id.add_new_rx_btn);
        addRxBtn.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {

                Fragment addRXFragment = new RxFragmentAddRx();
                Bundle args = new Bundle();
                args.putString("USER_ID", ARG_USER_ID);
                args.putString("SCREEN_CODE","A");
                addRXFragment.setArguments(args);
                FragmentManager fragmentManager = getFragmentManager();
                fragmentManager.beginTransaction().replace(R.id.content_frame, addRXFragment).commit();
            }


        });


        Button showAllRxBtn = (Button)rootView.findViewById(R.id.show_all_rx_btn);
        showAllRxBtn.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {

                Fragment RXFragment = new RxFragment();
                Bundle args = new Bundle();
                args.putString("USER_ID", ARG_USER_ID);
                args.putBoolean("SHOW_ACTIVE_RX", false);
                RXFragment.setArguments(args);
                FragmentManager fragmentManager = getFragmentManager();
                fragmentManager.beginTransaction().replace(R.id.content_frame, RXFragment).commit();
            }


        });



        Button refillRxBtn = (Button)rootView.findViewById(R.id.new_refill_btn);
        refillRxBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if(rxEligibleForRefillList.isEmpty()) {
                    Toast.makeText(getActivity(), "No Rx is eligible for refill",
                            Toast.LENGTH_LONG).show();
                }
                else {
                    Fragment RefillFragment = new RefillFragment();
                    Bundle args = new Bundle();
                    args.putString("USER_ID", ARG_USER_ID);
                    args.putStringArrayList("RX_ARRAYLIST", rxEligibleForRefillList);
                    RefillFragment.setArguments(args);
                    FragmentManager fragmentManager = getFragmentManager();
                    fragmentManager.beginTransaction().replace(R.id.content_frame, RefillFragment).commit();
                }

            }
        });


        Button refillWalgreensBtn = (Button) rootView.findViewById(R.id.refill_walgreens_btn);
        refillWalgreensBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

              if (rxEligibleForRefillList.isEmpty()) {
                    Toast.makeText(getActivity(), "No Rx is eligible for refill",
                           Toast.LENGTH_LONG).show();
                }
                else {
                    Fragment RefillWalgreens = new RefillWalgreensFragment();
                    Bundle args = new Bundle();
                    args.putStringArrayList("RX_ARRAYLIST", rxEligibleForRefillList);
                    //args.putString("RX_FOR_API_REQUEST", "");
                    args.putString("USER_ID", ARG_USER_ID);
                    RefillWalgreens.setArguments(args);
                    FragmentManager fragmentManager = getFragmentManager();
                    fragmentManager.beginTransaction().replace(R.id.content_frame, RefillWalgreens).commit();
                }

            }
        });



        return rootView;

    }


    public void populateActiveRx(View v)
    {

        // Render the data in the table layout
        int i = 1;
        TableLayout tableLayout = (TableLayout)v.findViewById(R.id.main_table);
        TableRow tr_head = new TableRow(getActivity());
        tr_head.setId(100000 + i);
        tr_head.setBackgroundColor(Color.GRAY);
        tr_head.setPadding(5, 10, 5, 10);
                tr_head.setLayoutParams(new TableLayout.LayoutParams(
                        TableRow.LayoutParams.FILL_PARENT,
                        TableRow.LayoutParams.WRAP_CONTENT));

        TextView label_rx = new TextView(getActivity());
        label_rx.setId(20000000 + i);
        label_rx.setText("Rx No");
        label_rx.setTextColor(Color.WHITE);
        label_rx.setPadding(5, 5, 5, 5);
        TableRow.LayoutParams params1 = new TableRow.LayoutParams(0, TableRow.LayoutParams.WRAP_CONTENT, .3f);
        label_rx.setLayoutParams(params1);
        tr_head.addView(label_rx);// add the column to the table row here

        TextView label_drug = new TextView(getActivity());
        label_drug.setId(20000001 + i);// define id that must be unique
        label_drug.setText("Drug Name"); // set the text for the header
        label_drug.setTextColor(Color.WHITE); // set the color
        label_drug.setPadding(5, 5, 5, 5); // set the padding (if required)
        TableRow.LayoutParams params2 = new TableRow.LayoutParams(0, TableRow.LayoutParams.WRAP_CONTENT, .3f);
        label_drug.setLayoutParams(params2);
        tr_head.addView(label_drug); // add the column to the table row here

        TextView label_refill_remaining = new TextView(getActivity());
        label_refill_remaining.setId(20000001 + i);// define id that must be unique
        label_refill_remaining.setText("Refills\n Left"); // set the text for the header
        label_refill_remaining.setTextColor(Color.WHITE); // set the color
        label_refill_remaining.setPadding(5, 5, 5, 5); // set the padding (if required)
        TableRow.LayoutParams params3 = new TableRow.LayoutParams(0, TableRow.LayoutParams.WRAP_CONTENT, .2f);
        label_refill_remaining.setLayoutParams(params3);
        tr_head.addView(label_refill_remaining); // add the column to the table row here

        TextView label_view_rx = new TextView(getActivity());
        label_view_rx.setId(20000001 + i);// define id that must be unique
        label_view_rx.setText("View Rx"); // set the text for the header
        label_view_rx.setTextColor(Color.WHITE); // set the color
        label_view_rx.setPadding(5, 5, 5, 5); // set the padding (if required)
        TableRow.LayoutParams params4 = new TableRow.LayoutParams(0, TableRow.LayoutParams.WRAP_CONTENT, .2f);
        label_view_rx.setLayoutParams(params4);
        tr_head.addView(label_view_rx);


        tableLayout.addView(tr_head, new TableLayout.LayoutParams(
                TableLayout.LayoutParams.FILL_PARENT,
                TableLayout.LayoutParams.WRAP_CONTENT));


        DBCollection user_profile = MongoConnect.getCollection(MongoConnect.dbCollections.user_profile);
        BasicDBObject whereQuery = new BasicDBObject();
        whereQuery.put("_id", new ObjectId(ARG_USER_ID));
        DBCursor cursor = user_profile.find(whereQuery);

        DBObject DBO = cursor.next();

        BasicDBList rxList = (BasicDBList) DBO.get("Rx");


        DBCollection prescription = MongoConnect.getCollection(MongoConnect.dbCollections.prescription);
        BasicDBObject rxQuery = new BasicDBObject();
        List<BasicDBObject> obj = new ArrayList<BasicDBObject>();
        obj.add(new BasicDBObject("_id", new BasicDBObject("$in", rxList)));

        DBCollection refill = MongoConnect.getCollection(MongoConnect.dbCollections.refill);


        // To fetch details of the drug
        DBCollection drug_details = MongoConnect.getCollection(MongoConnect.dbCollections.drug_details);
        BasicDBObject drugQuery = new BasicDBObject();


        if(showActiveRx) {
            obj.add(new BasicDBObject("isActive", true));
            rxQuery.put("$and", obj);

        }

        try
        {

        DBCursor rxCursor = prescription.find(rxQuery);
        Integer count = 0;


            while (rxCursor.hasNext()) {

                int refill_remaining = 0;
                int refillListSize;
                boolean activeRefillFound = false;

                DBObject rxDBO = rxCursor.next();
                BasicDBList refillList = (BasicDBList) rxDBO.get("refills");

                BasicDBObject refillQuery = new BasicDBObject();
                List<BasicDBObject> refillObj = new ArrayList<BasicDBObject>();
                refillObj.add(new BasicDBObject("_id", new BasicDBObject("$in", refillList)));
                refillObj.add(new BasicDBObject("isActive", true));
                refillQuery.put("$and", refillObj);
                DBCursor refillCursor = refill.find(refillQuery);

                try {
                    if(refillCursor.hasNext())
                        activeRefillFound = true;
                } catch (Exception e) {

                }


                rxIdList.add(count, rxDBO.get("_id").toString());

                // Create the table row
                TableRow tr = new TableRow(getActivity());
                if (count % 2 != 0) tr.setBackgroundColor(Color.GRAY);
                tr.setId(count);
                tr.setLayoutParams(new TableRow.LayoutParams(
                        TableRow.LayoutParams.FILL_PARENT,
                        TableRow.LayoutParams.WRAP_CONTENT));

                //Create two columns to add as table data
                // Create a TextView to add date
                TextView labelRx = new TextView(getActivity());
                labelRx.setId(count);
                labelRx.setText(rxDBO.get("_id").toString());
                labelRx.setPadding(2, 0, 5, 0);
                labelRx.setTextColor(Color.BLACK);
                labelRx.setLayoutParams(params1);
                tr.addView(labelRx);



                drugQuery.put("NDC", rxDBO.get("drug_NDC").toString());

                DBCursor drugCursor = drug_details.find(drugQuery);
                TextView labelDrug = new TextView(getActivity());
                labelDrug.setId(count);
                //labelDrug.setText(rxDBO.get("drug_NDC").toString());
                labelDrug.setText(drugCursor.next().get("drug_name").toString());
                labelDrug.setTextColor(Color.BLACK);
                labelDrug.setLayoutParams(params2);
                tr.addView(labelDrug);

                try {

                    if (refillList == null)
                        refillListSize = 0;
                    else
                        refillListSize = refillList.size();
                    refill_remaining = Integer.parseInt(rxDBO.get("no_of_refills").toString()) - refillListSize;

                    if (refill_remaining > 0 && rxDBO.get("isActive").toString() == "true" && activeRefillFound == false)
                        rxEligibleForRefillList.add(rxDBO.get("_id").toString());

                } catch (Exception e) {

                }


                TextView labelRefillRemaining = new TextView(getActivity());
                labelRefillRemaining.setId(count);
                labelRefillRemaining.setText(String.valueOf(refill_remaining));
                labelRefillRemaining.setTextColor(Color.BLACK);
                labelRefillRemaining.setLayoutParams(params3);

                tr.addView(labelRefillRemaining);


                //TODO : Add fragment and functionality to btn_rx_details
                ImageButton btn_rx_details = new ImageButton(getActivity());
                btn_rx_details.setId(count);// define id that must be unique
                btn_rx_details.setImageResource(R.drawable.view); // set the text for the header
                btn_rx_details.setMaxWidth(3);
                btn_rx_details.setMaxHeight(3);
                //label_drug.setTextColor(Color.WHITE); // set the color
                btn_rx_details.setPadding(5, 5, 5, 5); // set the padding (if required)
                btn_rx_details.setLayoutParams(params4);

                tr.addView(btn_rx_details); // add the column to the table row here


                // finally add this to the table row
                tableLayout.addView(tr, new TableLayout.LayoutParams(
                        TableLayout.LayoutParams.FILL_PARENT,
                        TableLayout.LayoutParams.WRAP_CONTENT));


                count++;
            }
        }
        catch (MongoException e) {

           Button refillRxButton, refillWalgreensButton, showAllRxButton;

            refillRxButton = (Button)v.findViewById(R.id.new_refill_btn);
            refillWalgreensButton = (Button)v.findViewById(R.id.refill_walgreens_btn);
            showAllRxButton = (Button)v.findViewById(R.id.show_all_rx_btn);
            refillRxButton.setEnabled(false);
            refillWalgreensButton.setEnabled(false);
            showAllRxButton.setEnabled(false);
        }




    }



    }
