package edu.neu.ccs.droidnurse;

import android.app.AlertDialog;
import android.app.Fragment;
import android.app.FragmentManager;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.ArrayAdapter;
import android.widget.Toast;

import com.mongodb.BasicDBObject;
import com.mongodb.DBCollection;

import org.bson.types.ObjectId;
import org.joda.time.DateTime;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

/**
 * Created by Sandeep on 7/25/2014.
 */


public class RxFragmentAddRx extends Fragment {

    private static final String TAG = "RxFragmentAddRx";
    private static final String SLASHDELIMITER = "/";
    private static final String COMMADELIMITER = ",";
    public String ARG_USER_ID;
    boolean confirmed;

    /*
       Below String are used for bundle arguments when navigation is made between multiple screens
       A-> Navigation from MyPrescription to AddRX page
       B-> Navigation from SearchPrescriber to AddRX page
       C-> Navigation from PhyscianDetailsAPI to AddRX page
       D1-> Navigation from SearchDrug to AddRX page
       D2-> Navigation from DrugDetailsAPI to AddRX page
    */
    public String SCREEN_CODE;
    public String NPINUMBER;
    public String PRESCRIBERFNAME;
    public String PRESCRIBERLNAME;
    public String RXNUMBER;
    public String NDCNUMBER;
    public String NDCNAME;
    public String NO_OF_REFILLS;
    public String WRITTENDATE;
    public String EXPIRYDATE;
    public String DRUGCOUNT;
    public String DRUGDOSAGE;
    public String DOSAGECOUNT;
    public String DOSAGEINTERVAL;

    EditText txtRXNO, txtNoOfRefills, txtWrittenDate, txtExpiryDate, txtDrugCount, txtDosageCount;
    TextView tvPrescriberNPI, tvDrugNDC;
    Spinner spDrugDosage, spDosageInterval;

    public RxFragmentAddRx() {
        // Required empty public constructor
    }

    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {

        View v = inflater.inflate(R.layout.fragment_rx_add_rx, container, false);

        ARG_USER_ID = getArguments().getString("USER_ID");
        SCREEN_CODE = getArguments().getString("SCREEN_CODE");

        txtRXNO = (EditText) v.findViewById(R.id.rx_no);
        txtNoOfRefills = (EditText) v.findViewById(R.id.refill_count);
        txtWrittenDate = (EditText) v.findViewById(R.id.written_date);
        txtExpiryDate = (EditText) v.findViewById(R.id.expiry_date);
        txtDrugCount = (EditText) v.findViewById(R.id.sig_count);
        txtDosageCount = (EditText) v.findViewById(R.id.sig_times_count);

        tvPrescriberNPI = (TextView) v.findViewById(R.id.prescriber);
        tvDrugNDC = (TextView) v.findViewById(R.id.drug);

        spDrugDosage = (Spinner) v.findViewById(R.id.uom_spinner);
        spDosageInterval = (Spinner) v.findViewById(R.id.interval_spinner);


    /*
       Below String are used for bundle arguments when navigation is made between multiple screens
       A-> Navigation from MyPrescription to AddRX page
       B-> Navigation from SearchPrescriber to AddRX page
       C-> Navigation from PhyscianDetailsAPI to AddRX page
       D1-> Navigation from SearchDrug to AddRX page
       D2-> Navigation from DrugDetailsAPI to AddRX page
    */
        if ((SCREEN_CODE.toUpperCase().equals("B")) || (SCREEN_CODE.toUpperCase().equals("C")) ||
                (SCREEN_CODE.toUpperCase().equals("D1")) || (SCREEN_CODE.toUpperCase().equals("D2"))) {
            RXNUMBER = getArguments().getString("RXNUMBER");
            NPINUMBER = getArguments().getString("NPINUMBER");
            PRESCRIBERFNAME = getArguments().getString("PRESCRIBERFNAME");
            PRESCRIBERLNAME = getArguments().getString("PRESCRIBERLNAME");
            NDCNUMBER = getArguments().getString("NDCNUMBER");
            NDCNAME = getArguments().getString("NDCNAME");
            NO_OF_REFILLS = getArguments().getString("NO_OF_REFILLS");
            WRITTENDATE = getArguments().getString("WRITTENDATE");
            EXPIRYDATE = getArguments().getString("EXPIRYDATE");
            DRUGCOUNT = getArguments().getString("DRUGCOUNT");
            DRUGDOSAGE = getArguments().getString("DRUGDOSAGE");
            DOSAGECOUNT = getArguments().getString("DOSAGECOUNT");
            DOSAGEINTERVAL = getArguments().getString("DOSAGEINTERVAL");

            txtRXNO.setText(RXNUMBER);

            if (!(NPINUMBER == null)) {
                tvPrescriberNPI.setText(NPINUMBER + SLASHDELIMITER + PRESCRIBERLNAME + COMMADELIMITER + PRESCRIBERFNAME);
            }
            if (!(NDCNUMBER == null)) {
                tvDrugNDC.setText(NDCNUMBER + SLASHDELIMITER + NDCNAME);
            }

            txtNoOfRefills.setText(NO_OF_REFILLS);
            txtWrittenDate.setText(WRITTENDATE);
            txtExpiryDate.setText(EXPIRYDATE);
            txtDrugCount.setText(DRUGCOUNT);
            txtDosageCount.setText(DOSAGECOUNT);

            ArrayAdapter drugDosageAdapter = (ArrayAdapter) spDrugDosage.getAdapter();
            int drugDosageSpinnerPosition = drugDosageAdapter.getPosition(DRUGDOSAGE);
            spDrugDosage.setSelection(drugDosageSpinnerPosition);

            ArrayAdapter dosageIntervalAdapter = (ArrayAdapter) spDosageInterval.getAdapter();
            int dosageIntervalSpinnerPosition = dosageIntervalAdapter.getPosition(DOSAGEINTERVAL);
            spDosageInterval.setSelection(dosageIntervalSpinnerPosition);

        }

        Button submit_rx, back_btn, btnAddPresciber, btnSearchDrug;
        btnAddPresciber = (Button) v.findViewById(R.id.prescriber_search_button);
        btnSearchDrug = (Button) v.findViewById(R.id.drug_search_button);
        submit_rx = (Button) v.findViewById(R.id.submit_new_rx);
        back_btn = (Button) v.findViewById(R.id.rx_back_btn);

        btnAddPresciber.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                NavigateToSearchPrescriberScreen();
            }
        });

        btnSearchDrug.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                NavigateToSearchDrugScreen();
            }
        });

        back_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                backToRxMainScreen();
            }
        });


        submit_rx.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if (validateFields()) {
                    // if (sigConfirmed()) {

                    // insert rx into db;
                    boolean res = insertRxToDB();

                    if (res) {
                        AlertDialog.Builder dlgAlert = new AlertDialog.Builder(getActivity());
                        dlgAlert.setMessage("Prescription saved successfully");
                        dlgAlert.setTitle("Rx Saved!");
                        dlgAlert.setPositiveButton("OK", null);
                        dlgAlert.setCancelable(true);
                        dlgAlert.create().show();
                        backToRxMainScreen();


                    } else {
                        AlertDialog.Builder dlgAlert = new AlertDialog.Builder(getActivity());
                        dlgAlert.setMessage("An error occurred while saving.\n" +
                                        "1)Duplicate Rx numbers are not allowed.\n" +
                                        "2) Dates should exactly be in \"dd-MM-yyyy\" format\n" +
                                        "3) Rx written date cannot be a future date or beyond expiry date.\n" +
                                        "4) Rx expiry date cannot be a date in the past"
                        );
                        dlgAlert.setTitle("Error!");
                        dlgAlert.setPositiveButton("OK", null);
                        dlgAlert.setCancelable(true);
                        dlgAlert.create().show();
                    }


                    //}
                } else {
                    AlertDialog.Builder dlgAlert = new AlertDialog.Builder(getActivity());
                    dlgAlert.setMessage("An error occurred while saving.\n" +
                                    "1)Duplicate Rx numbers are not allowed.\n" +
                                    "2) Dates should exactly be in \"dd-MM-yyyy\" format\n" +
                                    "3) Rx written date cannot be a future date or beyond expiry date.\n" +
                                    "4) Rx expiry date cannot be a date in the past"
                    );
                    dlgAlert.setTitle("Error..Invalid Input!");
                    dlgAlert.setPositiveButton("OK", null);
                    dlgAlert.setCancelable(true);
                    dlgAlert.create().show();
                }

            }
        });


        return v;
    }


    public boolean validateFields() {
        boolean valid = true;


        EditText rx_no, refill_count, written_date, expiry_date, sig_count, sig_times_count;
        TextView prescriber, drug;

        rx_no = (EditText) getActivity().findViewById(R.id.rx_no);
        refill_count = (EditText) getActivity().findViewById(R.id.refill_count);
        written_date = (EditText) getActivity().findViewById(R.id.written_date);
        expiry_date = (EditText) getActivity().findViewById(R.id.expiry_date);
        sig_count = (EditText) getActivity().findViewById(R.id.sig_count);
        sig_times_count = (EditText) getActivity().findViewById(R.id.sig_times_count);


        prescriber = (TextView) getActivity().findViewById(R.id.prescriber);
        drug = (TextView) getActivity().findViewById(R.id.drug);


        if (rx_no.getText().toString().trim().matches("") ||
                rx_no.getText().toString().trim().length() != 13 ||
                refill_count.getText().toString().trim().matches("") ||
                written_date.getText().toString().trim().length() != 10 ||
                expiry_date.getText().toString().trim().length() != 10 ||
                sig_count.getText().toString().trim().matches("") ||
                sig_times_count.getText().toString().trim().matches("") ||
                prescriber.getText().toString().trim().matches("") ||
                drug.getText().toString().trim().matches("")) {
            valid = false;
        }

        try {
            DateFormat formatter = new SimpleDateFormat("dd-MM-yyyy");
            formatter.setLenient(false);
            Date writtenDate = formatter.parse(written_date.getText().toString());
            Date expiryDate = formatter.parse(expiry_date.getText().toString());
            Date today = formatter.parse(DateTime.now().toString("dd-MM-yyyy"));

            if (writtenDate.after(expiryDate) || writtenDate.after(today) || expiryDate.before(today)) {
                valid = false;
            }


        } catch (Exception e) {
            valid = false;
        }


        return valid;
    }


    /*public boolean sigConfirmed() {

        String sigText = "";
        final int d;

        Spinner uom_spinner, interval_spinner;
        EditText sig_count, sig_times_count;

        sig_count = (EditText) getActivity().findViewById(R.id.sig_count);
        sig_times_count = (EditText) getActivity().findViewById(R.id.sig_times_count);

        uom_spinner = (Spinner) getActivity().findViewById(R.id.uom_spinner);
        interval_spinner = (Spinner) getActivity().findViewById(R.id.interval_spinner);

        sigText = "Take " + sig_count.getText().toString() +
                " " + uom_spinner.getSelectedItem().toString() +
                " " + sig_times_count.getText().toString() +
                " times per " + interval_spinner.getSelectedItem().toString();


        AlertDialog.Builder dlgAlert = new AlertDialog.Builder(getActivity());
        dlgAlert.setMessage("Please check your input & make sure they are valid");
        dlgAlert.setTitle("Error..Invalid Input!");
        dlgAlert.setPositiveButton("OK", null);
        dlgAlert.setCancelable(true);
        dlgAlert.create().show();

        AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());
        builder.setTitle("Confirm Your Sig");
        builder.setMessage("Please confirm if the following sig is correct :\n \"" + sigText +"\"");
        DialogInterface.OnClickListener dialogClickListener = new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {

                        confirmed = true;

            }
        };

        builder.setPositiveButton("Yes", dialogClickListener);
        builder.setNegativeButton("No", null);
        builder.show();

        return confirmed;
    }*/


    public boolean insertRxToDB() {

        int UOMCode = 60, intervalCode = 50;
        EditText rx_no, refill_count, written_date, expiry_date, sig_count, sig_times_count;
        TextView prescriber, drug;

        rx_no = (EditText) getActivity().findViewById(R.id.rx_no);
        refill_count = (EditText) getActivity().findViewById(R.id.refill_count);
        written_date = (EditText) getActivity().findViewById(R.id.written_date);
        expiry_date = (EditText) getActivity().findViewById(R.id.expiry_date);
        sig_count = (EditText) getActivity().findViewById(R.id.sig_count);
        sig_times_count = (EditText) getActivity().findViewById(R.id.sig_times_count);


        prescriber = (TextView) getActivity().findViewById(R.id.prescriber);
        drug = (TextView) getActivity().findViewById(R.id.drug);


        Spinner uom_spinner = (Spinner) getActivity().findViewById(R.id.uom_spinner);
        Spinner interval_spinner = (Spinner) getActivity().findViewById(R.id.interval_spinner);

        switch (uom_spinner.getSelectedItemPosition()) {
            case 0:
                UOMCode = 60;
                break;
            case 1:
                UOMCode = 61;
                break;
            case 2:
                UOMCode = 62;
                break;
            case 3:
                UOMCode = 63;
                break;
            case 4:
                UOMCode = 64;
                break;
            case 5:
                UOMCode = 65;
                break;
            case 6:
                UOMCode = 66;
                break;
        }

        switch (interval_spinner.getSelectedItemPosition()) {
            case 0:
                intervalCode = 50;
                break;
            case 1:
                intervalCode = 51;
                break;
            case 2:
                intervalCode = 52;
                break;
        }


        try {
            DateFormat formatter = new SimpleDateFormat("dd-MM-yyyy");
            formatter.setLenient(false);
            Date writtenDate = formatter.parse(written_date.getText().toString());
            Date expiryDate = formatter.parse(expiry_date.getText().toString());

            BasicDBObject sigArray = new BasicDBObject();
            sigArray.put("single_dose_qty", Integer.parseInt(sig_count.getText().toString()));
            sigArray.put("sig_times", Integer.parseInt(sig_times_count.getText().toString()));
            sigArray.put("UOM_code", UOMCode);
            sigArray.put("interval_code", intervalCode);


            DBCollection prescription = MongoConnect.getCollection(MongoConnect.dbCollections.prescription);

            BasicDBObject doc = new BasicDBObject("_id", rx_no.getText().toString())
                    .append("drug_NDC", NDCNUMBER)
                    .append("physician_NPI", NPINUMBER)
                    .append("written_date", writtenDate)
                    .append("expiry_date", expiryDate)
                    .append("no_of_refills", Integer.parseInt(refill_count.getText().toString()))
                    .append("expiry_date", expiryDate)
                    .append("sig", sigArray)
                    .append("isActive", true);

            prescription.insert(doc);


            // insert the rx into user_profile
            DBCollection user_profile = MongoConnect.getCollection(MongoConnect.dbCollections.user_profile);
            BasicDBObject rxArrayElement = new BasicDBObject();
            rxArrayElement.put("$addToSet", new BasicDBObject("Rx", rx_no.getText().toString()));
            BasicDBObject userMatch = new BasicDBObject();
            userMatch.put("_id", new ObjectId(ARG_USER_ID));
            user_profile.update(userMatch, rxArrayElement);


            return true;

        } catch (Exception e) {
            e.printStackTrace();
            return false;

        }

    }


    public void backToRxMainScreen() {
        Fragment RXFragment = new RxFragment();
        Bundle args = new Bundle();
        args.putString("USER_ID", ARG_USER_ID);
        args.putBoolean("SHOW_ACTIVE_RX", false);
        RXFragment.setArguments(args);
        FragmentManager fragmentManager = getFragmentManager();
        fragmentManager.beginTransaction().replace(R.id.content_frame, RXFragment).commit();
    }

    // Below method is called after clicking "Search" button in the AddRX screen. The user would be navigated to Search Prescriber screen
    private void NavigateToSearchPrescriberScreen() {
        try {
            Fragment searchPrescriberFragment = new SearchPrescriberFragment();
            Bundle args = new Bundle();
            args.putString("USER_ID", ARG_USER_ID);
            args.putString("SCREEN_CODE", "");
            args.putString("RXNUMBER", txtRXNO.getText().toString());

            String npiDetails = tvPrescriberNPI.getText().toString();
            if (npiDetails.length() > 6) {
                String[] npiNumberArray = npiDetails.split(SLASHDELIMITER);
                args.putString("NPINUMBER", npiNumberArray[0].trim());

                String[] prescriberNameArray = npiNumberArray[1].split(COMMADELIMITER);
                args.putString("PRESCRIBERLNAME", prescriberNameArray[0].trim());
                args.putString("PRESCRIBERFNAME", prescriberNameArray[1].trim());
            } else {
                args.putString("NPINUMBER", NPINUMBER);
                args.putString("PRESCRIBERLNAME", PRESCRIBERLNAME);
                args.putString("PRESCRIBERFNAME", PRESCRIBERFNAME);
            }

            String drugDetails = tvDrugNDC.getText().toString();
            if (drugDetails.length() > 6) {
                String[] drugDetailsArray = drugDetails.split(SLASHDELIMITER);
                args.putString("NDCNUMBER", drugDetailsArray[0].trim());
                args.putString("NDCNAME", drugDetailsArray[1].trim());
            } else {
                args.putString("NDCNUMBER", NDCNUMBER);
                args.putString("NDCNAME", NDCNAME);
            }

            args.putString("NO_OF_REFILLS", txtNoOfRefills.getText().toString());
            args.putString("WRITTENDATE", txtWrittenDate.getText().toString());
            args.putString("EXPIRYDATE", txtExpiryDate.getText().toString());
            args.putString("DRUGCOUNT", txtDrugCount.getText().toString());
            args.putString("DRUGDOSAGE", spDrugDosage.getSelectedItem().toString());
            args.putString("DOSAGECOUNT", txtDosageCount.getText().toString());
            args.putString("DOSAGEINTERVAL", spDosageInterval.getSelectedItem().toString());
            searchPrescriberFragment.setArguments(args);
            FragmentManager fragmentManager = getFragmentManager();
            fragmentManager.beginTransaction().replace(R.id.content_frame, searchPrescriberFragment).commit();
        } catch (Exception ex) {
            Log.e(TAG, "Exception - " + ex.getMessage());
            Toast.makeText(getActivity(),
                    "Exception - " + ex.getMessage(), Toast.LENGTH_SHORT)
                    .show();
        }
    }

    // Below method is called after clicking "Search" button in the AddRX screen. The user would be navigated to Search Drug screen
    private void NavigateToSearchDrugScreen() {
        try {
            Fragment searchPrescriberFragment = new SearchDrugFragment();
            Bundle args = new Bundle();
            args.putString("USER_ID", ARG_USER_ID);
            args.putString("SCREEN_CODE", "");
            args.putString("RXNUMBER", txtRXNO.getText().toString());

            String npiDetails = tvPrescriberNPI.getText().toString();
            if (npiDetails.length() > 6) {
                String[] npiNumberArray = npiDetails.split(SLASHDELIMITER);
                args.putString("NPINUMBER", npiNumberArray[0].trim());

                String[] prescriberNameArray = npiNumberArray[1].split(COMMADELIMITER);
                args.putString("PRESCRIBERLNAME", prescriberNameArray[0].trim());
                args.putString("PRESCRIBERFNAME", prescriberNameArray[1].trim());
            } else {
                args.putString("NPINUMBER", NPINUMBER);
                args.putString("PRESCRIBERLNAME", PRESCRIBERLNAME);
                args.putString("PRESCRIBERFNAME", PRESCRIBERFNAME);
            }

            String drugDetails = tvDrugNDC.getText().toString();
            if (drugDetails.length() > 6) {
                String[] drugDetailsArray = drugDetails.split(SLASHDELIMITER);
                args.putString("NDCNUMBER", drugDetailsArray[0].trim());
                args.putString("NDCNAME", drugDetailsArray[1].trim());
            } else {
                args.putString("NDCNUMBER", NDCNUMBER);
                args.putString("NDCNAME", NDCNAME);
            }

            args.putString("NO_OF_REFILLS", txtNoOfRefills.getText().toString());
            args.putString("WRITTENDATE", txtWrittenDate.getText().toString());
            args.putString("EXPIRYDATE", txtExpiryDate.getText().toString());
            args.putString("DRUGCOUNT", txtDrugCount.getText().toString());
            args.putString("DRUGDOSAGE", spDrugDosage.getSelectedItem().toString());
            args.putString("DOSAGECOUNT", txtDosageCount.getText().toString());
            args.putString("DOSAGEINTERVAL", spDosageInterval.getSelectedItem().toString());
            searchPrescriberFragment.setArguments(args);
            FragmentManager fragmentManager = getFragmentManager();
            fragmentManager.beginTransaction().replace(R.id.content_frame, searchPrescriberFragment).commit();
        } catch (Exception ex) {
            Log.e(TAG, "Exception - " + ex.getMessage());
            Toast.makeText(getActivity(),
                    "Exception - " + ex.getMessage(), Toast.LENGTH_SHORT)
                    .show();
        }
    }


}
