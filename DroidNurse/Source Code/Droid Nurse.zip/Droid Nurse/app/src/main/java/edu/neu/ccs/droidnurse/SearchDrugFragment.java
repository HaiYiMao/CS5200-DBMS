package edu.neu.ccs.droidnurse;

import android.app.Fragment;
import android.app.FragmentManager;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.TableLayout;
import android.widget.TableRow;
import android.widget.TextView;
import android.widget.Toast;

import com.mongodb.BasicDBObject;
import com.mongodb.DBCollection;
import com.mongodb.DBCursor;
import com.mongodb.DBObject;

import org.joda.time.DateTime;
import org.joda.time.DateTimeZone;

import java.util.ArrayList;
import java.util.List;


/**
 * Created by Venkatesh on 29/07/14.
 */

public class SearchDrugFragment extends Fragment {

    private static final String TAG = "SearchDrugFragment";
    private final String SCREENCODECONSTANT = "D1";
    View rootView;


    // Bundle Arguments
    public String ARG_USER_ID;
    public String SCREEN_CODE;
    public String NPINUMBER;
    public String PRESCRIBERLNAME;
    public String PRESCRIBERFNAME;
    public String RXNUMBER;
    public String NDCNUMBER;
    public String NDCNAME;
    public String NO_OF_REFILLS;
    public String WRITTENDATE;
    public String EXPIRYDATE;
    public String DRUGCOUNT;
    public String DRUGDOSAGE;
    public String DOSAGECOUNT;
    public String DOSAGEINTERVAL;
    public String DRUGTEMPNAME;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {

        rootView = inflater.inflate(R.layout.fragment_search_drug, container, false);

        GetBundleArguments();

        if (SCREEN_CODE.toUpperCase().equals("D2")) {
            DRUGTEMPNAME = getArguments().getString("DRUGTEMPNAME");
            EditText txtDrugName = (EditText) rootView.findViewById(R.id.txtDrugName);
            txtDrugName.setText(DRUGTEMPNAME);
        }

        Button btnSearchPrescriber = (Button) rootView.findViewById(R.id.btnSearchDrug);
        btnSearchPrescriber.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {

                TableLayout tableLayout = (TableLayout) rootView.findViewById(R.id.tblSearchDrugResults);
                tableLayout.removeAllViewsInLayout();

                EditText txtDrugName = (EditText) rootView.findViewById(R.id.txtDrugName);
                String drugName = txtDrugName.getText().toString().toLowerCase().trim();

                if (drugName.length() > 0) {
                    DisplayDrugDetailsFromDB(drugName);
                } else {
                    Toast.makeText(getActivity(),
                            "Please enter a valid drug name for search.", Toast.LENGTH_SHORT)
                            .show();
                }

            }
        });


        Button btnBackToAddRX = (Button) rootView.findViewById(R.id.btnBackToAddRX);
        btnBackToAddRX.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Fragment addRXFragment = new RxFragmentAddRx();
                Bundle args = new Bundle();
                args.putString("USER_ID", ARG_USER_ID);
                args.putString("SCREEN_CODE", SCREENCODECONSTANT);
                args.putString("RXNUMBER", RXNUMBER);
                args.putString("NPINUMBER", NPINUMBER);
                args.putString("PRESCRIBERLNAME", PRESCRIBERLNAME);
                args.putString("PRESCRIBERFNAME", PRESCRIBERFNAME);
                args.putString("NDCNUMBER", NDCNUMBER);
                args.putString("NDCNAME", NDCNAME);
                args.putString("NO_OF_REFILLS", NO_OF_REFILLS);
                args.putString("WRITTENDATE", WRITTENDATE);
                args.putString("EXPIRYDATE", EXPIRYDATE);
                args.putString("DRUGCOUNT", DRUGCOUNT);
                args.putString("DRUGDOSAGE", DRUGDOSAGE);
                args.putString("DOSAGECOUNT", DOSAGECOUNT);
                args.putString("DOSAGEINTERVAL", DOSAGEINTERVAL);
                addRXFragment.setArguments(args);
                FragmentManager fragmentManager = getFragmentManager();
                fragmentManager.beginTransaction().replace(R.id.content_frame, addRXFragment).commit();

            }
        });

        return rootView;
    }

    // Retrieves the bundle arguments which holds data from the previous screens
    private void GetBundleArguments() {
        try {
            ARG_USER_ID = getArguments().getString("USER_ID");
            SCREEN_CODE = getArguments().getString("SCREEN_CODE");
            RXNUMBER = getArguments().getString("RXNUMBER");
            NPINUMBER = getArguments().getString("NPINUMBER");
            PRESCRIBERLNAME = getArguments().getString("PRESCRIBERLNAME");
            PRESCRIBERFNAME = getArguments().getString("PRESCRIBERFNAME");
            NDCNUMBER = getArguments().getString("NDCNUMBER");
            NDCNAME = getArguments().getString("NDCNAME");
            NO_OF_REFILLS = getArguments().getString("NO_OF_REFILLS");
            WRITTENDATE = getArguments().getString("WRITTENDATE");
            EXPIRYDATE = getArguments().getString("EXPIRYDATE");
            DRUGCOUNT = getArguments().getString("DRUGCOUNT");
            DRUGDOSAGE = getArguments().getString("DRUGDOSAGE");
            DOSAGECOUNT = getArguments().getString("DOSAGECOUNT");
            DOSAGEINTERVAL = getArguments().getString("DOSAGEINTERVAL");

        } catch (Exception ex) {
            Log.e(TAG, "Exception At GetBundleArguments() - " + ex.getMessage());
        }
    }

    // Below method displays all the drug details
    private void DisplayDrugDetailsFromDB(String drugName) {
        try {
            TableRow tr_head = new TableRow(getActivity());
            TableLayout tableLayout = (TableLayout) rootView.findViewById(R.id.tblSearchDrugResults);
            tr_head.setBackgroundColor(Color.BLUE);
            tr_head.setLayoutParams(new TableLayout.LayoutParams(
                    TableRow.LayoutParams.MATCH_PARENT,
                    TableRow.LayoutParams.WRAP_CONTENT));


            TextView label_NPI = new TextView(getActivity());
            label_NPI.setText("NDC");
            label_NPI.setTextColor(Color.WHITE);
            tr_head.addView(label_NPI);

            TextView label_Select = new TextView(getActivity());
            label_Select.setText("Select");
            label_Select.setTextColor(Color.WHITE);
            tr_head.addView(label_Select);

            TextView label_View = new TextView(getActivity());
            label_View.setText("View");
            label_View.setTextColor(Color.WHITE);
            tr_head.addView(label_View);

            tableLayout.addView(tr_head, new TableLayout.LayoutParams(
                    TableLayout.LayoutParams.MATCH_PARENT,
                    TableLayout.LayoutParams.WRAP_CONTENT));

            DBCollection drugCollections = MongoConnect.getCollection(MongoConnect.dbCollections.drug_details);
            BasicDBObject regexQuery = new BasicDBObject();
            regexQuery.put("drug_name",
                    new BasicDBObject("$regex", drugName + ".*")
                            .append("$options", "i")
            );
            DBCursor cursor = drugCollections.find(regexQuery);
            while (cursor.hasNext()) {
                DBObject dbObject = cursor.next();
                String ndc = dbObject.get("NDC").toString();
                String drugNameFromDB = dbObject.get("drug_name").toString();

                // Create the table row
                TableRow tr = new TableRow(getActivity());
                tr.setLayoutParams(new TableRow.LayoutParams(
                        TableRow.LayoutParams.MATCH_PARENT,
                        TableRow.LayoutParams.WRAP_CONTENT));

                // Create a TextView to add ndc number
                TextView txtViewNDCTableResults = new TextView(getActivity());
                txtViewNDCTableResults.setText(ndc);
                txtViewNDCTableResults.setPadding(2, 0, 5, 0);
                txtViewNDCTableResults.setTextColor(Color.BLACK);
                tr.addView(txtViewNDCTableResults);

                // Once when any of the radio button is selected, the user should be navigated to the AddRX screen
                final RadioButton rbSelectDrug = new RadioButton(getActivity());
                rbSelectDrug.setHint(ndc);
                rbSelectDrug.setText(drugNameFromDB);
                rbSelectDrug.setTextColor(Color.BLACK);
                rbSelectDrug.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        String ndcSelectedDrug = rbSelectDrug.getHint().toString();
                        String drugNameFromDB = rbSelectDrug.getText().toString();
                        Fragment addRXFragment = new RxFragmentAddRx();
                        Bundle args = new Bundle();
                        args.putString("USER_ID", ARG_USER_ID);
                        args.putString("SCREEN_CODE", SCREENCODECONSTANT);
                        args.putString("RXNUMBER", RXNUMBER);
                        args.putString("NPINUMBER", NPINUMBER);
                        args.putString("PRESCRIBERLNAME", PRESCRIBERLNAME);
                        args.putString("PRESCRIBERFNAME", PRESCRIBERFNAME);

                        args.putString("NDCNUMBER", ndcSelectedDrug);
                        args.putString("NDCNAME", drugNameFromDB);

                        args.putString("NO_OF_REFILLS", NO_OF_REFILLS);
                        args.putString("WRITTENDATE", WRITTENDATE);
                        args.putString("EXPIRYDATE", EXPIRYDATE);
                        args.putString("DRUGCOUNT", DRUGCOUNT);
                        args.putString("DRUGDOSAGE", DRUGDOSAGE);
                        args.putString("DOSAGECOUNT", DOSAGECOUNT);
                        args.putString("DOSAGEINTERVAL", DOSAGEINTERVAL);

                        addRXFragment.setArguments(args);
                        FragmentManager fragmentManager = getFragmentManager();
                        fragmentManager.beginTransaction().replace(R.id.content_frame, addRXFragment).commit();


                    }
                });
                tr.addView(rbSelectDrug);


                // Once when any of the radio button is selected, the user should be navigated to the AddRX screen
                final Button btnMoreDetails = new Button(getActivity());
                btnMoreDetails.setHint(ndc);
                btnMoreDetails.setText("Details");
                btnMoreDetails.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        String nDCSelectedDRUG = btnMoreDetails.getHint().toString();
                        Fragment drugDetailsAPIFragment = new DrugDetailsAPI();
                        Bundle args = new Bundle();
                        args.putString("USER_ID", ARG_USER_ID);
                        args.putString("SCREEN_CODE", SCREENCODECONSTANT);
                        args.putString("RXNUMBER", RXNUMBER);
                        args.putString("NPINUMBER", NPINUMBER);
                        args.putString("PRESCRIBERLNAME", PRESCRIBERLNAME);
                        args.putString("PRESCRIBERFNAME", PRESCRIBERFNAME);
                        args.putString("NDCNUMBER", NDCNUMBER);
                        args.putString("NDCNAME", NDCNAME);
                        args.putString("NO_OF_REFILLS", NO_OF_REFILLS);
                        args.putString("WRITTENDATE", WRITTENDATE);
                        args.putString("EXPIRYDATE", EXPIRYDATE);
                        args.putString("DRUGCOUNT", DRUGCOUNT);
                        args.putString("DRUGDOSAGE", DRUGDOSAGE);
                        args.putString("DOSAGECOUNT", DOSAGECOUNT);
                        args.putString("DOSAGEINTERVAL", DOSAGEINTERVAL);

                        EditText txtDrugName = (EditText) rootView.findViewById(R.id.txtDrugName);
                        args.putString("DRUGTEMPNAME", txtDrugName.getText().toString());
                        args.putString("NDCNUMBERTEMP", nDCSelectedDRUG);

                        drugDetailsAPIFragment.setArguments(args);
                        FragmentManager fragmentManager = getFragmentManager();
                        fragmentManager.beginTransaction().replace(R.id.content_frame, drugDetailsAPIFragment).commit();

                    }
                });
                tr.addView(btnMoreDetails);


                // finally add the table row to the table row
                tableLayout.addView(tr, new TableLayout.LayoutParams(
                        TableLayout.LayoutParams.MATCH_PARENT,
                        TableLayout.LayoutParams.WRAP_CONTENT));
            }

        } catch (Exception ex) {
            Log.e(TAG, "Exception - " + ex.getMessage());
            Toast.makeText(getActivity(),
                    "Exception - "+ex.getMessage(), Toast.LENGTH_SHORT)
                    .show();
        }
    }
}
