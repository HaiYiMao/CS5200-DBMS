package edu.neu.ccs.droidnurse;

import android.app.Fragment;
import android.app.FragmentManager;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.TableLayout;
import android.widget.TableRow;
import android.widget.TextView;
import android.widget.Toast;

import com.mongodb.BasicDBObject;
import com.mongodb.DBCollection;
import com.mongodb.DBCursor;
import com.mongodb.DBObject;

import org.joda.time.DateTime;
import org.joda.time.DateTimeZone;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by Venkatesh on 26/07/14.
 */

public class SearchPrescriberFragment extends Fragment {

    private static final String TAG = "SearchPrescriberFragment";
    private static final String COMMADELIMITER = ",";
    View rootView;

    // Bundle Arguments
    public String ARG_USER_ID;
    public String SCREEN_CODE;
    public String NPINUMBER;
    public String PRESCRIBERLNAME;
    public String PRESCRIBERFNAME;
    public String RXNUMBER;
    public String NDCNUMBER;
    public String NDCNAME;
    public String NO_OF_REFILLS;
    public String WRITTENDATE;
    public String EXPIRYDATE;
    public String DRUGCOUNT;
    public String DRUGDOSAGE;
    public String DOSAGECOUNT;
    public String DOSAGEINTERVAL;
    public String PRESCRIBERTEMPLNAME;
    public String PRESCRIBERTEMPFNAME;


    public SearchPrescriberFragment() {
        // Required empty public constructor
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {

        rootView = inflater.inflate(R.layout.fragment_search_prescriber, container, false);
        GetBundleArguments();

        /*
       Below String are used for bundle arguments when navigation is made between multiple screens
       A-> Navigation from MyPrescription to AddRX page
       B-> Navigation from SearchPrescriber to AddRX page
       C-> Navigation from PhyscianDetailsAPI to AddRX page
    */
        if (SCREEN_CODE.toUpperCase().equals("C")) {
            PRESCRIBERTEMPLNAME = getArguments().getString("PRESCRIBERTEMPLNAME");
            PRESCRIBERTEMPFNAME = getArguments().getString("PRESCRIBERTEMPFNAME");
            EditText txtPrescriberLastName = (EditText) rootView.findViewById(R.id.txtPrescriberLastName);
            EditText txtPrescriberFirstName = (EditText) rootView.findViewById(R.id.txtPrescriberFirstName);
            txtPrescriberLastName.setText(PRESCRIBERTEMPLNAME);
            txtPrescriberFirstName.setText(PRESCRIBERTEMPFNAME);
        }

        Button btnSearchPrescriber = (Button) rootView.findViewById(R.id.btnSearchPrescriber);
        btnSearchPrescriber.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {

                TableLayout tableLayout = (TableLayout) rootView.findViewById(R.id.tblSearchPresciberResults);
                tableLayout.removeAllViewsInLayout();

                EditText txtPrescriberFirstName = (EditText) rootView.findViewById(R.id.txtPrescriberFirstName);
                EditText txtPrescriberLastName = (EditText) rootView.findViewById(R.id.txtPrescriberLastName);
                String prescriberFirstName = txtPrescriberFirstName.getText().toString().trim().toUpperCase();
                String prescriberLastName = txtPrescriberLastName.getText().toString().trim().toUpperCase();

                if ((prescriberFirstName.length() > 0) || ((prescriberLastName.length() > 0))) {
                    DisplayPrescribersByNameFromDB(prescriberFirstName, prescriberLastName);
                } else {
                    Toast.makeText(getActivity(),
                            "Please enter valid first/last name of prescriber for search.", Toast.LENGTH_SHORT)
                            .show();
                }
            }

        });


        Button btnBackToAddRX = (Button) rootView.findViewById(R.id.btnGoBackToAddRX);
        btnBackToAddRX.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Fragment addRXFragment = new RxFragmentAddRx();
                Bundle args = new Bundle();
                args.putString("USER_ID", ARG_USER_ID);
                args.putString("SCREEN_CODE", "B");
                args.putString("RXNUMBER", RXNUMBER);
                args.putString("NPINUMBER", NPINUMBER);
                args.putString("PRESCRIBERLNAME", PRESCRIBERLNAME);
                args.putString("PRESCRIBERFNAME", PRESCRIBERFNAME);
                args.putString("NDCNUMBER", NDCNUMBER);
                args.putString("NDCNAME", NDCNAME);
                args.putString("NO_OF_REFILLS", NO_OF_REFILLS);
                args.putString("WRITTENDATE", WRITTENDATE);
                args.putString("EXPIRYDATE", EXPIRYDATE);
                args.putString("DRUGCOUNT", DRUGCOUNT);
                args.putString("DRUGDOSAGE", DRUGDOSAGE);
                args.putString("DOSAGECOUNT", DOSAGECOUNT);
                args.putString("DOSAGEINTERVAL", DOSAGEINTERVAL);
                addRXFragment.setArguments(args);
                FragmentManager fragmentManager = getFragmentManager();
                fragmentManager.beginTransaction().replace(R.id.content_frame, addRXFragment).commit();

            }
        });

        return rootView;
    }

    // Below method displays all the prescribers with the respective first name and last name
    private void DisplayPrescribersByNameFromDB(String prescriberFirstName, String prescriberLastName) {
        try {
            TableRow tr_head = new TableRow(getActivity());
            TableLayout tableLayout = (TableLayout) rootView.findViewById(R.id.tblSearchPresciberResults);
            tr_head.setBackgroundColor(Color.BLUE);
            tr_head.setLayoutParams(new TableLayout.LayoutParams(
                    TableRow.LayoutParams.MATCH_PARENT,
                    TableRow.LayoutParams.WRAP_CONTENT));


            TextView label_NPI = new TextView(getActivity());
            label_NPI.setText("NPI ID");
            label_NPI.setTextColor(Color.WHITE);
            tr_head.addView(label_NPI);

            TextView label_Select = new TextView(getActivity());
            label_Select.setText("Select");
            label_Select.setTextColor(Color.WHITE);
            tr_head.addView(label_Select);

            TextView label_View = new TextView(getActivity());
            label_View.setText("View");
            label_View.setTextColor(Color.WHITE);
            tr_head.addView(label_View);

            tableLayout.addView(tr_head, new TableLayout.LayoutParams(
                    TableLayout.LayoutParams.MATCH_PARENT,
                    TableLayout.LayoutParams.WRAP_CONTENT));

            DBCollection physicianCollections = MongoConnect.getCollection(MongoConnect.dbCollections.physician);
            BasicDBObject searchQuery = new BasicDBObject();
            List<BasicDBObject> obj = new ArrayList<BasicDBObject>();

            // Added if else block as the search could be either with first or last name
            if ((prescriberFirstName.length() > 0) && (prescriberLastName.length() > 0)) {
                obj.add(new BasicDBObject("first_name", prescriberFirstName));
                obj.add(new BasicDBObject("last_name", prescriberLastName));
                searchQuery.put("$and", obj);
            } else if (prescriberFirstName.length() > 0) {
                searchQuery.put("first_name", prescriberFirstName);
            } else if (prescriberLastName.length() > 0) {
                searchQuery.put("last_name", prescriberLastName);
            }

            DBCursor cursor = physicianCollections.find(searchQuery);
            while (cursor.hasNext()) {

                DBObject dbObject = cursor.next();
                String npi = dbObject.get("npi").toString();
                String firstName = dbObject.get("first_name").toString();
                String lastName = dbObject.get("last_name").toString();

                // Create the table row
                TableRow tr = new TableRow(getActivity());
                tr.setLayoutParams(new TableRow.LayoutParams(
                        TableRow.LayoutParams.MATCH_PARENT,
                        TableRow.LayoutParams.WRAP_CONTENT));

                // Create a TextView to add npi, first name and last name of the prescriber
                TextView txtViewNPITableResults = new TextView(getActivity());
                txtViewNPITableResults.setText(npi);
                txtViewNPITableResults.setPadding(2, 0, 5, 0);
                txtViewNPITableResults.setTextColor(Color.BLACK);
                tr.addView(txtViewNPITableResults);

                // Once when any of the radio button is selected, the user should be navigated to the AddRX screen
                final RadioButton rbSelectPrescriber = new RadioButton(getActivity());
                rbSelectPrescriber.setId(Integer.parseInt(npi));
                rbSelectPrescriber.setHint(lastName + COMMADELIMITER + firstName);
                rbSelectPrescriber.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        int npiSelectedPrescriber = rbSelectPrescriber.getId();
                        String[] prescriberNameArray = rbSelectPrescriber.getHint().toString().split(COMMADELIMITER);
                        Fragment addRXFragment = new RxFragmentAddRx();
                        Bundle args = new Bundle();
                        args.putString("USER_ID", ARG_USER_ID);
                        args.putString("SCREEN_CODE", "B");
                        args.putString("RXNUMBER", RXNUMBER);
                        args.putString("NPINUMBER", String.valueOf(npiSelectedPrescriber));
                        args.putString("NDCNUMBER", NDCNUMBER);
                        args.putString("NDCNAME", NDCNAME);
                        args.putString("NO_OF_REFILLS", NO_OF_REFILLS);
                        args.putString("WRITTENDATE", WRITTENDATE);
                        args.putString("EXPIRYDATE", EXPIRYDATE);
                        args.putString("DRUGCOUNT", DRUGCOUNT);
                        args.putString("DRUGDOSAGE", DRUGDOSAGE);
                        args.putString("DOSAGECOUNT", DOSAGECOUNT);
                        args.putString("DOSAGEINTERVAL", DOSAGEINTERVAL);

                        args.putString("PRESCRIBERLNAME", prescriberNameArray[0].trim());
                        args.putString("PRESCRIBERFNAME", prescriberNameArray[1].trim());

                        addRXFragment.setArguments(args);
                        FragmentManager fragmentManager = getFragmentManager();
                        fragmentManager.beginTransaction().replace(R.id.content_frame, addRXFragment).commit();

                    }
                });
                tr.addView(rbSelectPrescriber);


                // Once when any of the radio button is selected, the user should be navigated to the AddRX screen
                final Button btnMoreDetails = new Button(getActivity());
                btnMoreDetails.setId(Integer.parseInt(npi));
                btnMoreDetails.setHint(lastName + COMMADELIMITER + firstName);
                btnMoreDetails.setText("Details");
                btnMoreDetails.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        int npiSelectedPrescriber = btnMoreDetails.getId();
                        String[] prescriberNameArray = btnMoreDetails.getHint().toString().split(COMMADELIMITER);

                        Fragment physicianDetailsAPIFragment = new PhysicianDetailsAPI();
                        Bundle args = new Bundle();
                        args.putString("USER_ID", ARG_USER_ID);
                        args.putString("SCREEN_CODE", "B");
                        args.putString("RXNUMBER", RXNUMBER);
                        args.putString("NPINUMBER", NPINUMBER);
                        args.putString("NPINUMBERTEMP", String.valueOf(npiSelectedPrescriber));
                        args.putString("NDCNUMBER", NDCNUMBER);
                        args.putString("NDCNAME", NDCNAME);
                        args.putString("NO_OF_REFILLS", NO_OF_REFILLS);
                        args.putString("WRITTENDATE", WRITTENDATE);
                        args.putString("EXPIRYDATE", EXPIRYDATE);
                        args.putString("DRUGCOUNT", DRUGCOUNT);
                        args.putString("DRUGDOSAGE", DRUGDOSAGE);
                        args.putString("DOSAGECOUNT", DOSAGECOUNT);
                        args.putString("DOSAGEINTERVAL", DOSAGEINTERVAL);

                        args.putString("PRESCRIBERLNAME", prescriberNameArray[0].trim());
                        args.putString("PRESCRIBERFNAME", prescriberNameArray[1].trim());
                        EditText txtPrescriberLastName = (EditText) rootView.findViewById(R.id.txtPrescriberLastName);
                        EditText txtPrescriberFirstName = (EditText) rootView.findViewById(R.id.txtPrescriberFirstName);

                        args.putString("PRESCRIBERTEMPLNAME", txtPrescriberLastName.getText().toString());
                        args.putString("PRESCRIBERTEMPFNAME", txtPrescriberFirstName.getText().toString());

                        physicianDetailsAPIFragment.setArguments(args);
                        FragmentManager fragmentManager = getFragmentManager();
                        fragmentManager.beginTransaction().replace(R.id.content_frame, physicianDetailsAPIFragment).commit();

                    }
                });
                tr.addView(btnMoreDetails);


                // finally add the table row to the table row
                tableLayout.addView(tr, new TableLayout.LayoutParams(
                        TableLayout.LayoutParams.MATCH_PARENT,
                        TableLayout.LayoutParams.WRAP_CONTENT));
            }
        } catch (Exception ex) {
            Log.e(TAG, "Exception - " + ex.getMessage());
        }
    }

    // Retrieves the bundle arguments which holds data from the previous screens
    private void GetBundleArguments() {
        try {
            ARG_USER_ID = getArguments().getString("USER_ID");
            SCREEN_CODE = getArguments().getString("SCREEN_CODE");
            RXNUMBER = getArguments().getString("RXNUMBER");
            NPINUMBER = getArguments().getString("NPINUMBER");
            PRESCRIBERLNAME = getArguments().getString("PRESCRIBERLNAME");
            PRESCRIBERFNAME = getArguments().getString("PRESCRIBERFNAME");
            NDCNUMBER = getArguments().getString("NDCNUMBER");
            NDCNAME = getArguments().getString("NDCNAME");
            NO_OF_REFILLS = getArguments().getString("NO_OF_REFILLS");
            WRITTENDATE = getArguments().getString("WRITTENDATE");
            EXPIRYDATE = getArguments().getString("EXPIRYDATE");
            DRUGCOUNT = getArguments().getString("DRUGCOUNT");
            DRUGDOSAGE = getArguments().getString("DRUGDOSAGE");
            DOSAGECOUNT = getArguments().getString("DOSAGECOUNT");
            DOSAGEINTERVAL = getArguments().getString("DOSAGEINTERVAL");

        } catch (Exception ex) {
            Log.e(TAG, "Exception At GetBundleArguments() - " + ex.getMessage());
        }
    }

}